
# 🌍 WEBOND — Complete Deployment Guide
### By Yusuf Abubakar Yusuf (Yushat) | Founder of Webond

---

## 📦 What's in the ZIP (43 files, 4 projects)

| Project | Description | Tech |
|---|---|---|
| `webond-react/` | Web app (runs in browser) | React 18, Zustand, Framer Motion |
| `webond-backend/` | API server with real database + AI | Node.js, Express, Socket.io |
| `webond-mobile/` | iOS + Android mobile app | React Native, Expo |
| `webond-admin/` | Admin dashboard (single HTML file) | Vanilla JS |

---

## ⚡ STEP 1 — Set Up the Database (Supabase)

**Free forever for small projects.**

1. Go to [supabase.com](https://supabase.com) → "New Project"
2. Name it `webond` → choose a region close to Nigeria (e.g. `eu-west-1`)
3. Go to **SQL Editor** → **New query**
4. Copy the entire contents of `webond-backend/config/schema.sql`
5. Paste → click **Run** ✅
6. Go to **Project Settings → API** → copy:
   - `Project URL` → this is your `SUPABASE_URL`
   - `anon/public` key → `SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_KEY`

---

## ⚡ STEP 2 — Get API Keys

### Claude AI (Webond AI chat)
1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Create account → **API Keys** → **Create Key**
3. Copy → this is your `ANTHROPIC_API_KEY`

### Email OTP (Resend — free 3,000 emails/month)
1. Go to [resend.com](https://resend.com) → sign up free
2. **API Keys** → **Create API Key**
3. Copy → this is your `RESEND_API_KEY`

---

## ⚡ STEP 3 — Run the Backend

```bash
# 1. Go into backend folder
cd webond-backend

# 2. Copy env file
cp .env.example .env

# 3. Fill in your .env file (open in any text editor):
# SUPABASE_URL=https://your-project.supabase.co
# SUPABASE_ANON_KEY=your_key_here
# SUPABASE_SERVICE_KEY=your_service_key
# ANTHROPIC_API_KEY=sk-ant-your_key
# RESEND_API_KEY=re_your_key
# JWT_SECRET=make_this_a_long_random_string_64chars_minimum
# JWT_REFRESH_SECRET=another_long_random_string_64chars_minimum

# 4. Install and run
npm install
npm run dev
```

You should see:
```
🚀 Webond API running on port 5000
🌍 Environment: development
📡 Real-time: Socket.io enabled
🤖 AI: Claude connected
🗄️  DB: Supabase connected
```

---

## ⚡ STEP 4 — Run the Web App

```bash
# In a NEW terminal window
cd webond-react

# Copy env file
cp .env.example .env.local
# .env.local should have:
# REACT_APP_API_URL=http://localhost:5000/api
# REACT_APP_SOCKET_URL=http://localhost:5000

npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000) 🎉

---

## ⚡ STEP 5 — Run the Mobile App

```bash
cd webond-mobile

# Install Expo CLI globally (first time only)
npm install -g expo-cli eas-cli

npm install

# Start development server
npx expo start
```

Then:
- Press `a` for Android emulator
- Press `i` for iOS simulator  
- Scan QR code with **Expo Go** app on your real phone

---

## ⚡ STEP 6 — Open Admin Dashboard

Just double-click `webond-admin/index.html` in your file manager.

Or open it in any browser:
```
file:///path/to/webond-admin/index.html
```

---

## 🌍 DEPLOY EVERYTHING ONLINE (FREE)

### Deploy Backend → Render.com (Free)

1. Push `webond-backend` to GitHub:
```bash
cd webond-backend
git init
git add .
git commit -m "Webond backend"
git remote add origin https://github.com/YOURUSERNAME/webond-backend.git
git push -u origin main
```

2. Go to [render.com](https://render.com) → **New Web Service**
3. Connect your GitHub repo
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `node src/server.js`
5. Add all your environment variables in the **Environment** section
6. Deploy → Your API URL: `https://webond-backend.onrender.com`

### Deploy Web App → Vercel (Free)

1. Push `webond-react` to GitHub
2. Go to [vercel.com](https://vercel.com) → **New Project** → Import repo
3. Add environment variable:
   - `REACT_APP_API_URL` = `https://webond-backend.onrender.com/api`
   - `REACT_APP_SOCKET_URL` = `https://webond-backend.onrender.com`
4. Deploy → Your app: `https://webond.vercel.app`

### Deploy Admin Dashboard → Netlify (Free)

1. Go to [netlify.com](https://netlify.com)
2. Drag the `webond-admin` folder onto the dashboard
3. Done! Live at `https://webond-admin.netlify.app`

**⚠️ Protect admin with a password in Netlify settings → Basic Auth.**

---

## 📱 PUBLISH TO APP STORES

### Setup EAS (Expo Application Services)

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo account (create free at expo.dev)
eas login

# Configure your project
cd webond-mobile
eas build:configure
```

Update `app.json`:
```json
{
  "expo": {
    "extra": {
      "apiUrl": "https://webond-backend.onrender.com/api",
      "socketUrl": "https://webond-backend.onrender.com",
      "eas": { "projectId": "your-expo-project-id" }
    }
  }
}
```

### Build for Android (Google Play)

```bash
# Build APK for testing
eas build --platform android --profile preview

# Build AAB for Google Play Store
eas build --platform android --profile production
```

**Google Play Store steps:**
1. Create account at [play.google.com/console](https://play.google.com/console) ($25 one-time fee)
2. Create new app → "Webond"
3. Upload the `.aab` file from EAS
4. Fill in store listing, screenshots, privacy policy
5. Submit for review (1–3 days)

### Build for iOS (Apple App Store)

```bash
eas build --platform ios --profile production
```

**Apple App Store steps:**
1. Create Apple Developer account at [developer.apple.com](https://developer.apple.com) ($99/year)
2. App Store Connect → New App → "Webond"
3. Upload `.ipa` via EAS submit
4. Fill in metadata, screenshots (required sizes)
5. Submit for review (1–7 days)

### Submit automatically with EAS

```bash
# Submit to both stores at once
eas submit --platform all
```

---

## 💰 COSTS BREAKDOWN

### Free Tier (0–1,000 users)

| Service | Cost |
|---|---|
| Vercel (web hosting) | FREE |
| Render.com (backend) | FREE (sleeps after 15min inactivity) |
| Supabase (database) | FREE (500MB, 2GB bandwidth) |
| Resend (emails) | FREE (3,000 emails/month) |
| Expo (mobile builds) | FREE (limited builds/month) |
| **Total** | **$0/month** |

### Growth Tier (1,000–50,000 users)

| Service | Cost |
|---|---|
| Vercel Pro | $20/month |
| Render Starter | $25/month |
| Supabase Pro | $25/month |
| Resend Pro | $20/month |
| Anthropic Claude API | ~$50/month |
| **Total** | **~$140/month** |

### Scale Tier (50,000+ users)

| Service | Cost |
|---|---|
| AWS/GCP | $200–500/month |
| Supabase Enterprise | $599/month |
| CDN (Cloudflare) | FREE–$20/month |
| **Total** | **~$800–1,200/month** |

---

## 🔒 SECURITY CHECKLIST

Before going public, make sure you:

- [ ] Change JWT_SECRET to a random 64+ character string
- [ ] Change JWT_REFRESH_SECRET to another random string
- [ ] Enable Supabase Row Level Security (already in schema.sql)
- [ ] Add your domain to Supabase → Authentication → URL Configuration
- [ ] Set CORS to only allow your frontend domain in `server.js`
- [ ] Enable 2FA on all service accounts
- [ ] Set up HTTPS (automatic on Vercel + Render)
- [ ] Add rate limiting (already built in)
- [ ] Protect admin dashboard with authentication

---

## 🔧 CUSTOM DOMAIN SETUP

1. Buy `webond.com` at Namecheap (~$10/year)
2. **Vercel** → Settings → Domains → Add `webond.com`
3. **Backend** → On Render, add custom domain `api.webond.com`
4. Update `.env.local`:
   ```
   REACT_APP_API_URL=https://api.webond.com/api
   ```

---

## 📞 SUPPORT & UPDATES

- **GitHub Issues:** Report bugs and request features
- **Updates:** Run `git pull` to get the latest code
- **Community:** Join Webond early access at webond.com

---

Built by **Yushat** — Yusuf Abubakar Yusuf
© 2025 Webond — Connect Beyond 🌍

*"Built from Abuja, Nigeria for the entire world."*
