// src/utils/api.js — Mobile API client with secure token storage
import * as SecureStore from 'expo-secure-store';
import Constants from 'expo-constants';

const BASE = Constants.expoConfig?.extra?.apiUrl || 'http://localhost:5000/api';
const SOCKET_URL = Constants.expoConfig?.extra?.socketUrl || 'http://localhost:5000';

export { SOCKET_URL };

// ── Secure token storage ──
export const storage = {
  get: (k) => SecureStore.getItemAsync(k),
  set: (k, v) => SecureStore.setItemAsync(k, v),
  del: (k) => SecureStore.deleteItemAsync(k),
};

export const getToken = () => storage.get('wb_token');
export const setTokens = async (access, refresh) => {
  await storage.set('wb_token', access);
  await storage.set('wb_refresh', refresh);
};
export const clearTokens = async () => {
  await storage.del('wb_token');
  await storage.del('wb_refresh');
  await storage.del('wb_user');
};

// ── Base fetch with auto-refresh ──
const req = async (path, opts = {}) => {
  const token = await getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...opts.headers,
  };

  let res = await fetch(`${BASE}${path}`, { ...opts, headers });

  if (res.status === 401) {
    const err = await res.json();
    if (err.code === 'TOKEN_EXPIRED') {
      const refresh = await storage.get('wb_refresh');
      if (refresh) {
        const rRes = await fetch(`${BASE}/auth/refresh`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refreshToken: refresh }),
        });
        if (rRes.ok) {
          const { accessToken, refreshToken } = await rRes.json();
          await setTokens(accessToken, refreshToken);
          const newHeaders = { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` };
          res = await fetch(`${BASE}${path}`, { ...opts, headers: newHeaders });
        } else {
          await clearTokens();
          throw new Error('SESSION_EXPIRED');
        }
      }
    }
  }

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
};

export const api = {
  auth: {
    register: (b) => req('/auth/register', { method: 'POST', body: JSON.stringify(b) }),
    verifyOtp: (b) => req('/auth/verify-otp', { method: 'POST', body: JSON.stringify(b) }),
    login: (b) => req('/auth/login', { method: 'POST', body: JSON.stringify(b) }),
    social: (b) => req('/auth/social', { method: 'POST', body: JSON.stringify(b) }),
    logout: async () => {
      const r = await storage.get('wb_refresh');
      await clearTokens();
      return req('/auth/logout', { method: 'POST', body: JSON.stringify({ refreshToken: r }) }).catch(() => {});
    },
    checkUsername: (u) => req(`/auth/check-username/${u}`),
    forgot: (email) => req('/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) }),
    reset: (b) => req('/auth/reset-password', { method: 'POST', body: JSON.stringify(b) }),
  },
  users: {
    me: () => req('/users/me'),
    update: (b) => req('/users/me', { method: 'PATCH', body: JSON.stringify(b) }),
    get: (u) => req(`/users/${u}`),
    posts: (u, page = 1) => req(`/users/${u}/posts?page=${page}`),
    follow: (id) => req(`/users/${id}/follow`, { method: 'POST' }),
    followers: (id) => req(`/users/${id}/followers`),
    following: (id) => req(`/users/${id}/following`),
  },
  posts: {
    feed: (page = 1) => req(`/posts/feed?page=${page}`),
    create: (b) => req('/posts', { method: 'POST', body: JSON.stringify(b) }),
    like: (id) => req(`/posts/${id}/like`, { method: 'POST' }),
    bookmark: (id) => req(`/posts/${id}/bookmark`, { method: 'POST' }),
    comments: (id) => req(`/posts/${id}/comments`),
    addComment: (id, content) => req(`/posts/${id}/comments`, { method: 'POST', body: JSON.stringify({ content }) }),
    delete: (id) => req(`/posts/${id}`, { method: 'DELETE' }),
  },
  messages: {
    conversations: () => req('/messages/conversations'),
    get: (id, page = 1) => req(`/messages/${id}?page=${page}`),
    send: (b) => req('/messages', { method: 'POST', body: JSON.stringify(b) }),
  },
  notifications: {
    get: () => req('/notifications'),
    readAll: () => req('/notifications/read-all', { method: 'PATCH' }),
  },
  ai: {
    chat: (message, history) => req('/ai/chat', { method: 'POST', body: JSON.stringify({ message, history }) }),
    writePost: (topic, tone = 'energetic') => req('/ai/write-post', { method: 'POST', body: JSON.stringify({ topic, tone }) }),
    hashtags: (content) => req('/ai/hashtags', { method: 'POST', body: JSON.stringify({ content }) }),
    summarise: (content) => req('/ai/summarise', { method: 'POST', body: JSON.stringify({ content }) }),
    history: () => req('/ai/history'),
  },
  stories: {
    get: () => req('/stories'),
    create: (b) => req('/stories', { method: 'POST', body: JSON.stringify(b) }),
  },
  search: {
    query: (q, type = 'all') => req(`/search?q=${encodeURIComponent(q)}&type=${type}`),
  },
};
