// src/utils/theme.js
export const Colors = {
  teal: '#00C2A8',
  teal2: '#00A892',
  teal3: '#E6FAF8',
  teal4: '#B3EFE9',
  coral: '#FF6B6B',
  coral2: '#FFF0F0',
  purple: '#8B5CF6',
  purple2: '#EDE9FE',
  amber: '#FFAA00',
  amber2: '#FFF8E7',
  blue: '#3B82F6',
  blue2: '#EFF6FF',
  bg: '#F2F4F8',
  white: '#FFFFFF',
  t1: '#1A1A2E',
  t2: '#5A5A7A',
  t3: '#9A9AB0',
  border: '#E8EAF0',
  dark: '#0a1628',
  dark2: '#0d2d2a',
  success: '#22C55E',
  warning: '#F59E0B',
};

export const Typography = {
  h1: { fontSize: 28, fontWeight: '800', color: Colors.t1, letterSpacing: -0.5 },
  h2: { fontSize: 22, fontWeight: '800', color: Colors.t1, letterSpacing: -0.3 },
  h3: { fontSize: 18, fontWeight: '700', color: Colors.t1 },
  h4: { fontSize: 16, fontWeight: '700', color: Colors.t1 },
  body: { fontSize: 15, fontWeight: '400', color: Colors.t1, lineHeight: 22 },
  bodySmall: { fontSize: 13, fontWeight: '400', color: Colors.t2, lineHeight: 20 },
  caption: { fontSize: 11, fontWeight: '500', color: Colors.t3 },
  label: { fontSize: 12, fontWeight: '700', color: Colors.t2, textTransform: 'uppercase', letterSpacing: 0.6 },
};

export const Spacing = {
  xs: 4, sm: 8, md: 14, lg: 18, xl: 24, xxl: 32,
};

export const Radius = {
  sm: 8, md: 12, lg: 16, xl: 22, full: 9999,
};

export const Shadow = {
  sm: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  md: { shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 12, elevation: 4 },
  teal: { shadowColor: Colors.teal, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.4, shadowRadius: 16, elevation: 8 },
};

export const AvatarColors = {
  'av-g': ['#00C2A8', '#00a892'],
  'av-c': ['#fb923c', '#FF6B6B'],
  'av-p': ['#8B5CF6', '#7C3AED'],
  'av-b': ['#3B82F6', '#2563EB'],
  'av-a': ['#FFAA00', '#F59E0B'],
};
