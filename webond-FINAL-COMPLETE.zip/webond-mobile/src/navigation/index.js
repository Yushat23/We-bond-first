// src/navigation/index.js
import React from 'react';
import { View, Text, TouchableOpacity, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import useStore from '../store/useStore';
import { Colors } from '../utils/theme';

// Auth screens
import SplashScreen from '../screens/auth/SplashScreen';
import WelcomeScreen from '../screens/auth/WelcomeScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import SignupScreen from '../screens/auth/SignupScreen';
import Signup2Screen from '../screens/auth/Signup2Screen';
import Signup3Screen from '../screens/auth/Signup3Screen';
import OTPScreen from '../screens/auth/OTPScreen';
import ForgotScreen from '../screens/auth/ForgotScreen';
import SetupScreen from '../screens/auth/SetupScreen';
import InterestsScreen from '../screens/auth/InterestsScreen';

// App screens
import ProfileScreen from '../screens/main/ProfileScreen';
import FeedScreen from '../screens/main/FeedScreen';
import VideoScreen from '../screens/main/VideoScreen';
import MessagesScreen from '../screens/main/MessagesScreen';
import NotificationsScreen from '../screens/main/NotificationsScreen';
import ChatScreen from '../screens/chat/ChatScreen';
import AIChatScreen from '../screens/chat/AIChatScreen';
import PostDetailScreen from '../screens/main/PostDetailScreen';
import SearchScreen from '../screens/main/SearchScreen';
import SettingsScreen from '../screens/main/SettingsScreen';
import CreatePostScreen from '../screens/main/CreatePostScreen';
import UserProfileScreen from '../screens/main/UserProfileScreen';
import ReelScreen from '../screens/video/ReelScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// ── Tab bar icon ──
const TabIcon = ({ name, focused, badge }) => {
  const icons = {
    Profile:  focused ? '👤' : '👤',
    Home:     focused ? '🏠' : '🏠',
    Reels:    focused ? '🎬' : '🎬',
    Messages: focused ? '💬' : '💬',
    Explore:  focused ? '🔍' : '🔍',
  };
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.45 }}>{icons[name] || '●'}</Text>
      {badge > 0 && (
        <View style={{ position: 'absolute', top: -4, right: -8, minWidth: 16, height: 16, borderRadius: 8, backgroundColor: Colors.coral, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3, borderWidth: 1.5, borderColor: Colors.white }}>
          <Text style={{ fontSize: 9, fontWeight: '800', color: '#fff' }}>{badge > 99 ? '99+' : badge}</Text>
        </View>
      )}
    </View>
  );
};

// ── FAB center button ──
const FABButton = ({ onPress }) => (
  <TouchableOpacity onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); onPress(); }} activeOpacity={0.88}
    style={{ width: 56, height: 56, borderRadius: 18, overflow: 'hidden', marginTop: -10, shadowColor: Colors.teal, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.45, shadowRadius: 14, elevation: 10 }}>
    <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: 26, color: '#fff' }}>+</Text>
    </LinearGradient>
  </TouchableOpacity>
);

// ── Main tab navigator ──
function MainTabs({ navigation }) {
  const { unreadCount } = useStore();

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: true,
        tabBarLabelStyle: { fontSize: 10, fontWeight: '600', marginTop: 2 },
        tabBarStyle: {
          backgroundColor: Colors.white,
          borderTopWidth: 1,
          borderTopColor: Colors.border,
          height: Platform.OS === 'ios' ? 84 : 64,
          paddingBottom: Platform.OS === 'ios' ? 22 : 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: Colors.teal,
        tabBarInactiveTintColor: Colors.t3,
      }}
    >
      <Tab.Screen name="Profile" component={ProfileScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon name="Profile" focused={focused} />, tabBarLabel: 'Profile' }}
      />
      <Tab.Screen name="Home" component={FeedScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon name="Home" focused={focused} />, tabBarLabel: 'Home' }}
      />
      <Tab.Screen name="Create" component={CreatePostScreen}
        options={{
          tabBarLabel: '',
          tabBarIcon: () => null,
          tabBarButton: (props) => <FABButton onPress={() => navigation.navigate('CreatePost')} />,
        }}
      />
      <Tab.Screen name="Messages" component={MessagesScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon name="Messages" focused={focused} badge={unreadCount} />, tabBarLabel: 'Messages' }}
      />
      <Tab.Screen name="Explore" component={SearchScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon name="Explore" focused={focused} />, tabBarLabel: 'Explore' }}
      />
    </Tab.Navigator>
  );
}

// ── Auth stack ──
function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Welcome" component={WelcomeScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Signup" component={SignupScreen} />
      <Stack.Screen name="Signup2" component={Signup2Screen} />
      <Stack.Screen name="Signup3" component={Signup3Screen} />
      <Stack.Screen name="OTP" component={OTPScreen} />
      <Stack.Screen name="Forgot" component={ForgotScreen} />
      <Stack.Screen name="Setup" component={SetupScreen} />
      <Stack.Screen name="Interests" component={InterestsScreen} />
    </Stack.Navigator>
  );
}

// ── App stack (after auth) ──
function AppStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
      <Stack.Screen name="MainTabs" component={MainTabs} />
      <Stack.Screen name="Chat" component={ChatScreen} />
      <Stack.Screen name="AIChat" component={AIChatScreen} />
      <Stack.Screen name="PostDetail" component={PostDetailScreen} />
      <Stack.Screen name="UserProfile" component={UserProfileScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="CreatePost" component={CreatePostScreen} options={{ animation: 'slide_from_bottom', presentation: 'modal' }} />
      <Stack.Screen name="Reel" component={ReelScreen} options={{ animation: 'slide_from_bottom' }} />
      <Stack.Screen name="VideoFeed" component={VideoScreen} />
    </Stack.Navigator>
  );
}

// ── Root navigator ──
export default function Navigation() {
  const { isAuthenticated, isLoading } = useStore();
  if (isLoading) return null;
  return (
    <NavigationContainer>
      {isAuthenticated ? <AppStack /> : <AuthStack />}
    </NavigationContainer>
  );
}
