// src/screens/main/index.js — All main app screens

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, ScrollView, FlatList, TouchableOpacity,
  TextInput, RefreshControl, Image, Alert, Switch,
  KeyboardAvoidingView, Platform, Animated, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import useStore from '../../store/useStore';
import { api } from '../../utils/api';
import { Colors, Typography, Spacing, Shadow, AvatarColors, Radius } from '../../utils/theme';
import { Avatar, Button, IconButton, Card, Header, LikeButton, StoryRing, EmptyState, Toggle, styles as S } from '../../components';

const { width: SW } = Dimensions.get('window');

// ══════════════════════════════
// FEED SCREEN
// ══════════════════════════════
export function FeedScreen({ navigation }) {
  const { posts, loadFeed, likePost, user } = useStore();
  const [refreshing, setRefreshing] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => { loadFeed(1); }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadFeed(1);
    setPage(1);
    setRefreshing(false);
  };

  const loadMore = async () => {
    if (!hasMore) return;
    const next = page + 1;
    const newPosts = await loadFeed(next);
    if (!newPosts?.length) setHasMore(false);
    else setPage(next);
  };

  const renderStories = () => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ backgroundColor: Colors.white, borderBottomWidth: 1, borderBottomColor: Colors.border }} contentContainerStyle={{ padding: 12, gap: 12, flexDirection: 'row' }}>
      <TouchableOpacity onPress={() => Alert.alert('📖', 'Add story — full version!')} style={{ alignItems: 'center', gap: 5 }}>
        <View style={{ width: 62, height: 62, borderRadius: 31, borderWidth: 2, borderStyle: 'dashed', borderColor: Colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.bg }}>
          <Text style={{ fontSize: 22, color: Colors.teal }}>+</Text>
        </View>
        <Text style={{ fontSize: 10, color: Colors.teal, fontWeight: '700' }}>Your story</Text>
      </TouchableOpacity>
      {[{n:'Amira',c:['#B3EFE9','#81d4fa']},{n:'Chidi',c:['#fde68a','#fca5a5']},{n:'Fatima',c:['#c4b5fd','#f9a8d4']},{n:'Emeka',c:['#fbcfe8','#fde68a']},{n:'Ngozi',c:['#86efac','#67e8f9']}].map(s => (
        <TouchableOpacity key={s.n} onPress={() => Alert.alert('👁', `${s.n}'s story`)} style={{ alignItems: 'center', gap: 5 }}>
          <StoryRing size={62}><LinearGradient colors={s.c} style={{ flex: 1 }} /></StoryRing>
          <Text style={{ fontSize: 10, color: Colors.t2, fontWeight: '500' }}>{s.n}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );

  const renderPost = ({ item: p }) => (
    <View style={{ backgroundColor: Colors.white, marginBottom: 8 }}>
      <TouchableOpacity onPress={() => navigation.navigate('PostDetail', { post: p })} activeOpacity={1}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 13, paddingBottom: 9 }}>
          <Avatar user={p.user || p} size={42} />
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: Colors.t1 }}>{p.user?.name || p.username}</Text>
              {p.user?.is_verified && <Text style={{ color: Colors.teal, fontSize: 13 }}>✓</Text>}
              {(p.user?.id || p.userId) === user?.id && <View style={{ backgroundColor: Colors.teal3, paddingHorizontal: 5, paddingVertical: 1, borderRadius: 4 }}><Text style={{ fontSize: 9, fontWeight: '700', color: Colors.teal2 }}>You</Text></View>}
            </View>
            <Text style={{ fontSize: 11, color: Colors.t3, marginTop: 1 }}>
              {p.createdAt ? new Date(p.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Just now'} · 🌍 {p.privacy || 'Public'}
            </Text>
          </View>
          <TouchableOpacity style={{ padding: 6 }}><Text style={{ fontSize: 16, color: Colors.t3 }}>⋯</Text></TouchableOpacity>
        </View>
        <Text style={{ paddingHorizontal: 15, paddingBottom: 10, fontSize: 14, color: Colors.t1, lineHeight: 22 }}>
          {(p.content || '').replace(/(#\w+)/g, '$1')}
        </Text>
        {p.aiSummary && (
          <View style={{ marginHorizontal: 15, marginBottom: 10, padding: 12, backgroundColor: Colors.teal3, borderRadius: 12, borderLeftWidth: 3, borderLeftColor: Colors.teal }}>
            <Text style={{ fontSize: 11, fontWeight: '700', color: Colors.teal2, marginBottom: 3 }}>🤖 Webond AI summary</Text>
            <Text style={{ fontSize: 12, color: Colors.t2, lineHeight: 18 }}>{p.aiSummary}</Text>
          </View>
        )}
        {p.mediaUrls?.length > 0 && (
          <View style={{ flexDirection: p.mediaUrls.length > 1 ? 'row' : undefined, gap: 2 }}>
            {p.mediaUrls.slice(0, 3).map((url, i) => (
              <View key={i} style={{ flex: p.mediaUrls.length > 1 ? 1 : undefined, height: p.mediaUrls.length > 1 ? 160 : 220, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontSize: 40 }}>🖼️</Text>
              </View>
            ))}
          </View>
        )}
      </TouchableOpacity>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 4 }}>
        <LikeButton liked={p.isLiked} count={p.likeCount || p.likes || 0} onPress={() => likePost(p.id)} />
        <TouchableOpacity onPress={() => navigation.navigate('PostDetail', { post: p })} style={{ flexDirection: 'row', alignItems: 'center', gap: 5, padding: 7 }}>
          <Text style={{ fontSize: 17 }}>💬</Text>
          <Text style={{ fontSize: 12, fontWeight: '600', color: Colors.t3 }}>{p.commentCount || p.comments || 0}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => { Haptics.selectionAsync(); Alert.alert('🔗', 'Link copied!'); }} style={{ flexDirection: 'row', alignItems: 'center', gap: 5, padding: 7 }}>
          <Text style={{ fontSize: 17 }}>🔗</Text>
          <Text style={{ fontSize: 12, fontWeight: '600', color: Colors.t3 }}>Share</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{ marginLeft: 'auto', padding: 7 }} onPress={() => api.posts.bookmark(p.id).catch(() => {})}>
          <Text style={{ fontSize: 17 }}>{p.isBookmarked ? '🔖' : '🏷️'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={S.screen} edges={['top']}>
      <View style={{ backgroundColor: Colors.white, paddingHorizontal: Spacing.lg, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <Text style={{ fontSize: 22, fontWeight: '900', letterSpacing: -1, color: Colors.t1 }}>
          web<Text style={{ color: Colors.teal }}>ond</Text>
        </Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <IconButton badge onPress={() => {}}><Text style={{ fontSize: 18 }}>🔔</Text></IconButton>
          <IconButton badge onPress={() => navigation.navigate('Messages')}><Text style={{ fontSize: 18 }}>💬</Text></IconButton>
        </View>
      </View>
      <FlatList
        data={posts}
        keyExtractor={i => i.id}
        renderItem={renderPost}
        ListHeaderComponent={() => (
          <>
            {renderStories()}
            <TouchableOpacity onPress={() => navigation.navigate('AIChat')} style={{ margin: 14, borderRadius: 14, overflow: 'hidden' }}>
              <LinearGradient colors={[Colors.teal, Colors.teal2]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ padding: 14, flexDirection: 'row', alignItems: 'center', gap: 11 }}>
                <View style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,.2)', alignItems: 'center', justifyContent: 'center' }}>
                  <Text style={{ fontSize: 17 }}>⚡</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 13, fontWeight: '700', color: '#fff' }}>Webond AI Brief</Text>
                  <Text style={{ fontSize: 12, color: 'rgba(255,255,255,.75)', marginTop: 1 }}>6 trending topics in your network ✨</Text>
                </View>
                <Text style={{ color: 'rgba(255,255,255,.7)', fontSize: 16 }}>›</Text>
              </LinearGradient>
            </TouchableOpacity>
          </>
        )}
        ListEmptyComponent={() => <EmptyState emoji="📭" title="No posts yet" subtitle="Follow people or create your first post!" />}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.teal} />}
        onEndReached={loadMore}
        onEndReachedThreshold={0.5}
        contentContainerStyle={{ paddingBottom: 90 }}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

// ══════════════════════════════
// PROFILE SCREEN
// ══════════════════════════════
export function ProfileScreen({ navigation }) {
  const { user, avClass, logout } = useStore();
  const [posts, setPosts] = useState([]);
  const [activeTab, setActiveTab] = useState('All');
  const initial = (user?.name || 'Y')[0].toUpperCase();
  const avColors = AvatarColors[avClass] || AvatarColors['av-g'];

  useEffect(() => {
    if (user?.username) {
      api.users.posts(user.username).then(({ posts }) => setPosts(posts || [])).catch(() => {});
    }
  }, [user]);

  const tabs = ['All', 'Posts', 'Media', 'Videos', 'Reels'];

  return (
    <SafeAreaView style={S.screen} edges={['top']}>
      <View style={{ backgroundColor: Colors.white, paddingHorizontal: Spacing.lg, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <Text style={Typography.h3}>Profile</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <IconButton onPress={() => {}}><Text style={{ fontSize: 18 }}>🔍</Text></IconButton>
          <IconButton onPress={() => navigation.navigate('Settings')}><Text style={{ fontSize: 18 }}>⚙️</Text></IconButton>
        </View>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 90 }}>
        {/* Profile info */}
        <View style={{ backgroundColor: Colors.white, padding: 18, flexDirection: 'row', gap: 14, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
          <View style={{ position: 'relative' }}>
            <LinearGradient colors={avColors} style={{ width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: Colors.white }}>
              <Text style={{ fontSize: 26, fontWeight: '800', color: '#fff' }}>{initial}</Text>
            </LinearGradient>
            <TouchableOpacity onPress={() => Alert.alert('📷', 'Change photo — full version!')} style={{ position: 'absolute', bottom: 0, right: 0, width: 22, height: 22, borderRadius: 11, backgroundColor: Colors.teal, borderWidth: 2, borderColor: Colors.white, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: '#fff', fontSize: 12 }}>+</Text>
            </TouchableOpacity>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 16, fontWeight: '700', color: Colors.t1, marginBottom: 2 }}>{user?.name || 'Yushat'}</Text>
            <Text style={{ fontSize: 12, color: Colors.teal, fontWeight: '500', marginBottom: 6 }}>@{user?.username || 'yushat'} · Webond Founder</Text>
            <Text style={{ fontSize: 13, color: Colors.t2, lineHeight: 19 }} numberOfLines={3}>{user?.bio || 'Building the future of social media from Abuja, Nigeria 🇳🇬 | Tech founder | AI enthusiast'}</Text>
          </View>
        </View>
        {/* Stats */}
        <View style={{ backgroundColor: Colors.white, flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
          {[['126', 'Following', Colors.teal], null, ['30', 'Stars', Colors.t1], null, ['48.9k', 'Followers', Colors.teal]].map((s, i) =>
            !s ? <View key={i} style={{ width: 1, height: 30, backgroundColor: Colors.border, marginHorizontal: 8 }} />
            : <View key={i} style={{ flex: 1, alignItems: 'center' }}>
                <Text style={{ fontSize: 17, fontWeight: '800', color: s[2] }}>{s[0]}</Text>
                <Text style={{ fontSize: 11, color: Colors.t3, fontWeight: '500', marginTop: 1 }}>{s[1]}</Text>
              </View>
          )}
        </View>
        {/* Action buttons */}
        <View style={{ backgroundColor: Colors.white, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 12, gap: 20, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
          {[['❤️','Like',() => Alert.alert('❤️','Liked!')],['💬','Message',() => navigation.navigate('AIChat')],['⭐','Stars',() => Alert.alert('⭐','Added!')]].map(([ic,lb,fn]) => (
            <TouchableOpacity key={lb} onPress={fn} style={{ flex: 1, alignItems: 'center', gap: 5 }}>
              <View style={{ width: 42, height: 42, borderRadius: 13, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontSize: 20 }}>{ic}</Text>
              </View>
              <Text style={{ fontSize: 11, color: Colors.t2, fontWeight: '600' }}>{lb}</Text>
            </TouchableOpacity>
          ))}
        </View>
        {/* Feed button */}
        <TouchableOpacity onPress={() => navigation.navigate('Home')} style={{ margin: 14, borderRadius: 14, overflow: 'hidden' }}>
          <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ paddingVertical: 13, alignItems: 'center' }}>
            <Text style={{ color: '#fff', fontSize: 14, fontWeight: '700' }}>🏠 Home feed</Text>
          </LinearGradient>
        </TouchableOpacity>
        {/* Tabs */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingHorizontal: 14, marginBottom: 12 }} contentContainerStyle={{ gap: 10 }}>
          {tabs.map(t => (
            <TouchableOpacity key={t} onPress={() => setActiveTab(t)} style={{ paddingHorizontal: 16, paddingVertical: 7, borderRadius: 22, backgroundColor: activeTab === t ? Colors.teal : Colors.white, borderWidth: activeTab === t ? 0 : 1, borderColor: Colors.border }}>
              <Text style={{ fontSize: 12, fontWeight: '600', color: activeTab === t ? '#fff' : Colors.t2 }}>{t}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        {/* Media grid */}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 2 }}>
          {[['🌅','#E6FAF8','#B3EFE9'],['🚀','#FFF8E7','#FFE5A0'],['💻','#EDE9FE','#DDD6FE'],['🎵','#FFF0F0','#FFD6D6'],['🌍','#EFF6FF','#BFDBFE'],['🏙️','#F0FDF4','#BBF7D0']].map(([em,c1,c2],i) => (
            <TouchableOpacity key={i} style={{ width: (SW - 4) / 3, aspectRatio: 1 }}>
              <LinearGradient colors={[c1,c2]} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontSize: 32 }}>{em}</Text>
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ══════════════════════════════
// MESSAGES SCREEN
// ══════════════════════════════
export function MessagesScreen({ navigation }) {
  const { conversations, loadConversations } = useStore();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadConversations(); }, []);

  const onRefresh = async () => { setRefreshing(true); await loadConversations(); setRefreshing(false); };

  const demoConvs = [
    { id: 'ai', name: 'Webond AI', avatar: '🤖', lastMessage: 'Ask me anything — always online!', time: 'Now', unread: 0, isAI: true, online: true },
    { id: 'c1', name: 'Amira Hassan', avatarColors: ['#B3EFE9','#06b6d4'], lastMessage: "Can't wait for the Webond launch! 🚀", time: 'Just now', unread: 2, online: true },
    { id: 'c2', name: 'Tech_Chidi', avatarColors: ['#fde68a','#fb923c'], lastMessage: 'Bro send me the invite link!', time: '2m', unread: 3, online: true },
    { id: 'c3', name: 'Fatima Umar', avatarColors: ['#c4b5fd','#f9a8d4'], lastMessage: 'Sent you a photo 📸', time: '15m', unread: 1, online: false },
    { id: 'c4', name: 'Ngozi Creates', avatarColors: ['#86efac','#67e8f9'], lastMessage: '🎵 Sent an audio clip', time: '3h', unread: 0, online: true },
  ];

  const renderItem = ({ item: c }) => (
    <TouchableOpacity onPress={() => navigation.navigate(c.isAI ? 'AIChat' : 'Chat', { conversation: c })} activeOpacity={0.85}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 18, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.white }}>
      <View style={{ position: 'relative' }}>
        {c.isAI ? (
          <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ width: 50, height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 24 }}>{c.avatar}</Text>
          </LinearGradient>
        ) : (
          <LinearGradient colors={c.avatarColors || [Colors.teal, Colors.teal2]} style={{ width: 50, height: 50, borderRadius: 25 }} />
        )}
        {c.online && <View style={{ position: 'absolute', bottom: 1, right: 1, width: 12, height: 12, borderRadius: 6, backgroundColor: Colors.success, borderWidth: 2, borderColor: Colors.bg }} />}
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={{ fontSize: 14, fontWeight: '600', color: c.isAI ? Colors.teal2 : Colors.t1, marginBottom: 2 }}>{c.name}</Text>
        <Text style={{ fontSize: 13, color: c.unread > 0 ? Colors.t1 : Colors.t3, fontWeight: c.unread > 0 ? '600' : '400' }} numberOfLines={1}>{c.lastMessage}</Text>
      </View>
      <View style={{ alignItems: 'flex-end', gap: 5 }}>
        <Text style={{ fontSize: 11, color: Colors.t3 }}>{c.time}</Text>
        {c.unread > 0 && <View style={{ minWidth: 20, height: 20, borderRadius: 10, backgroundColor: Colors.coral, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 }}><Text style={{ fontSize: 10, fontWeight: '800', color: '#fff' }}>{c.unread}</Text></View>}
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={S.screen} edges={['top']}>
      <Header title="Messages" right={[<IconButton key="s"><Text style={{ fontSize: 18 }}>🔍</Text></IconButton>, <IconButton key="e"><Text style={{ fontSize: 18 }}>✏️</Text></IconButton>]} />
      {/* Online bar */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ backgroundColor: Colors.bg, maxHeight: 80 }} contentContainerStyle={{ padding: 12, gap: 14, flexDirection: 'row', alignItems: 'center' }}>
        {demoConvs.filter(c => c.online && !c.isAI).map(c => (
          <TouchableOpacity key={c.id} onPress={() => navigation.navigate('Chat', { conversation: c })} style={{ alignItems: 'center', gap: 4 }}>
            <View style={{ position: 'relative' }}>
              <LinearGradient colors={c.avatarColors || [Colors.teal, Colors.teal2]} style={{ width: 46, height: 46, borderRadius: 23 }} />
              <View style={{ position: 'absolute', bottom: 0, right: 0, width: 11, height: 11, borderRadius: 6, backgroundColor: Colors.success, borderWidth: 2, borderColor: Colors.bg }} />
            </View>
            <Text style={{ fontSize: 10, color: Colors.t2, fontWeight: '500' }}>{c.name.split(' ')[0]}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <FlatList
        data={demoConvs}
        keyExtractor={i => i.id}
        renderItem={renderItem}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.teal} />}
        contentContainerStyle={{ paddingBottom: 90 }}
        showsVerticalScrollIndicator={false}
        style={{ backgroundColor: Colors.white }}
      />
    </SafeAreaView>
  );
}

// ══════════════════════════════
// SEARCH SCREEN
// ══════════════════════════════
export function SearchScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState({ users: [], posts: [], hashtags: [] });
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('All');
  const trending = ['#Webond','#NaijaTech','#AfricaTech','#AbujaLife','#Lagos','#AIFirst'];

  const doSearch = useCallback(async (q) => {
    if (!q || q.length < 2) { setResults({ users: [], posts: [], hashtags: [] }); return; }
    setLoading(true);
    try {
      const { results: r } = await api.search.query(q);
      setResults(r);
    } catch (e) {
      setResults({
        users: [{ id: '1', name: 'Amira Hassan', username: 'amira_h', avatar_class: 'av-g', follower_count: 12400, is_verified: false }],
        posts: [], hashtags: [{ tag: 'Webond', count: 2400 }],
      });
    } finally { setLoading(false); }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => doSearch(query), 350);
    return () => clearTimeout(t);
  }, [query]);

  return (
    <SafeAreaView style={S.screen} edges={['top']}>
      <View style={{ backgroundColor: Colors.white, padding: Spacing.lg, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.bg, borderRadius: Radius.md, paddingHorizontal: 14, paddingVertical: 11 }}>
          <Text style={{ fontSize: 16, color: Colors.t3 }}>🔍</Text>
          <TextInput value={query} onChangeText={setQuery} placeholder="Search Webond..." placeholderTextColor={Colors.t3} style={{ flex: 1, fontSize: 15, color: Colors.t1 }} autoCapitalize="none" returnKeyType="search" />
          {query.length > 0 && <TouchableOpacity onPress={() => setQuery('')}><Text style={{ fontSize: 16, color: Colors.t3 }}>✕</Text></TouchableOpacity>}
        </View>
      </View>
      <ScrollView contentContainerStyle={{ paddingBottom: 90 }}>
        {!query ? (
          <View style={{ padding: Spacing.lg }}>
            <Text style={[Typography.label, { marginBottom: 12 }]}>Trending on Webond</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 9 }}>
              {trending.map(t => (
                <TouchableOpacity key={t} onPress={() => setQuery(t)} style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: Colors.teal3, borderWidth: 1, borderColor: Colors.teal4 }}>
                  <Text style={{ fontSize: 13, fontWeight: '600', color: Colors.teal2 }}>{t}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ) : (
          <View style={{ padding: Spacing.lg }}>
            {loading && <Text style={{ color: Colors.t3, textAlign: 'center', marginBottom: 12 }}>Searching...</Text>}
            {results.users?.map(u => (
              <TouchableOpacity key={u.id} onPress={() => navigation.navigate('UserProfile', { username: u.username })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
                <Avatar user={u} size={44} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 14, fontWeight: '600', color: Colors.t1 }}>{u.name} {u.is_verified && '✓'}</Text>
                  <Text style={{ fontSize: 12, color: Colors.t3 }}>@{u.username} · {u.follower_count?.toLocaleString()} followers</Text>
                </View>
                <TouchableOpacity onPress={() => api.users.follow(u.id).catch(() => {})} style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: Colors.teal3, borderWidth: 1, borderColor: Colors.teal4 }}>
                  <Text style={{ fontSize: 12, fontWeight: '700', color: Colors.teal2 }}>Follow</Text>
                </TouchableOpacity>
              </TouchableOpacity>
            ))}
            {results.hashtags?.map(h => (
              <TouchableOpacity key={h.tag} onPress={() => setQuery('#' + h.tag)} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
                <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
                  <Text style={{ fontSize: 18, color: Colors.teal }}>＃</Text>
                </View>
                <View>
                  <Text style={{ fontSize: 14, fontWeight: '600', color: Colors.t1 }}>#{h.tag}</Text>
                  <Text style={{ fontSize: 12, color: Colors.t3 }}>{h.count?.toLocaleString()} posts</Text>
                </View>
              </TouchableOpacity>
            ))}
            {!loading && !results.users?.length && !results.hashtags?.length && (
              <EmptyState emoji="🔍" title="No results" subtitle={`Nothing found for "${query}"`} />
            )}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// ══════════════════════════════
// CREATE POST SCREEN
// ══════════════════════════════
export function CreatePostScreen({ navigation }) {
  const { user, avClass, addPost } = useStore();
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiWriting, setAiWriting] = useState(false);
  const initial = (user?.name || 'Y')[0].toUpperCase();
  const avColors = AvatarColors[avClass] || AvatarColors['av-g'];

  const handlePost = async () => {
    if (!text.trim()) { Alert.alert('⚠️', 'Write something first!'); return; }
    setLoading(true);
    try {
      const { post } = await api.posts.create({ content: text.trim() });
      addPost(post);
      Alert.alert('✅', 'Posted to Webond!');
      navigation.goBack();
    } catch (err) {
      Alert.alert('Failed', err.message);
    } finally { setLoading(false); }
  };

  const handleAIWrite = async () => {
    setAiWriting(true);
    try {
      const { post } = await api.ai.writePost('Webond social platform launch from Nigeria', 'energetic');
      setText(post || "Building the future from Nigeria 🇳🇬 Join Webond and connect beyond limits! 🚀 #Webond #Africa");
    } catch {
      setText("Just launched something amazing — Webond is LIVE! 🚀 The social platform built for Africa and the world. Join us today! #Webond #Africa #Tech");
    } finally { setAiWriting(false); }
  };

  const tools = [
    { icon: '📷', label: 'Photo', action: () => Alert.alert('📷', 'Photo — full version!') },
    { icon: '🎬', label: 'Video', action: () => Alert.alert('🎬', 'Video — full version!') },
    { icon: '⚡', label: 'AI Write', action: handleAIWrite },
    { icon: '📍', label: 'Location', action: () => Alert.alert('📍', 'Location — full version!') },
    { icon: '😊', label: 'GIF', action: () => Alert.alert('😊', 'GIF — full version!') },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }} edges={['top']}>
      <View style={{ paddingHorizontal: 18, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={{ fontSize: 16, color: Colors.t2 }}>Cancel</Text></TouchableOpacity>
        <Text style={{ fontSize: 16, fontWeight: '700', color: Colors.t1 }}>New post</Text>
        <Button label="Post" onPress={handlePost} loading={loading} style={{ paddingVertical: 9, paddingHorizontal: 20 }} />
      </View>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <View style={{ flex: 1, padding: 18 }}>
          <View style={{ flexDirection: 'row', gap: 12, marginBottom: 14 }}>
            <LinearGradient colors={avColors} style={{ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontWeight: '800', color: '#fff', fontSize: 15 }}>{initial}</Text>
            </LinearGradient>
            <View>
              <Text style={{ fontSize: 14, fontWeight: '700', color: Colors.t1 }}>{user?.name || 'Yushat'}</Text>
              <View style={{ paddingHorizontal: 9, paddingVertical: 3, borderRadius: 12, backgroundColor: Colors.teal3, marginTop: 3 }}>
                <Text style={{ fontSize: 10, fontWeight: '600', color: Colors.teal2 }}>🌍 Everyone</Text>
              </View>
            </View>
          </View>
          <TextInput
            value={aiWriting ? 'AI is writing...' : text}
            onChangeText={setText}
            placeholder="What's on your mind?"
            placeholderTextColor={Colors.t3}
            multiline
            style={{ flex: 1, fontSize: 16, color: Colors.t1, textAlignVertical: 'top', lineHeight: 24 }}
            editable={!aiWriting}
          />
        </View>
        <View style={{ borderTopWidth: 1, borderTopColor: Colors.border, paddingVertical: 10, paddingHorizontal: 14 }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {tools.map(t => (
              <TouchableOpacity key={t.label} onPress={t.action} style={{ alignItems: 'center', gap: 5, paddingHorizontal: 14, paddingVertical: 10, borderRadius: Radius.md, borderWidth: 1.5, borderStyle: 'dashed', borderColor: Colors.border }}>
                <Text style={{ fontSize: 20 }}>{t.icon}</Text>
                <Text style={{ fontSize: 11, color: Colors.t2, fontWeight: '500' }}>{t.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ══════════════════════════════
// SETTINGS SCREEN
// ══════════════════════════════
export function SettingsScreen({ navigation }) {
  const { user, avClass, logout } = useStore();
  const [notifs, setNotifs] = useState(true);
  const [dark, setDark] = useState(false);
  const [ai, setAi] = useState(true);
  const initial = (user?.name || 'Y')[0].toUpperCase();
  const avColors = AvatarColors[avClass] || AvatarColors['av-g'];

  const Section = ({ title, children }) => (
    <View style={{ marginTop: 14 }}>
      <Text style={[Typography.label, { marginHorizontal: 18, marginBottom: 7 }]}>{title}</Text>
      <View style={{ backgroundColor: Colors.white, borderRadius: Radius.lg, overflow: 'hidden', marginHorizontal: 14, ...Shadow.sm }}>
        {children}
      </View>
    </View>
  );

  const Item = ({ icon, label, sub, right, onPress, danger }) => (
    <TouchableOpacity onPress={onPress} activeOpacity={onPress ? 0.85 : 1} style={{ flexDirection: 'row', alignItems: 'center', gap: 13, padding: 14, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
      <View style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: danger ? Colors.coral2 : Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ fontSize: 17 }}>{icon}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontWeight: '600', color: danger ? Colors.coral : Colors.t1 }}>{label}</Text>
        {sub && <Text style={{ fontSize: 12, color: Colors.t3, marginTop: 1 }}>{sub}</Text>}
      </View>
      {right}
    </TouchableOpacity>
  );

  const handleLogout = () => {
    Alert.alert('Log out', 'Are you sure you want to log out of Webond?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log out', style: 'destructive', onPress: logout },
    ]);
  };

  return (
    <SafeAreaView style={S.screen} edges={['top']}>
      <Header title="Settings" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ paddingBottom: 90 }}>
        {/* Profile card */}
        <TouchableOpacity style={{ backgroundColor: Colors.white, padding: 18, flexDirection: 'row', alignItems: 'center', gap: 13, borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: 6 }}>
          <LinearGradient colors={avColors} style={{ width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: '#fff' }}>{initial}</Text>
          </LinearGradient>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 16, fontWeight: '700', color: Colors.t1 }}>{user?.name || 'Yushat'}</Text>
            <Text style={{ fontSize: 12, color: Colors.teal, fontWeight: '500', marginTop: 2 }}>@{user?.username || 'yushat'}</Text>
            <Text style={{ fontSize: 11, color: Colors.t3, marginTop: 1 }}>{user?.email || 'you@example.com'}</Text>
          </View>
          <LinearGradient colors={avColors} style={{ width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontWeight: '800', color: '#fff' }}>{initial}</Text>
          </LinearGradient>
        </TouchableOpacity>

        <Section title="Account">
          <Item icon="👤" label="Edit profile" sub="Name, bio, photo" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => Alert.alert('✏️', 'Edit profile — full version!')} />
          <Item icon="📱" label="Phone number" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => {}} />
          <Item icon="📧" label="Email address" sub={user?.email || 'you@example.com'} right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => {}} />
        </Section>

        <Section title="Privacy & Safety">
          <Item icon="🔒" label="Privacy" sub="Who can see your content" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => {}} />
          <Item icon="🛡️" label="Security" sub="2FA, login activity" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => {}} />
          <Item icon="🚫" label="Blocked accounts" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => {}} />
        </Section>

        <Section title="Preferences">
          <Item icon="🔔" label="Notifications" right={<Toggle value={notifs} onChange={setNotifs} />} />
          <Item icon="🌙" label="Dark mode" right={<Toggle value={dark} onChange={(v) => { setDark(v); Alert.alert(v ? '🌙 Dark mode' : '☀️ Light mode', 'Full theming — coming in v2!'); }} />} />
          <Item icon="🌐" label="Language" sub="English" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => {}} />
          <Item icon="⚡" label="Webond AI" sub={ai ? 'Smart assistant enabled' : 'Disabled'} right={<Toggle value={ai} onChange={setAi} />} />
        </Section>

        <Section title="Creator Tools">
          <Item icon="💰" label="Monetisation" sub="Tips, subscriptions, brand deals" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => Alert.alert('💰', 'Monetisation — coming in v2!')} />
          <Item icon="📊" label="Analytics" sub="Impressions, reach, engagement" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => Alert.alert('📊', 'Analytics — coming in v2!')} />
        </Section>

        <Section title="Support">
          <Item icon="❓" label="Help Center" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => {}} />
          <Item icon="📄" label="Terms & Privacy" right={<Text style={{ color: Colors.t3, fontSize: 16 }}>›</Text>} onPress={() => {}} />
        </Section>

        <Section title="Account actions">
          <Item icon="🚪" label="Log out" danger onPress={handleLogout} />
        </Section>

        <View style={{ padding: 20, alignItems: 'center' }}>
          <Text style={{ fontSize: 12, color: Colors.t3 }}>Webond v1.0.0 · Made with ❤️ by Yushat</Text>
          <Text style={{ fontSize: 11, color: Colors.t3, marginTop: 4 }}>© 2025 Webond. All rights reserved.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ══════════════════════════════
// USER PROFILE SCREEN
// ══════════════════════════════
export function UserProfileScreen({ navigation, route }) {
  const { username } = route.params || {};
  const [profile, setProfile] = useState(null);
  const [following, setFollowing] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (username) {
      api.users.get(username).then(({ user }) => { setProfile(user); setFollowing(user.isFollowing); setLoading(false); }).catch(() => setLoading(false));
    }
  }, [username]);

  if (loading) return <SafeAreaView style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.white }}><Text style={{ fontSize: 32 }}>⏳</Text></SafeAreaView>;
  if (!profile) return <SafeAreaView style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.white }}><Text>User not found</Text></SafeAreaView>;

  const handleFollow = async () => {
    try { await api.users.follow(profile.id); setFollowing(!following); } catch (e) {}
  };

  return (
    <SafeAreaView style={S.screen} edges={['top']}>
      <Header title={profile.username} onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ paddingBottom: 90 }}>
        <View style={{ backgroundColor: Colors.white, padding: 18, alignItems: 'center', borderBottomWidth: 1, borderBottomColor: Colors.border }}>
          <Avatar user={profile} size={80} style={{ marginBottom: 12 }} />
          <Text style={{ fontSize: 20, fontWeight: '800', color: Colors.t1 }}>{profile.name} {profile.is_verified && <Text style={{ color: Colors.teal }}>✓</Text>}</Text>
          <Text style={{ fontSize: 13, color: Colors.teal, fontWeight: '500', marginTop: 2 }}>@{profile.username}</Text>
          {profile.bio && <Text style={{ fontSize: 14, color: Colors.t2, textAlign: 'center', marginTop: 10, lineHeight: 20 }}>{profile.bio}</Text>}
          <View style={{ flexDirection: 'row', gap: 32, marginTop: 16 }}>
            {[[(profile.follower_count || 0).toLocaleString(), 'Followers'],[(profile.following_count || 0).toLocaleString(), 'Following'],[(profile.post_count || 0).toLocaleString(), 'Posts']].map(([n, l]) => (
              <View key={l} style={{ alignItems: 'center' }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: Colors.t1 }}>{n}</Text>
                <Text style={{ fontSize: 11, color: Colors.t3, marginTop: 1 }}>{l}</Text>
              </View>
            ))}
          </View>
          <TouchableOpacity onPress={handleFollow} style={{ marginTop: 16, paddingHorizontal: 40, paddingVertical: 11, borderRadius: 22, backgroundColor: following ? Colors.bg : Colors.teal, borderWidth: 1.5, borderColor: following ? Colors.border : Colors.teal }}>
            <Text style={{ fontSize: 14, fontWeight: '700', color: following ? Colors.t1 : '#fff' }}>{following ? 'Following' : '+ Follow'}</Text>
          </TouchableOpacity>
        </View>
        <EmptyState emoji="📸" title="No posts yet" subtitle="This user hasn't posted anything yet." />
      </ScrollView>
    </SafeAreaView>
  );
}

// ══════════════════════════════
// POST DETAIL SCREEN
// ══════════════════════════════
export function PostDetailScreen({ navigation, route }) {
  const { post } = route.params || {};
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const { likePost, user } = useStore();

  useEffect(() => {
    if (post?.id) api.posts.comments(post.id).then(({ comments }) => setComments(comments || [])).catch(() => {});
  }, [post?.id]);

  const handleComment = async () => {
    if (!newComment.trim()) return;
    setLoading(true);
    try {
      const { comment } = await api.posts.addComment(post.id, newComment.trim());
      setComments(p => [comment, ...p]);
      setNewComment('');
    } catch (e) {} finally { setLoading(false); }
  };

  if (!post) return null;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.bg }} edges={['top']}>
      <Header title="Post" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
          <View style={{ backgroundColor: Colors.white, marginBottom: 8 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 13 }}>
              <Avatar user={post.user || post} size={42} />
              <View>
                <Text style={{ fontSize: 14, fontWeight: '600', color: Colors.t1 }}>{post.user?.name || post.username}</Text>
                <Text style={{ fontSize: 11, color: Colors.t3 }}>{new Date(post.createdAt || Date.now()).toLocaleDateString()}</Text>
              </View>
            </View>
            <Text style={{ paddingHorizontal: 15, paddingBottom: 12, fontSize: 15, color: Colors.t1, lineHeight: 23 }}>{post.content}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 6, borderTopWidth: 1, borderTopColor: Colors.border }}>
              <LikeButton liked={post.isLiked} count={post.likeCount || 0} onPress={() => likePost(post.id)} />
              <Text style={{ marginLeft: 8, fontSize: 12, color: Colors.t3 }}>{post.commentCount || comments.length} comments</Text>
            </View>
          </View>
          {comments.map(c => (
            <View key={c.id} style={{ backgroundColor: Colors.white, marginBottom: 2, padding: 13, flexDirection: 'row', gap: 10 }}>
              <Avatar user={c.user} size={36} />
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13, fontWeight: '600', color: Colors.t1 }}>{c.user?.name}</Text>
                <Text style={{ fontSize: 14, color: Colors.t1, marginTop: 3, lineHeight: 20 }}>{c.content}</Text>
                <Text style={{ fontSize: 11, color: Colors.t3, marginTop: 4 }}>{new Date(c.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
              </View>
            </View>
          ))}
          {comments.length === 0 && <EmptyState emoji="💬" title="No comments yet" subtitle="Be the first to comment!" />}
        </ScrollView>
        <View style={{ backgroundColor: Colors.white, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, borderTopColor: Colors.border }}>
          <Avatar user={user} size={36} />
          <TextInput value={newComment} onChangeText={setNewComment} placeholder="Add a comment..." placeholderTextColor={Colors.t3} style={{ flex: 1, backgroundColor: Colors.bg, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, color: Colors.t1 }} returnKeyType="send" onSubmitEditing={handleComment} />
          <TouchableOpacity onPress={handleComment} disabled={loading} style={{ backgroundColor: Colors.teal, width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#fff', fontSize: 16 }}>→</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ══════════════════════════════
// NOTIFICATIONS SCREEN
// ══════════════════════════════
export function NotificationsScreen({ navigation }) {
  const { notifications, loadNotifications } = useStore();
  useEffect(() => { loadNotifications(); }, []);
  const demo = [
    { id: '1', type: 'like', actor: { name: 'Amira Hassan' }, content: 'liked your post', time: '2m', emoji: '❤️' },
    { id: '2', type: 'comment', actor: { name: 'Tech_Chidi' }, content: 'commented: "This is amazing!"', time: '15m', emoji: '💬' },
    { id: '3', type: 'follow', actor: { name: 'Ngozi Creates' }, content: 'started following you', time: '1h', emoji: '👤' },
    { id: '4', type: 'mention', actor: { name: 'Fatima Umar' }, content: 'mentioned you in a post', time: '3h', emoji: '🔔' },
  ];
  return (
    <SafeAreaView style={S.screen} edges={['top']}>
      <Header title="Notifications" />
      <FlatList data={notifications.length > 0 ? notifications : demo} keyExtractor={i => i.id}
        renderItem={({ item }) => (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.white }}>
            <View style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 22 }}>{item.emoji || '🔔'}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, color: Colors.t1, lineHeight: 20 }}><Text style={{ fontWeight: '700' }}>{item.actor?.name || 'Someone'}</Text> {item.content}</Text>
              <Text style={{ fontSize: 11, color: Colors.t3, marginTop: 3 }}>{item.time}</Text>
            </View>
          </View>
        )}
        contentContainerStyle={{ paddingBottom: 90 }}
        ListEmptyComponent={() => <EmptyState emoji="🔔" title="No notifications" subtitle="You're all caught up!" />}
      />
    </SafeAreaView>
  );
}
