// src/screens/chat/ChatScreen.js
import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, FlatList, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { api } from '../../utils/api';
import { Colors, Spacing, Radius, Shadow, AvatarColors } from '../../utils/theme';
import { Avatar, Header } from '../../components';
import useStore from '../../store/useStore';

export function ChatScreen({ navigation, route }) {
  const { conversation } = route.params || {};
  const { user } = useStore();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const flatRef = useRef(null);

  useEffect(() => {
    if (conversation?.id && conversation.id !== 'ai') {
      setLoading(true);
      api.messages.get(conversation.id)
        .then(({ messages: msgs }) => setMessages(msgs || []))
        .catch(() => setMessages([
          { id: '1', sender_id: 'other', content: `Hey! I'm ${conversation.name} 👋`, created_at: new Date(Date.now() - 60000).toISOString() },
          { id: '2', sender_id: user?.id, content: 'Hey! What\'s up?', created_at: new Date(Date.now() - 30000).toISOString() },
          { id: '3', sender_id: 'other', content: 'Have you seen Webond? It looks incredible! 🚀', created_at: new Date().toISOString() },
        ]))
        .finally(() => setLoading(false));
    }
  }, [conversation?.id]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const tempMsg = { id: Date.now().toString(), sender_id: user?.id, content: text, created_at: new Date().toISOString(), pending: true };
    setMessages(p => [...p, tempMsg]);
    setInput('');
    setSending(true);
    try {
      await api.messages.send({ recipientId: conversation?.otherUser?.id || 'demo', content: text });
      setMessages(p => p.map(m => m.id === tempMsg.id ? { ...m, pending: false } : m));
      // Simulate reply after delay
      setTimeout(() => {
        const replies = ['That\'s great! 🙌', 'Amazing! Can\'t wait to see it 🚀', 'Tell me more about Webond!', 'You\'re building something incredible Yushat! 🌍', 'Africa\'s future is bright thanks to you! 💪'];
        const reply = { id: (Date.now() + 1).toString(), sender_id: 'other', content: replies[Math.floor(Math.random() * replies.length)], created_at: new Date().toISOString() };
        setMessages(p => [...p, reply]);
      }, 1500);
    } catch (e) {
      setMessages(p => p.map(m => m.id === tempMsg.id ? { ...m, failed: true, pending: false } : m));
    } finally { setSending(false); }
  };

  const formatTime = (iso) => {
    try {
      const d = new Date(iso);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch { return ''; }
  };

  const renderMessage = ({ item: m }) => {
    const isMe = m.sender_id === user?.id;
    return (
      <View style={{ alignItems: isMe ? 'flex-end' : 'flex-start', marginBottom: 10, paddingHorizontal: 14 }}>
        <View style={{
          maxWidth: '76%',
          borderRadius: 18,
          borderBottomLeftRadius: isMe ? 18 : 4,
          borderBottomRightRadius: isMe ? 4 : 18,
          overflow: 'hidden',
          opacity: m.pending ? 0.7 : 1,
        }}>
          {isMe
            ? <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ paddingHorizontal: 14, paddingVertical: 11 }}>
                <Text style={{ fontSize: 14, color: '#fff', lineHeight: 21 }}>{m.content}</Text>
                <Text style={{ fontSize: 10, color: 'rgba(255,255,255,.6)', marginTop: 4, textAlign: 'right' }}>
                  {m.failed ? '❌ Failed' : m.pending ? '⏳' : formatTime(m.created_at)}
                </Text>
              </LinearGradient>
            : <View style={{ backgroundColor: Colors.white, paddingHorizontal: 14, paddingVertical: 11, ...Shadow.sm }}>
                <Text style={{ fontSize: 14, color: Colors.t1, lineHeight: 21 }}>{m.content}</Text>
                <Text style={{ fontSize: 10, color: Colors.t3, marginTop: 4 }}>{formatTime(m.created_at)}</Text>
              </View>
          }
        </View>
      </View>
    );
  };

  const avColors = AvatarColors[conversation?.avClass || 'av-g'] || [Colors.teal, Colors.teal2];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.bg }} edges={['top']}>
      {/* Header */}
      <View style={{ backgroundColor: Colors.white, paddingHorizontal: 15, paddingVertical: 11, flexDirection: 'row', alignItems: 'center', gap: 10, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 18, color: Colors.t1 }}>←</Text>
        </TouchableOpacity>
        <LinearGradient colors={conversation?.avatarColors || avColors} style={{ width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Text style={{ fontWeight: '800', color: '#fff', fontSize: 14 }}>{(conversation?.name || 'U')[0]}</Text>
        </LinearGradient>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 15, fontWeight: '700', color: Colors.t1 }}>{conversation?.name || 'Chat'}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: Colors.success }} />
            <Text style={{ fontSize: 12, color: Colors.success, fontWeight: '500' }}>Online</Text>
          </View>
        </View>
        <TouchableOpacity style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 18 }}>📞</Text>
        </TouchableOpacity>
      </View>

      {/* Messages */}
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        {loading
          ? <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={Colors.teal} size="large" /></View>
          : <FlatList
              ref={flatRef}
              data={messages}
              keyExtractor={i => i.id}
              renderItem={renderMessage}
              contentContainerStyle={{ paddingVertical: 14 }}
              onContentSizeChange={() => flatRef.current?.scrollToEnd({ animated: true })}
              showsVerticalScrollIndicator={false}
            />
        }
        {/* Typing indicator */}
        {sending && (
          <View style={{ paddingHorizontal: 14, paddingBottom: 6 }}>
            <View style={{ flexDirection: 'row', gap: 5, alignItems: 'center', backgroundColor: Colors.white, borderRadius: 18, borderBottomLeftRadius: 4, alignSelf: 'flex-start', padding: 11, ...Shadow.sm }}>
              {[0,1,2].map(i => <View key={i} style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: Colors.t3, opacity: 0.5 + i * 0.2 }} />)}
            </View>
          </View>
        )}
        {/* Input */}
        <View style={{ backgroundColor: Colors.white, paddingHorizontal: 13, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 9, borderTopWidth: 1, borderTopColor: Colors.border }}>
          <TouchableOpacity style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 18 }}>📎</Text>
          </TouchableOpacity>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Type a message..."
            placeholderTextColor={Colors.t3}
            style={{ flex: 1, backgroundColor: Colors.bg, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, color: Colors.t1 }}
            returnKeyType="send"
            onSubmitEditing={handleSend}
            multiline
            maxLength={2000}
          />
          <TouchableOpacity style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 18 }}>😊</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleSend} style={{ width: 40, height: 40, borderRadius: 20, overflow: 'hidden' }}>
            <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: '#fff', fontSize: 18 }}>→</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ══════════════════════════════
// AI CHAT SCREEN
// ══════════════════════════════
export function AIChatScreen({ navigation }) {
  const { chatMessages, sendAiMessage, loadChatHistory } = useStore();
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const flatRef = useRef(null);
  const quickPrompts = ['Write me a post', "What's trending?", 'Summarise my feed', 'Help with caption', 'Content strategy'];

  useEffect(() => { loadChatHistory(); }, []);

  const handleSend = async (text) => {
    const msg = (text || input).trim();
    if (!msg) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setInput('');
    setTyping(true);
    await sendAiMessage(msg);
    setTyping(false);
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const formatTime = (iso) => {
    try { return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
    catch { return ''; }
  };

  const renderMsg = ({ item: m }) => {
    const isUser = m.role === 'user';
    return (
      <View style={{ alignItems: isUser ? 'flex-start' : 'flex-end', marginBottom: 12, paddingHorizontal: 14 }}>
        {!isUser ? (
          <View style={{ maxWidth: '80%', backgroundColor: Colors.teal3, borderWidth: 1, borderColor: Colors.teal4, borderRadius: 18, borderBottomRightRadius: 4, padding: 13 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 6 }}>
              <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontSize: 10, fontWeight: '800', color: '#fff' }}>W</Text>
              </LinearGradient>
              <Text style={{ fontSize: 12, fontWeight: '700', color: Colors.teal2 }}>Webond AI</Text>
            </View>
            <Text style={{ fontSize: 14, color: Colors.t1, lineHeight: 22 }}>{m.content}</Text>
            <Text style={{ fontSize: 10, color: Colors.t3, marginTop: 5, textAlign: 'right' }}>{formatTime(m.time)}</Text>
          </View>
        ) : (
          <View style={{ maxWidth: '80%', borderRadius: 18, borderBottomLeftRadius: 4, overflow: 'hidden' }}>
            <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ paddingHorizontal: 14, paddingVertical: 11 }}>
              <Text style={{ fontSize: 14, color: '#fff', lineHeight: 21 }}>{m.content}</Text>
              <Text style={{ fontSize: 10, color: 'rgba(255,255,255,.6)', marginTop: 4, textAlign: 'right' }}>{formatTime(m.time)}</Text>
            </LinearGradient>
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.bg }} edges={['top']}>
      {/* Header */}
      <View style={{ backgroundColor: Colors.white, paddingHorizontal: 15, paddingVertical: 11, flexDirection: 'row', alignItems: 'center', gap: 10, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 18 }}>←</Text>
        </TouchableOpacity>
        <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 20 }}>🤖</Text>
        </LinearGradient>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 15, fontWeight: '700', color: Colors.t1 }}>Webond AI</Text>
          <Text style={{ fontSize: 12, color: Colors.teal, fontWeight: '500' }}>● Always online · Powered by AI</Text>
        </View>
        <TouchableOpacity style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 18 }}>⚡</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <FlatList
          ref={flatRef}
          data={chatMessages}
          keyExtractor={i => i.id}
          renderItem={renderMsg}
          contentContainerStyle={{ paddingVertical: 14, paddingBottom: 6 }}
          onContentSizeChange={() => flatRef.current?.scrollToEnd({ animated: true })}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={() =>
            typing ? (
              <View style={{ paddingHorizontal: 14, marginBottom: 6 }}>
                <View style={{ flexDirection: 'row', gap: 5, alignItems: 'center', backgroundColor: Colors.white, borderRadius: 18, borderBottomLeftRadius: 4, alignSelf: 'flex-start', padding: 11, ...Shadow.sm }}>
                  {[0,1,2].map(i => <View key={i} style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: Colors.t3 }} />)}
                </View>
              </View>
            ) : null
          }
        />
        {/* Quick prompts */}
        <View style={{ paddingBottom: 6 }}>
          <FlatList
            horizontal
            data={quickPrompts}
            keyExtractor={i => i}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 14, gap: 8 }}
            renderItem={({ item }) => (
              <TouchableOpacity onPress={() => handleSend(item)} style={{ paddingHorizontal: 13, paddingVertical: 7, borderRadius: 20, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.white }}>
                <Text style={{ fontSize: 12, fontWeight: '500', color: Colors.t2 }}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        {/* Input bar */}
        <View style={{ backgroundColor: Colors.white, paddingHorizontal: 13, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 9, borderTopWidth: 1, borderTopColor: Colors.border }}>
          <TouchableOpacity style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 18 }}>📎</Text>
          </TouchableOpacity>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Ask Webond AI anything..."
            placeholderTextColor={Colors.t3}
            style={{ flex: 1, backgroundColor: Colors.bg, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, color: Colors.t1 }}
            returnKeyType="send"
            onSubmitEditing={() => handleSend()}
            multiline
          />
          <TouchableOpacity style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 18 }}>😊</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleSend()} disabled={typing} style={{ width: 40, height: 40, borderRadius: 20, overflow: 'hidden', opacity: typing ? 0.6 : 1 }}>
            <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: '#fff', fontSize: 18 }}>→</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ══════════════════════════════
// VIDEO FEED SCREEN
// ══════════════════════════════
export function VideoScreen({ navigation }) {
  const [activeTab, setActiveTab] = useState('Text');
  const tabs = ['Text', 'Videos', 'Photos', 'Reels', 'LIVE'];
  const videos = [
    { id: 'v1', user: '@ngozi_creates', verified: true, avColors: ['#B3EFE9','#06b6d4'], desc: 'Night life in Abuja is something else 🔥 This city never sleeps!', emoji: '👩‍💼', duration: '0:42', likes: '48.2k', comments: '2.8k', liked: true },
    { id: 'v2', user: '@tech_chidi', verified: true, avColors: ['#fde68a','#fb923c'], desc: 'Everything you need to know about building a startup in Lagos ⚡', emoji: '🏙️', duration: '1:14', likes: '12.4k', comments: '893', liked: false },
    { id: 'v3', user: '@yushat', verified: true, avColors: [Colors.teal, Colors.teal2], desc: 'Behind the scenes building Webond 🚀 The future of social media is here!', emoji: '💻', duration: '2:31', likes: '89.1k', comments: '4.2k', liked: false },
  ];

  const VideoCard = ({ v }) => {
    const [liked, setLiked] = useState(v.liked);
    const [saved, setSaved] = useState(false);
    return (
      <TouchableOpacity onPress={() => navigation.navigate('Reel', { video: v })} activeOpacity={0.96}
        style={{ backgroundColor: Colors.white, borderRadius: Radius.lg, marginHorizontal: 14, marginBottom: 12, overflow: 'hidden', ...Shadow.sm }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <LinearGradient colors={v.avColors} style={{ width: 36, height: 36, borderRadius: 18 }} />
            <View>
              <Text style={{ fontSize: 13, fontWeight: '600', color: Colors.t1 }}>{v.user} {v.verified && '✓'}</Text>
              <Text style={{ fontSize: 11, color: Colors.t3 }}>2 hours ago</Text>
            </View>
          </View>
          <TouchableOpacity><Text style={{ fontSize: 18, color: Colors.t3 }}>⋯</Text></TouchableOpacity>
        </View>
        <View style={{ width: '100%', aspectRatio: 4/3, backgroundColor: Colors.dark, alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          <Text style={{ fontSize: 80 }}>{v.emoji}</Text>
          <View style={{ position: 'absolute', inset: 0, alignItems: 'center', justifyContent: 'center' }}>
            <View style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: 'rgba(0,0,0,0.4)', alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontSize: 22, color: '#fff', marginLeft: 3 }}>▶</Text>
            </View>
          </View>
          <View style={{ position: 'absolute', top: 10, right: 10, backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 3 }}>
            <Text style={{ fontSize: 11, color: '#fff', fontWeight: '600' }}>{v.duration}</Text>
          </View>
        </View>
        <View style={{ padding: 12 }}>
          <Text style={{ fontSize: 13, color: Colors.t1, marginBottom: 10, lineHeight: 20 }}>{v.desc}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            <TouchableOpacity onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setLiked(!liked); }} style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
              <Text style={{ fontSize: 18 }}>{liked ? '❤️' : '🤍'}</Text>
              <Text style={{ fontSize: 12, fontWeight: '600', color: liked ? Colors.coral : Colors.t3 }}>{v.likes}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
              <Text style={{ fontSize: 18 }}>💬</Text>
              <Text style={{ fontSize: 12, fontWeight: '600', color: Colors.t3 }}>{v.comments}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
              <Text style={{ fontSize: 18 }}>🔗</Text>
              <Text style={{ fontSize: 12, fontWeight: '600', color: Colors.t3 }}>Share</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setSaved(!saved)} style={{ marginLeft: 'auto' }}>
              <Text style={{ fontSize: 18 }}>{saved ? '🔖' : '🏷️'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.bg }} edges={['top']}>
      <View style={{ backgroundColor: Colors.white, paddingHorizontal: Spacing.lg, paddingVertical: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <Text style={{ fontSize: 18, fontWeight: '700', color: Colors.t1 }}>Short video feed</Text>
        <TouchableOpacity style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 18 }}>🔍</Text>
        </TouchableOpacity>
      </View>
      <View style={{ backgroundColor: Colors.white, borderBottomWidth: 1, borderBottomColor: Colors.border }}>
        <FlatList horizontal data={tabs} keyExtractor={t => t} showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 14 }}
          renderItem={({ item: t }) => (
            <TouchableOpacity onPress={() => setActiveTab(t)} style={{ paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 2.5, borderBottomColor: activeTab === t ? Colors.teal : 'transparent', marginRight: 4 }}>
              <Text style={{ fontSize: 13, fontWeight: '600', color: activeTab === t ? Colors.teal : Colors.t3 }}>{t}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <FlatList data={videos} keyExtractor={v => v.id} renderItem={({ item }) => <VideoCard v={item} />}
        contentContainerStyle={{ paddingTop: 12, paddingBottom: 90 }}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

// ══════════════════════════════
// FULLSCREEN REEL SCREEN
// ══════════════════════════════
export function ReelScreen({ navigation, route }) {
  const { video } = route.params || {};
  const { user, avClass } = useStore();
  const [liked, setLiked] = useState(true);
  const [saved, setSaved] = useState(false);
  const avColors = AvatarColors[avClass] || [Colors.teal, Colors.teal2];
  const initial = (user?.name || 'Y')[0].toUpperCase();

  const actions = [
    { icon: liked ? '❤️' : '🤍', label: '48.3k', onPress: () => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setLiked(!liked); } },
    { icon: saved ? '🔖' : '🏷️', label: 'Save', onPress: () => { Haptics.selectionAsync(); setSaved(!saved); } },
    { icon: '💬', label: '2.8k', onPress: () => {} },
    { icon: '🔗', label: 'Share', onPress: () => Haptics.selectionAsync() },
    { icon: '🎵', label: 'Sound', onPress: () => {} },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: Colors.dark }}>
      {/* Background */}
      <LinearGradient colors={[Colors.dark, Colors.dark2, '#1a0a28']} style={{ ...StyleSheet.absoluteFillObject }} />
      {/* Content */}
      <View style={{ ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ fontSize: 110 }}>{video?.emoji || '👩‍💼'}</Text>
      </View>
      {/* Gradient overlay */}
      <LinearGradient colors={['rgba(0,0,0,0.7)', 'transparent', 'rgba(0,0,0,0.85)']} locations={[0, 0.4, 1]} style={{ ...StyleSheet.absoluteFillObject }} />

      {/* Top bar */}
      <SafeAreaView edges={['top']} style={{ position: 'absolute', top: 0, left: 0, right: 0 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingTop: 12 }}>
          <View style={{ flexDirection: 'row', gap: 14 }}>
            {['Following', 'For You', 'LIVE'].map(t => (
              <TouchableOpacity key={t}>
                <Text style={{ fontSize: 14, fontWeight: '600', color: t === 'For You' ? '#fff' : 'rgba(255,255,255,0.4)', borderBottomWidth: t === 'For You' ? 2 : 0, borderBottomColor: Colors.teal, paddingBottom: 3 }}>{t}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity onPress={() => navigation.goBack()} style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700' }}>✕</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>

      {/* Right action bar */}
      <View style={{ position: 'absolute', right: 12, bottom: 120, alignItems: 'center', gap: 20 }}>
        <View style={{ alignItems: 'center', gap: 6 }}>
          <LinearGradient colors={avColors} style={{ width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', borderWidth: 2.5, borderColor: 'rgba(255,255,255,0.8)' }}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: '#fff' }}>{initial}</Text>
          </LinearGradient>
          <TouchableOpacity onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)} style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: Colors.teal, alignItems: 'center', justifyContent: 'center', marginTop: -12 }}>
            <Text style={{ color: '#fff', fontSize: 12, fontWeight: '800' }}>+</Text>
          </TouchableOpacity>
        </View>
        {actions.map((a, i) => (
          <TouchableOpacity key={i} onPress={a.onPress} style={{ alignItems: 'center', gap: 3 }}>
            <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontSize: 20 }}>{a.icon}</Text>
            </View>
            <Text style={{ fontSize: 11, color: '#fff', fontWeight: '600', textShadowColor: 'rgba(0,0,0,0.5)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 3 }}>{a.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Bottom info */}
      <View style={{ position: 'absolute', bottom: 30, left: 0, right: 70, paddingHorizontal: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 9 }}>
          <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: 'rgba(255,255,255,0.8)' }}>
            <Text style={{ fontSize: 14, fontWeight: '800', color: '#fff' }}>N</Text>
          </LinearGradient>
          <Text style={{ fontSize: 15, fontWeight: '700', color: '#fff' }}>{video?.user || '@ngozi_creates'} ✓</Text>
          <TouchableOpacity onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)} style={{ paddingHorizontal: 12, paddingVertical: 4, borderRadius: 16, backgroundColor: 'rgba(0,194,168,0.3)', borderWidth: 1, borderColor: 'rgba(0,194,168,0.5)' }}>
            <Text style={{ fontSize: 11, fontWeight: '700', color: Colors.teal }}>+ Follow</Text>
          </TouchableOpacity>
        </View>
        <Text style={{ fontSize: 13, color: 'rgba(255,255,255,0.88)', lineHeight: 20, marginBottom: 9 }}>{video?.desc || 'Night life in Abuja is something else 🔥 This city never sleeps!'}</Text>
        <View style={{ flexDirection: 'row', gap: 7, flexWrap: 'wrap', marginBottom: 10 }}>
          {['#Abuja', '#NightLife', '#Webond'].map(t => (
            <View key={t} style={{ paddingHorizontal: 9, paddingVertical: 3, borderRadius: 14, backgroundColor: 'rgba(0,194,168,0.15)', borderWidth: 1, borderColor: 'rgba(0,194,168,0.25)' }}>
              <Text style={{ fontSize: 11, color: Colors.teal, fontWeight: '500' }}>{t}</Text>
            </View>
          ))}
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Text style={{ fontSize: 14 }}>🎵</Text>
          <Text style={{ fontSize: 11, color: 'rgba(255,255,255,0.65)' }}>Afrobeats Mix — DJ Neptune ft. Wizkid</Text>
        </View>
      </View>

      {/* Progress bar */}
      <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 2.5, backgroundColor: 'rgba(255,255,255,0.15)' }}>
        <LinearGradient colors={[Colors.teal, Colors.teal2]} style={{ height: '100%', width: '65%', borderRadius: 2 }} />
      </View>
    </View>
  );
}

// Need this import for StyleSheet
import { StyleSheet } from 'react-native';
