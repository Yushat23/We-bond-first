// src/screens/auth/SplashScreen.js
import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../utils/theme';
import useStore from '../../store/useStore';

export default function SplashScreen({ navigation }) {
  const init = useStore(s => s.init);
  useEffect(() => {
    const load = async () => {
      const loggedIn = await init();
      if (!loggedIn) setTimeout(() => navigation.replace('Welcome'), 2200);
    };
    load();
  }, []);
  return (
    <LinearGradient colors={[Colors.dark, Colors.dark2, Colors.dark]} style={styles.container}>
      {[340,260,180].map((s,i) => (
        <View key={i} style={[styles.ring, { width: s, height: s, borderColor: `rgba(0,194,168,${0.1+i*0.07})` }]} />
      ))}
      <Text style={styles.logo}>web<Text style={{ color: Colors.teal }}>ond</Text></Text>
      <Text style={styles.tag}>Connect Beyond</Text>
      <View style={styles.dots}>
        {[0,1,2].map(i => <View key={i} style={styles.dot} />)}
      </View>
    </LinearGradient>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  ring: { position: 'absolute', borderRadius: 9999, borderWidth: 1, borderStyle: 'solid', top: '50%', left: '50%', marginLeft: -170, marginTop: -170 },
  logo: { fontSize: 46, fontWeight: '900', color: '#fff', letterSpacing: -2 },
  tag: { fontSize: 14, color: 'rgba(255,255,255,0.45)', marginTop: 8 },
  dots: { position: 'absolute', bottom: 50, flexDirection: 'row', gap: 7 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.4)' },
});

// ─────────────────────────────
// WelcomeScreen.js
// ─────────────────────────────
import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button } from '../../components';
import { Colors, Typography, Spacing } from '../../utils/theme';

export { default as WelcomeScreen } from './WelcomeScreen';

// src/screens/auth/WelcomeScreen.js
export function WelcomeScreen({ navigation }) {
  const features = ['🤖 AI-First','🔒 E2E Encrypted','⚡ Real-time','🌍 Global'];
  return (
    <View style={{ flex: 1 }}>
      <LinearGradient colors={[Colors.dark, '#0d3d38', Colors.dark]} style={{ flex: 1.3, alignItems: 'center', justifyContent: 'center', padding: 30 }}>
        {[320,240,160].map((s,i) => (
          <View key={i} style={{ position: 'absolute', width: s, height: s, borderRadius: s/2, borderWidth: 1, borderColor: `rgba(0,194,168,${0.15+i*0.05})` }} />
        ))}
        <Text style={{ fontSize: 52, fontWeight: '900', color: '#fff', letterSpacing: -3, position: 'relative', zIndex: 1 }}>
          web<Text style={{ color: Colors.teal }}>ond</Text>
        </Text>
        <Text style={{ fontSize: 14, color: 'rgba(255,255,255,0.55)', textAlign: 'center', maxWidth: 230, lineHeight: 22, marginTop: 10, position: 'relative', zIndex: 1 }}>
          Next-gen social platform. AI-powered. Built for everyone on earth.
        </Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 20, justifyContent: 'center', position: 'relative', zIndex: 1 }}>
          {features.map(f => (
            <View key={f} style={{ paddingHorizontal: 12, paddingVertical: 5, borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)', borderRadius: 20 }}>
              <Text style={{ fontSize: 11, fontWeight: '600', color: 'rgba(255,255,255,0.65)' }}>{f}</Text>
            </View>
          ))}
        </View>
      </LinearGradient>
      <SafeAreaView edges={['bottom']} style={{ backgroundColor: Colors.white }}>
        <View style={{ padding: Spacing.lg, gap: 10 }}>
          <Button label="Create your account" onPress={() => navigation.navigate('Signup')} />
          <Button label="Sign in to Webond" variant="ghost" onPress={() => navigation.navigate('Login')} />
          <Text style={{ fontSize: 11, color: Colors.t3, textAlign: 'center', lineHeight: 17, marginTop: 4 }}>
            By continuing you agree to our{' '}
            <Text style={{ color: Colors.teal, fontWeight: '600' }}>Terms</Text> and{' '}
            <Text style={{ color: Colors.teal, fontWeight: '600' }}>Privacy Policy</Text>
          </Text>
        </View>
      </SafeAreaView>
    </View>
  );
}

// ─────────────────────────────
// LoginScreen.js
// ─────────────────────────────
import React, { useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Input, PasswordInput, SocialButton, Divider, Header } from '../../components';
import { api, setTokens } from '../../utils/api';
import useStore from '../../store/useStore';
import { Colors, Spacing } from '../../utils/theme';

export function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const setUser = useStore(s => s.setUser);

  const validate = () => {
    const e = {};
    if (!email || !/\S+@\S+\.\S+/.test(email)) e.email = 'Enter a valid email';
    if (!password || password.length < 6) e.password = '6+ characters required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const { user, accessToken, refreshToken } = await api.auth.login({ email, password });
      await setUser(user, accessToken, refreshToken);
    } catch (err) {
      Alert.alert('Sign in failed', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSocial = async (provider) => {
    // In a real app, use expo-auth-session for OAuth
    Alert.alert('Social Sign In', `${provider} OAuth would open here in production.\n\nFor demo, please use email/password.`);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }}>
      <Header title="Sign in" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: Spacing.lg, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
          <Text style={{ fontSize: 26, fontWeight: '800', color: Colors.t1, letterSpacing: -0.5, marginBottom: 6 }}>Welcome back 👋</Text>
          <Text style={{ fontSize: 14, color: Colors.t2, lineHeight: 22, marginBottom: 22 }}>Sign in to your Webond account</Text>
          <SocialButton label="Continue with Google" onPress={() => handleSocial('Google')} icon={<Text style={{ fontSize: 20 }}>🔵</Text>} />
          <SocialButton label="Continue with Apple" onPress={() => handleSocial('Apple')} icon={<Text style={{ fontSize: 20 }}>🍎</Text>} />
          <SocialButton label="Continue with Meta" onPress={() => handleSocial('Meta')} icon={<Text style={{ fontSize: 20 }}>💙</Text>} />
          <Divider label="or sign in with email" />
          <Input label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" error={errors.email} />
          <PasswordInput label="Password" value={password} onChangeText={setPassword} placeholder="Your password" error={errors.password} />
          <TouchableOpacity onPress={() => navigation.navigate('Forgot')} style={{ alignSelf: 'flex-end', marginBottom: 20 }}>
            <Text style={{ fontSize: 13, color: Colors.teal, fontWeight: '600' }}>Forgot password?</Text>
          </TouchableOpacity>
          <Button label="Sign in" onPress={handleLogin} loading={loading} />
          <TouchableOpacity onPress={() => navigation.navigate('Signup')} style={{ marginTop: 16, alignItems: 'center' }}>
            <Text style={{ fontSize: 14, color: Colors.t2 }}>No account? <Text style={{ color: Colors.teal, fontWeight: '700' }}>Sign up free</Text></Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─────────────────────────────
// SignupScreen.js (Step 1)
// ─────────────────────────────
export function SignupScreen({ navigation }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [unError, setUnError] = useState('');
  const [unHint, setUnHint] = useState('');
  const setTmpSignup = useStore(s => s.setTmpSignup);

  const checkUsername = async (val) => {
    const v = val.replace('@', '');
    setUsername('@' + v);
    if (v.length >= 3 && /^[a-zA-Z0-9_]+$/.test(v)) {
      setUnError('');
      try {
        const { available } = await api.auth.checkUsername(v);
        setUnHint(available ? `✓ @${v} is available!` : `✗ @${v} is taken`);
      } catch { setUnHint(''); }
    } else if (v.length > 0) {
      setUnError('3+ chars, letters/numbers only');
    } else {
      setUnError(''); setUnHint('');
    }
  };

  const handleNext = () => {
    if (!firstName || !lastName) { Alert.alert('Name required', 'Please enter your full name'); return; }
    const un = username.replace('@', '');
    if (!un || un.length < 3 || !/^[a-zA-Z0-9_]+$/.test(un)) { setUnError('3+ chars, letters/numbers only'); return; }
    setTmpSignup({ name: `${firstName} ${lastName}`, username: un });
    navigation.navigate('Signup2');
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }}>
      <Header title="Create account" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: Spacing.lg }} keyboardShouldPersistTaps="handled">
          <StepIndicator current={1} />
          <Text style={{ fontSize: 26, fontWeight: '800', color: Colors.t1, letterSpacing: -0.5, marginBottom: 6 }}>Your name 👤</Text>
          <Text style={{ fontSize: 14, color: Colors.t2, marginBottom: 22 }}>This will appear on your Webond profile</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><Input label="First name" value={firstName} onChangeText={setFirstName} placeholder="Yusuf" autoCapitalize="words" /></View>
            <View style={{ flex: 1 }}><Input label="Last name" value={lastName} onChangeText={setLastName} placeholder="Abubakar" autoCapitalize="words" /></View>
          </View>
          <Input label="Username" value={username} onChangeText={checkUsername} placeholder="@yushat" autoCapitalize="none" error={unError} hint={unHint} />
          <Button label="Continue →" onPress={handleNext} style={{ marginTop: 6 }} />
          <TouchableOpacity onPress={() => navigation.navigate('Login')} style={{ marginTop: 16, alignItems: 'center' }}>
            <Text style={{ fontSize: 14, color: Colors.t2 }}>Already on Webond? <Text style={{ color: Colors.teal, fontWeight: '700' }}>Sign in</Text></Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─────────────────────────────
// Signup2Screen.js (Step 2)
// ─────────────────────────────
export function Signup2Screen({ navigation }) {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const setTmpSignup = useStore(s => s.setTmpSignup);

  const handleNext = () => {
    if (!email || !/\S+@\S+\.\S+/.test(email)) { setError('Enter a valid email'); return; }
    setError('');
    setTmpSignup({ email });
    navigation.navigate('Signup3');
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }}>
      <Header title="Contact details" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: Spacing.lg }} keyboardShouldPersistTaps="handled">
          <StepIndicator current={2} />
          <Text style={{ fontSize: 26, fontWeight: '800', color: Colors.t1, letterSpacing: -0.5, marginBottom: 6 }}>How to reach you? 📱</Text>
          <Text style={{ fontSize: 14, color: Colors.t2, marginBottom: 22 }}>We'll use this to keep your account secure</Text>
          <Input label="Email address" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" error={error} />
          <Input label="Phone (optional)" placeholder="+234 080 xxxx xxxx" keyboardType="phone-pad" />
          <Button label="Continue →" onPress={handleNext} style={{ marginTop: 6 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─────────────────────────────
// Signup3Screen.js (Step 3)
// ─────────────────────────────
export function Signup3Screen({ navigation }) {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [strength, setStrength] = useState(0);
  const { tmpSignup } = useStore();

  const checkStr = (v) => {
    let s = 0;
    if (v.length >= 8) s++;
    if (/[A-Z]/.test(v)) s++;
    if (/[0-9]/.test(v)) s++;
    if (/[^A-Za-z0-9]/.test(v)) s++;
    setStrength(s);
  };

  const strColors = ['', '#EF4444','#EF4444', Colors.amber, Colors.teal, Colors.teal];
  const strLabels = ['','Weak','Weak','Medium','Strong','Very Strong'];

  const handleCreate = async () => {
    if (password.length < 8) { Alert.alert('Weak password', 'Must be at least 8 characters'); return; }
    if (password !== confirm) { setError("Passwords don't match"); return; }
    setError(''); setLoading(true);
    try {
      await api.auth.register({ ...tmpSignup, password });
      navigation.navigate('OTP', { email: tmpSignup.email });
    } catch (err) {
      Alert.alert('Registration failed', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }}>
      <Header title="Secure account" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: Spacing.lg }} keyboardShouldPersistTaps="handled">
          <StepIndicator current={3} />
          <Text style={{ fontSize: 26, fontWeight: '800', color: Colors.t1, letterSpacing: -0.5, marginBottom: 6 }}>Create password 🔐</Text>
          <Text style={{ fontSize: 14, color: Colors.t2, marginBottom: 22 }}>Make it strong to protect your account</Text>
          <PasswordInput label="Password" value={password} onChangeText={v => { setPassword(v); checkStr(v); }} placeholder="Create password" />
          {strength > 0 && (
            <View style={{ marginTop: -8, marginBottom: 14 }}>
              <View style={{ flexDirection: 'row', gap: 4, marginBottom: 4 }}>
                {[1,2,3,4].map(i => <View key={i} style={{ flex: 1, height: 3, borderRadius: 2, backgroundColor: i <= strength ? strColors[strength] : Colors.border }} />)}
              </View>
              <Text style={{ fontSize: 11, fontWeight: '600', color: strColors[strength] }}>{strLabels[strength]}</Text>
            </View>
          )}
          <PasswordInput label="Confirm password" value={confirm} onChangeText={setConfirm} placeholder="Repeat password" error={error} />
          <View style={{ backgroundColor: Colors.teal3, borderRadius: 11, padding: 12, marginBottom: 16 }}>
            {[[password.length >= 8, 'At least 8 characters'],[/[A-Z]/.test(password), 'One uppercase letter'],[/[0-9]/.test(password)||/[^A-Za-z0-9]/.test(password), 'One number or symbol']].map(([ok, lbl], i) => (
              <Text key={i} style={{ fontSize: 12, color: ok ? Colors.teal : Colors.t3, marginBottom: 3 }}>{ok ? '✓' : '○'} {lbl}</Text>
            ))}
          </View>
          <Button label="Create account" onPress={handleCreate} loading={loading} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─────────────────────────────
// OTPScreen.js
// ─────────────────────────────
export function OTPScreen({ navigation, route }) {
  const email = route.params?.email || '';
  const [timer, setTimer] = useState(60);
  const [loading, setLoading] = useState(false);
  const setUser = useStore(s => s.setUser);

  useEffect(() => {
    const t = setInterval(() => setTimer(p => Math.max(0, p - 1)), 1000);
    return () => clearInterval(t);
  }, []);

  const handleComplete = async (code) => {
    setLoading(true);
    try {
      const { user, accessToken, refreshToken } = await api.auth.verifyOtp({ email, otp: code });
      await setUser(user, accessToken, refreshToken);
      navigation.navigate('Setup');
    } catch (err) {
      Alert.alert('Verification failed', err.message || 'Invalid code. Try 123456 for demo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }}>
      <Header title="Verify email" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ padding: Spacing.lg, alignItems: 'center' }}>
        <View style={{ width: 68, height: 68, borderRadius: 22, backgroundColor: Colors.teal3, alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
          <Text style={{ fontSize: 32 }}>📬</Text>
        </View>
        <Text style={{ fontSize: 26, fontWeight: '800', color: Colors.t1, textAlign: 'center', marginBottom: 8 }}>Check your inbox</Text>
        <Text style={{ fontSize: 14, color: Colors.t2, textAlign: 'center', marginBottom: 4 }}>We sent a 6-digit code to</Text>
        <Text style={{ fontSize: 14, fontWeight: '700', color: Colors.teal, marginBottom: 4 }}>{email}</Text>
        <Text style={{ fontSize: 12, color: Colors.t3, marginBottom: 20 }}>Demo hint: enter 123456</Text>
        <OTPBoxes onComplete={handleComplete} />
        {loading && <ActivityIndicator color={Colors.teal} style={{ marginTop: 16 }} />}
        <Text style={{ fontSize: 13, color: Colors.t2, marginTop: 16 }}>
          Resend in <Text style={{ color: Colors.teal, fontWeight: '700' }}>{timer}s</Text>
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

// ─────────────────────────────
// ForgotScreen.js
// ─────────────────────────────
export function ForgotScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleReset = async () => {
    if (!email || !/\S+@\S+\.\S+/.test(email)) { Alert.alert('Invalid email'); return; }
    setLoading(true);
    try {
      await api.auth.forgot(email);
      setSent(true);
    } catch (err) {
      Alert.alert('Error', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }}>
      <Header title="Reset password" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ padding: Spacing.lg, alignItems: 'center' }}>
        <View style={{ width: 68, height: 68, borderRadius: 22, backgroundColor: Colors.coral2, alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
          <Text style={{ fontSize: 32 }}>🔑</Text>
        </View>
        <Text style={{ fontSize: 26, fontWeight: '800', color: Colors.t1, textAlign: 'center', marginBottom: 8 }}>Forgot password?</Text>
        <Text style={{ fontSize: 14, color: Colors.t2, textAlign: 'center', marginBottom: 22 }}>Enter your email and we'll send a reset code instantly</Text>
        {sent ? (
          <View style={{ alignItems: 'center', gap: 12 }}>
            <Text style={{ fontSize: 40 }}>✅</Text>
            <Text style={{ fontSize: 16, fontWeight: '700', color: Colors.teal }}>Reset code sent!</Text>
            <Text style={{ fontSize: 14, color: Colors.t2, textAlign: 'center' }}>Check your inbox at {email}</Text>
            <Button label="Back to sign in" onPress={() => navigation.navigate('Login')} style={{ marginTop: 16, width: '100%' }} />
          </View>
        ) : (
          <>
            <Input label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" containerStyle={{ width: '100%' }} />
            <Button label="Send reset code" onPress={handleReset} loading={loading} style={{ width: '100%' }} />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// ─────────────────────────────
// SetupScreen.js
// ─────────────────────────────
export function SetupScreen({ navigation }) {
  const [bio, setBio] = useState('');
  const [avClass, setAvClass] = useState('av-g');
  const { user, updateUser } = useStore();
  const initial = (user?.name || 'Y')[0].toUpperCase();
  const avOptions = ['av-g','av-c','av-p','av-b','av-a'];
  const { AvatarColors } = require('../../utils/theme');

  const handleFinish = async () => {
    try {
      await api.users.update({ bio, avatarClass: avClass });
      updateUser({ bio, avClass });
    } catch (e) {}
    navigation.navigate('Interests');
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }}>
      <Header title="Set up profile" right={<TouchableOpacity onPress={handleFinish}><Text style={{ fontSize: 14, fontWeight: '600', color: Colors.t3 }}>Skip</Text></TouchableOpacity>} />
      <ScrollView contentContainerStyle={{ padding: Spacing.lg, alignItems: 'center' }}>
        <Text style={{ fontSize: 26, fontWeight: '800', color: Colors.t1, textAlign: 'center', marginBottom: 6 }}>Make it yours ✨</Text>
        <Text style={{ fontSize: 14, color: Colors.t2, textAlign: 'center', marginBottom: 22 }}>Add a bio so friends can find you</Text>
        <TouchableOpacity onPress={() => Alert.alert('📷 Upload photo', 'Available in full version!')} style={{ width: 80, height: 80, borderRadius: 40, borderWidth: 2, borderStyle: 'dashed', borderColor: Colors.border, alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
          <Text style={{ fontSize: 28 }}>📷</Text>
        </TouchableOpacity>
        <Text style={{ fontSize: 12, color: Colors.t3, marginBottom: 18 }}>Tap to upload profile photo</Text>
        <Text style={{ fontSize: 11, fontWeight: '700', color: Colors.t2, textTransform: 'uppercase', letterSpacing: 0.5, alignSelf: 'flex-start', marginBottom: 10 }}>Pick a colour avatar</Text>
        <View style={{ flexDirection: 'row', gap: 11, marginBottom: 18 }}>
          {avOptions.map(cls => {
            const colors = AvatarColors[cls];
            return (
              <TouchableOpacity key={cls} onPress={() => setAvClass(cls)} style={{ borderWidth: avClass === cls ? 3 : 0, borderColor: Colors.teal, borderRadius: 30, overflow: 'hidden' }}>
                <LinearGradient colors={colors} style={{ width: 52, height: 52, alignItems: 'center', justifyContent: 'center', borderRadius: 26 }}>
                  <Text style={{ fontSize: 19, fontWeight: '800', color: '#fff' }}>{initial}</Text>
                </LinearGradient>
              </TouchableOpacity>
            );
          })}
        </View>
        <View style={{ width: '100%', marginBottom: 14 }}>
          <Text style={{ fontSize: 11, fontWeight: '700', color: Colors.t2, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 7 }}>Bio (optional)</Text>
          <TextInput value={bio} onChangeText={setBio} placeholder="Tech founder. Building Webond from Abuja, Nigeria 🇳🇬" multiline numberOfLines={3} style={{ backgroundColor: Colors.bg, borderWidth: 1.5, borderColor: Colors.border, borderRadius: 12, padding: 13, fontSize: 14, color: Colors.t1, textAlignVertical: 'top', minHeight: 80 }} />
        </View>
        <Button label="Finish — Let's go! 🚀" onPress={handleFinish} style={{ width: '100%' }} />
      </ScrollView>
    </SafeAreaView>
  );
}

// ─────────────────────────────
// InterestsScreen.js
// ─────────────────────────────
export function InterestsScreen({ navigation }) {
  const [selected, setSelected] = useState(new Set(['💻 Technology','⚽ Sports','🚀 Startups']));
  const interests = ['💻 Technology','🎵 Music','⚽ Sports','🎨 Art & Design','🚀 Startups','🍕 Food','✈️ Travel','📸 Photography','🤖 AI & Future','💰 Finance','🎮 Gaming','💚 Health'];

  const toggle = (i) => setSelected(p => { const s = new Set(p); s.has(i) ? s.delete(i) : s.add(i); return s; });

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white }}>
      <Header title="Your interests" right={<TouchableOpacity onPress={() => navigation.replace('MainTabs')}><Text style={{ fontSize: 14, fontWeight: '600', color: Colors.t3 }}>Skip</Text></TouchableOpacity>} />
      <ScrollView contentContainerStyle={{ padding: Spacing.lg, paddingBottom: 40 }}>
        <Text style={{ fontSize: 26, fontWeight: '800', color: Colors.t1, marginBottom: 6 }}>What do you love? ❤️</Text>
        <Text style={{ fontSize: 14, color: Colors.t2, marginBottom: 20 }}>Pick 3+ topics so Webond AI can personalise your feed</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 24 }}>
          {interests.map(i => {
            const on = selected.has(i);
            return (
              <TouchableOpacity key={i} onPress={() => toggle(i)} style={{ paddingHorizontal: 14, paddingVertical: 10, borderRadius: 22, borderWidth: 1.5, borderColor: on ? Colors.teal : Colors.border, backgroundColor: on ? Colors.teal3 : Colors.white }}>
                <Text style={{ fontSize: 13, fontWeight: '600', color: on ? Colors.teal2 : Colors.t2 }}>{i}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
        <Button label="Start exploring Webond →" onPress={() => navigation.replace('MainTabs')} />
      </ScrollView>
    </SafeAreaView>
  );
}

// Required imports at top of each file (add these)
import { ActivityIndicator } from 'react-native';
import { StepIndicator, OTPBoxes } from '../../components';
