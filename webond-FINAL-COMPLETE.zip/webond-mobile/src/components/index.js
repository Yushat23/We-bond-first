// src/components/index.js — Shared mobile UI components
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, TextInput, ActivityIndicator,
  StyleSheet, Pressable, Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { Colors, Typography, Spacing, Radius, Shadow, AvatarColors } from '../utils/theme';

// ── Avatar ──
export const Avatar = ({ user, size = 44, style }) => {
  const cls = user?.avClass || user?.avatar_class || 'av-g';
  const colors = AvatarColors[cls] || AvatarColors['av-g'];
  const initial = (user?.name || user?.username || 'Y')[0].toUpperCase();
  return (
    <LinearGradient colors={colors} style={[{ width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center' }, style]}>
      <Text style={{ fontSize: size * 0.38, fontWeight: '800', color: '#fff' }}>{initial}</Text>
    </LinearGradient>
  );
};

// ── Button ──
export const Button = ({ label, onPress, variant = 'primary', loading = false, disabled = false, style, icon }) => {
  const isPrimary = variant === 'primary';
  const isGhost = variant === 'ghost';

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onPress?.();
  };

  if (isPrimary) {
    return (
      <TouchableOpacity onPress={handlePress} disabled={disabled || loading} style={[{ borderRadius: Radius.lg, overflow: 'hidden' }, style]} activeOpacity={0.88}>
        <LinearGradient colors={[Colors.teal, Colors.teal2]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={{ paddingVertical: 15, paddingHorizontal: 24, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8 }}>
          {loading ? <ActivityIndicator color="#fff" size="small" /> : (
            <>
              {icon}
              <Text style={{ fontSize: 15, fontWeight: '700', color: '#fff', fontFamily: 'System' }}>{label}</Text>
            </>
          )}
        </LinearGradient>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity onPress={handlePress} disabled={disabled || loading}
      style={[{ borderRadius: Radius.lg, paddingVertical: 14, paddingHorizontal: 24, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, borderWidth: 1.5, borderColor: isGhost ? Colors.border : Colors.teal, backgroundColor: isGhost ? 'transparent' : Colors.teal3 }, style]}
      activeOpacity={0.88}>
      {loading ? <ActivityIndicator color={Colors.teal} size="small" /> : (
        <Text style={{ fontSize: 15, fontWeight: '700', color: isGhost ? Colors.t1 : Colors.teal }}>{label}</Text>
      )}
    </TouchableOpacity>
  );
};

// ── Input ──
export const Input = ({ label, error, hint, style, containerStyle, ...props }) => {
  const [focused, setFocused] = useState(false);
  return (
    <View style={[{ marginBottom: 14 }, containerStyle]}>
      {label && <Text style={[Typography.label, { marginBottom: 7 }]}>{label}</Text>}
      <TextInput
        style={[{
          backgroundColor: focused ? Colors.white : Colors.bg,
          borderWidth: 1.5,
          borderColor: error ? Colors.coral : focused ? Colors.teal : Colors.border,
          borderRadius: Radius.md,
          paddingHorizontal: 15, paddingVertical: 13,
          fontSize: 15, color: Colors.t1,
          fontFamily: 'System',
        }, style]}
        placeholderTextColor={Colors.t3}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        {...props}
      />
      {error && <Text style={{ fontSize: 12, color: Colors.coral, marginTop: 4 }}>{error}</Text>}
      {hint && !error && <Text style={{ fontSize: 12, color: Colors.t3, marginTop: 4 }}>{hint}</Text>}
    </View>
  );
};

// ── Social login button ──
export const SocialButton = ({ label, onPress, icon, style }) => (
  <TouchableOpacity onPress={onPress}
    style={[{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13, paddingHorizontal: 16, borderRadius: Radius.md, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.white, marginBottom: 10 }, style]}
    activeOpacity={0.85}>
    {icon}
    <Text style={{ fontSize: 14, fontWeight: '600', color: Colors.t1, flex: 1 }}>{label}</Text>
  </TouchableOpacity>
);

// ── Card ──
export const Card = ({ children, style, onPress }) => {
  if (onPress) {
    return (
      <TouchableOpacity onPress={onPress} activeOpacity={0.92}
        style={[{ backgroundColor: Colors.white, borderRadius: Radius.lg, ...Shadow.sm }, style]}>
        {children}
      </TouchableOpacity>
    );
  }
  return <View style={[{ backgroundColor: Colors.white, borderRadius: Radius.lg, ...Shadow.sm }, style]}>{children}</View>;
};

// ── Icon button ──
export const IconButton = ({ onPress, children, badge = false, style }) => (
  <TouchableOpacity onPress={onPress} activeOpacity={0.8}
    style={[{ width: 38, height: 38, borderRadius: Radius.md, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center' }, style]}>
    {children}
    {badge && <View style={{ position: 'absolute', top: 7, right: 7, width: 7, height: 7, borderRadius: 4, backgroundColor: Colors.coral, borderWidth: 1.5, borderColor: Colors.white }} />}
  </TouchableOpacity>
);

// ── Toggle ──
export const Toggle = ({ value, onChange }) => {
  const handlePress = () => { Haptics.selectionAsync(); onChange(!value); };
  return (
    <TouchableOpacity onPress={handlePress} activeOpacity={0.9}
      style={{ width: 46, height: 26, borderRadius: 13, backgroundColor: value ? Colors.teal : Colors.border, justifyContent: 'center', paddingHorizontal: 3 }}>
      <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: Colors.white, alignSelf: value ? 'flex-end' : 'flex-start', ...Shadow.sm }} />
    </TouchableOpacity>
  );
};

// ── Divider with label ──
export const Divider = ({ label }) => (
  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 11, marginVertical: 6 }}>
    <View style={{ flex: 1, height: 1, backgroundColor: Colors.border }} />
    <Text style={{ fontSize: 12, color: Colors.t3, fontWeight: '500' }}>{label}</Text>
    <View style={{ flex: 1, height: 1, backgroundColor: Colors.border }} />
  </View>
);

// ── Like button with animation ──
export const LikeButton = ({ liked, count, onPress }) => {
  const scale = new Animated.Value(1);
  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Animated.sequence([
      Animated.spring(scale, { toValue: 1.4, useNativeDriver: true, friction: 3 }),
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, friction: 3 }),
    ]).start();
    onPress?.();
  };
  const fmt = (n) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : n;
  return (
    <TouchableOpacity onPress={handlePress} style={{ flexDirection: 'row', alignItems: 'center', gap: 5, padding: 7 }} activeOpacity={0.8}>
      <Animated.View style={{ transform: [{ scale }] }}>
        <Text style={{ fontSize: 18 }}>{liked ? '❤️' : '🤍'}</Text>
      </Animated.View>
      <Text style={{ fontSize: 12, fontWeight: '600', color: liked ? Colors.coral : Colors.t3 }}>{fmt(count || 0)}</Text>
    </TouchableOpacity>
  );
};

// ── Screen header ──
export const Header = ({ title, onBack, right, style }) => (
  <View style={[{ backgroundColor: Colors.white, paddingHorizontal: Spacing.lg, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: Colors.border }, style]}>
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
      {onBack && (
        <TouchableOpacity onPress={onBack} style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 18, color: Colors.t1 }}>←</Text>
        </TouchableOpacity>
      )}
      {typeof title === 'string' ? <Text style={Typography.h3}>{title}</Text> : title}
    </View>
    {right && <View style={{ flexDirection: 'row', gap: 8 }}>{right}</View>}
  </View>
);

// ── Story ring ──
export const StoryRing = ({ children, hasStory = true, size = 62, style }) => (
  <LinearGradient
    colors={hasStory ? [Colors.teal, Colors.coral, Colors.amber] : [Colors.border, Colors.border]}
    start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
    style={[{ width: size, height: size, borderRadius: size / 2, padding: 2.5 }, style]}>
    <View style={{ flex: 1, borderRadius: (size - 5) / 2, borderWidth: 2.5, borderColor: Colors.white, overflow: 'hidden', backgroundColor: Colors.bg }}>
      {children}
    </View>
  </LinearGradient>
);

// ── Empty state ──
export const EmptyState = ({ emoji = '📭', title, subtitle }) => (
  <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.xxl }}>
    <Text style={{ fontSize: 56, marginBottom: 16 }}>{emoji}</Text>
    <Text style={[Typography.h3, { textAlign: 'center', marginBottom: 8 }]}>{title}</Text>
    {subtitle && <Text style={[Typography.bodySmall, { textAlign: 'center' }]}>{subtitle}</Text>}
  </View>
);

// ── Password input with show/hide ──
export const PasswordInput = ({ label, error, ...props }) => {
  const [show, setShow] = useState(false);
  return (
    <View style={{ marginBottom: 14 }}>
      {label && <Text style={[Typography.label, { marginBottom: 7 }]}>{label}</Text>}
      <View style={{ position: 'relative' }}>
        <TextInput
          secureTextEntry={!show}
          style={{ backgroundColor: Colors.bg, borderWidth: 1.5, borderColor: error ? Colors.coral : Colors.border, borderRadius: Radius.md, paddingHorizontal: 15, paddingRight: 46, paddingVertical: 13, fontSize: 15, color: Colors.t1 }}
          placeholderTextColor={Colors.t3}
          {...props}
        />
        <TouchableOpacity onPress={() => setShow(!show)} style={{ position: 'absolute', right: 13, top: '50%', marginTop: -12, padding: 4 }}>
          <Text style={{ fontSize: 16 }}>{show ? '🙈' : '👁'}</Text>
        </TouchableOpacity>
      </View>
      {error && <Text style={{ fontSize: 12, color: Colors.coral, marginTop: 4 }}>{error}</Text>}
    </View>
  );
};

// ── Steps indicator ──
export const StepIndicator = ({ current, total = 3 }) => (
  <View style={{ flexDirection: 'row', gap: 5, marginBottom: 20 }}>
    {Array.from({ length: total }).map((_, i) => (
      <View key={i} style={{ flex: 1, height: 3, borderRadius: 2, backgroundColor: i < current ? Colors.teal : Colors.border }} />
    ))}
  </View>
);

// ── OTP Input ──
export const OTPBoxes = ({ onComplete }) => {
  const [values, setValues] = useState(['', '', '', '', '', '']);
  const refs = React.useRef([]);
  const handleChange = (i, val) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...values];
    next[i] = val;
    setValues(next);
    if (val && i < 5) refs.current[i + 1]?.focus();
    if (next.every(v => v)) onComplete(next.join(''));
  };
  const handleKeyPress = (i, e) => {
    if (e.nativeEvent.key === 'Backspace' && !values[i] && i > 0) refs.current[i - 1]?.focus();
  };
  return (
    <View style={{ flexDirection: 'row', gap: 10, justifyContent: 'center', marginVertical: 20 }}>
      {values.map((v, i) => (
        <TextInput
          key={i}
          ref={el => refs.current[i] = el}
          maxLength={1}
          keyboardType="numeric"
          value={v}
          onChangeText={val => handleChange(i, val)}
          onKeyPress={e => handleKeyPress(i, e)}
          style={{ width: 52, height: 62, borderWidth: 1.5, borderColor: v ? Colors.teal : Colors.border, borderRadius: Radius.md, fontSize: 26, fontWeight: '700', textAlign: 'center', backgroundColor: v ? Colors.teal3 : Colors.bg, color: v ? Colors.teal2 : Colors.t1 }}
        />
      ))}
    </View>
  );
};

// ── Typing indicator ──
export const TypingIndicator = () => (
  <View style={{ flexDirection: 'row', gap: 5, alignItems: 'center', backgroundColor: Colors.white, borderRadius: 18, borderBottomLeftRadius: 4, padding: '10px 13px', alignSelf: 'flex-start', ...Shadow.sm, paddingHorizontal: 13, paddingVertical: 10 }}>
    {[0, 1, 2].map(i => (
      <View key={i} style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: Colors.t3 }} />
    ))}
  </View>
);

export const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.bg },
  scrollContent: { paddingBottom: 80 },
  section: { paddingHorizontal: Spacing.lg, marginTop: Spacing.md },
  sectionTitle: { fontSize: 11, fontWeight: '700', color: Colors.t3, textTransform: 'uppercase', letterSpacing: 0.7, marginBottom: 7 },
  row: { flexDirection: 'row', alignItems: 'center' },
  flex1: { flex: 1 },
  center: { alignItems: 'center', justifyContent: 'center' },
  shadow: Shadow.sm,
  card: { backgroundColor: Colors.white, borderRadius: Radius.lg, ...Shadow.sm },
});
