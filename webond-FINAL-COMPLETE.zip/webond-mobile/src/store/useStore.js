// src/store/useStore.js
import { create } from 'zustand';
import { api, setTokens, clearTokens, storage } from '../utils/api';

const useStore = create((set, get) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  avClass: 'av-g',
  posts: [],
  conversations: [],
  chatMessages: [],
  notifications: [],
  unreadCount: 0,
  stories: [],

  // ── Init ──
  init: async () => {
    try {
      const saved = await storage.get('wb_user');
      if (saved) {
        const user = JSON.parse(saved);
        set({ user, isAuthenticated: true, avClass: user.avClass || 'av-g', isLoading: false });
        return true;
      }
    } catch (e) {}
    set({ isLoading: false });
    return false;
  },

  // ── Auth ──
  setUser: async (user, access, refresh) => {
    if (access && refresh) await setTokens(access, refresh);
    await storage.set('wb_user', JSON.stringify(user));
    set({ user, isAuthenticated: true, avClass: user.avClass || user.avatar_class || 'av-g' });
  },

  logout: async () => {
    await api.auth.logout().catch(() => {});
    await clearTokens();
    set({ user: null, isAuthenticated: false, posts: [], chatMessages: [], conversations: [] });
  },

  updateUser: (updates) => {
    const user = { ...get().user, ...updates };
    storage.set('wb_user', JSON.stringify(user));
    set({ user });
  },

  // ── Posts ──
  loadFeed: async (page = 1) => {
    try {
      const { posts } = await api.posts.feed(page);
      if (page === 1) set({ posts });
      else set((s) => ({ posts: [...s.posts, ...posts] }));
      return posts;
    } catch (e) { return []; }
  },

  addPost: (post) => set((s) => ({ posts: [post, ...s.posts] })),

  likePost: async (postId) => {
    // Optimistic update
    set((s) => ({
      posts: s.posts.map(p =>
        p.id === postId
          ? { ...p, isLiked: !p.isLiked, likeCount: p.isLiked ? Math.max(0, p.likeCount - 1) : p.likeCount + 1 }
          : p
      ),
    }));
    try {
      await api.posts.like(postId);
    } catch {
      // Revert on failure
      set((s) => ({
        posts: s.posts.map(p =>
          p.id === postId
            ? { ...p, isLiked: !p.isLiked, likeCount: p.isLiked ? p.likeCount - 1 : p.likeCount + 1 }
            : p
        ),
      }));
    }
  },

  // ── Messages ──
  loadConversations: async () => {
    try {
      const { conversations } = await api.messages.conversations();
      set({ conversations });
    } catch (e) {}
  },

  // ── AI Chat ──
  loadChatHistory: async () => {
    try {
      const { messages } = await api.ai.history();
      if (messages?.length > 0) set({ chatMessages: messages });
      else set({
        chatMessages: [{
          id: '0', role: 'assistant',
          content: 'Hi! I\'m Webond AI 🤖 I can write posts, answer questions, summarise your feed, and much more. What can I do for you?',
          time: new Date().toISOString(),
        }],
      });
    } catch (e) {}
  },

  sendAiMessage: async (text) => {
    const userMsg = { id: Date.now().toString(), role: 'user', content: text, time: new Date().toISOString() };
    set((s) => ({ chatMessages: [...s.chatMessages, userMsg] }));
    try {
      const history = get().chatMessages.slice(-10);
      const { reply } = await api.ai.chat(text, history);
      const aiMsg = { id: (Date.now() + 1).toString(), role: 'assistant', content: reply, time: new Date().toISOString() };
      set((s) => ({ chatMessages: [...s.chatMessages, aiMsg] }));
      return reply;
    } catch (e) {
      const err = { id: (Date.now() + 1).toString(), role: 'assistant', content: 'Sorry, I\'m having trouble connecting right now. Try again in a moment! 🔄', time: new Date().toISOString() };
      set((s) => ({ chatMessages: [...s.chatMessages, err] }));
    }
  },

  // ── Notifications ──
  loadNotifications: async () => {
    try {
      const { notifications, unreadCount } = await api.notifications.get();
      set({ notifications, unreadCount });
    } catch (e) {}
  },
}));

export default useStore;
