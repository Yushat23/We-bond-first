// webond-features/maintenance/maintenanceSystem.js
// Auto-updates, error monitoring, DB backups, health checks

// ═══════════════════════════════════════
// 1. SENTRY ERROR MONITORING
// Install: npm install @sentry/node @sentry/react @sentry/react-native
// ═══════════════════════════════════════

// Backend — add to top of server.js
const Sentry = require('@sentry/node');
const { nodeProfilingIntegration } = require('@sentry/profiling-node');

const initSentry = () => {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: process.env.NODE_ENV,
    release: `webond-backend@${process.env.npm_package_version}`,
    integrations: [
      nodeProfilingIntegration(),
      new Sentry.Integrations.Http({ tracing: true }),
      new Sentry.Integrations.Express({ app: require('./server').app }),
    ],
    tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
    profilesSampleRate: 0.1,
    beforeSend(event) {
      // Strip sensitive data before sending
      if (event.request?.data) {
        delete event.request.data.password;
        delete event.request.data.token;
        delete event.request.data.refreshToken;
      }
      return event;
    },
  });
};

// Capture custom events
const captureError = (err, context = {}) => {
  Sentry.withScope(scope => {
    Object.entries(context).forEach(([k, v]) => scope.setTag(k, v));
    Sentry.captureException(err);
  });
};

const captureMetric = (name, value, unit = 'none') => {
  Sentry.metrics.distribution(name, value, { unit });
};

// ═══════════════════════════════════════
// 2. HEALTH CHECK ENDPOINT
// ═══════════════════════════════════════
const express = require('express');
const { supabase } = require('../../webond-backend/config/supabase');

const healthRouter = express.Router();

healthRouter.get('/', async (req, res) => {
  const start = Date.now();
  const checks = {};

  // Database
  try {
    const { data, error } = await supabase.from('users').select('id').limit(1);
    checks.database = { status: error ? 'error' : 'ok', latency: Date.now() - start };
  } catch (e) {
    checks.database = { status: 'error', message: e.message };
  }

  // AI service
  try {
    const aiStart = Date.now();
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'HEAD',
      headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY },
    });
    checks.ai = { status: resp.status < 500 ? 'ok' : 'degraded', latency: Date.now() - aiStart };
  } catch {
    checks.ai = { status: 'unknown' };
  }

  // Memory
  const mem = process.memoryUsage();
  checks.memory = {
    status: mem.heapUsed / mem.heapTotal > 0.9 ? 'warning' : 'ok',
    heapUsed: Math.round(mem.heapUsed / 1024 / 1024) + 'MB',
    heapTotal: Math.round(mem.heapTotal / 1024 / 1024) + 'MB',
    rss: Math.round(mem.rss / 1024 / 1024) + 'MB',
  };

  // Uptime
  checks.uptime = {
    status: 'ok',
    seconds: Math.floor(process.uptime()),
    human: formatUptime(process.uptime()),
  };

  const allOk = Object.values(checks).every(c => c.status === 'ok');
  const httpStatus = allOk ? 200 : checks.database?.status === 'error' ? 503 : 200;

  res.status(httpStatus).json({
    status: allOk ? 'healthy' : 'degraded',
    app: 'Webond API',
    version: process.env.npm_package_version || '1.0.0',
    environment: process.env.NODE_ENV,
    timestamp: new Date().toISOString(),
    checks,
    responseTime: Date.now() - start + 'ms',
  });
});

healthRouter.get('/ping', (req, res) => res.json({ pong: true, ts: Date.now() }));

healthRouter.get('/metrics', async (req, res) => {
  const [users, posts, dau] = await Promise.all([
    supabase.from('users').select('id', { count: 'exact', head: true }),
    supabase.from('posts').select('id', { count: 'exact', head: true }),
    supabase.from('users').select('id', { count: 'exact', head: true })
      .gt('last_seen', new Date(Date.now() - 86400000).toISOString()),
  ]);

  res.json({
    totalUsers: users.count || 0,
    totalPosts: posts.count || 0,
    dailyActiveUsers: dau.count || 0,
    uptime: formatUptime(process.uptime()),
    nodeVersion: process.version,
    memoryMB: Math.round(process.memoryUsage().rss / 1024 / 1024),
  });
});

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}

// ═══════════════════════════════════════
// 3. DATABASE BACKUP SCRIPTS
// Run via cron: 0 2 * * * node backup.js
// ═══════════════════════════════════════
const backupDatabase = async () => {
  const { createClient } = require('@supabase/supabase-js');
  const fs = require('fs');
  const path = require('path');

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupDir = path.join(process.cwd(), 'backups');
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

  const supabaseAdmin = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);

  const tables = ['users', 'posts', 'likes', 'follows', 'comments', 'messages', 'notifications', 'subscriptions', 'transactions'];
  const backup = { timestamp, tables: {} };

  console.log(`🗄️ Starting backup ${timestamp}...`);

  for (const table of tables) {
    try {
      const { data, error } = await supabaseAdmin.from(table).select('*');
      if (error) { console.error(`❌ ${table}:`, error.message); continue; }
      backup.tables[table] = { count: data.length, data };
      console.log(`✅ ${table}: ${data.length} rows`);
    } catch (e) {
      console.error(`❌ ${table}:`, e.message);
    }
  }

  const backupPath = path.join(backupDir, `webond-backup-${timestamp}.json`);
  fs.writeFileSync(backupPath, JSON.stringify(backup, null, 2));
  console.log(`\n✅ Backup saved: ${backupPath}`);
  console.log(`📦 Size: ${(fs.statSync(backupPath).size / 1024 / 1024).toFixed(2)}MB`);

  // Keep only last 7 backups
  const files = fs.readdirSync(backupDir)
    .filter(f => f.startsWith('webond-backup-'))
    .sort().reverse();

  if (files.length > 7) {
    files.slice(7).forEach(f => {
      fs.unlinkSync(path.join(backupDir, f));
      console.log(`🗑️ Deleted old backup: ${f}`);
    });
  }

  return backupPath;
};

// ═══════════════════════════════════════
// 4. AUTO-UPDATE SYSTEM (React + Mobile)
// ═══════════════════════════════════════
const checkForUpdates = async (currentVersion) => {
  try {
    const res = await fetch('https://api.github.com/repos/yushat/webond/releases/latest');
    const release = await res.json();
    const latestVersion = release.tag_name?.replace('v', '');

    if (latestVersion && latestVersion !== currentVersion) {
      return {
        hasUpdate: true,
        version: latestVersion,
        changelog: release.body || '',
        downloadUrl: release.html_url,
        publishedAt: release.published_at,
        isForced: release.body?.includes('[FORCED]') || false,
      };
    }
    return { hasUpdate: false };
  } catch {
    return { hasUpdate: false };
  }
};

// Mobile OTA update check (Expo Updates)
const mobileUpdateCheck = `
// Add to App.js in webond-mobile
import * as Updates from 'expo-updates';

const checkMobileUpdates = async () => {
  try {
    const update = await Updates.checkForUpdateAsync();
    if (update.isAvailable) {
      await Updates.fetchUpdateAsync();
      await Updates.reloadAsync();
    }
  } catch (e) {
    console.log('Update check failed:', e.message);
  }
};

// Run on app start
useEffect(() => {
  if (!__DEV__) checkMobileUpdates();
}, []);
`;

// ═══════════════════════════════════════
// 5. AUTOMATED CLEANUP JOBS
// Run these on a schedule with node-cron
// Install: npm install node-cron
// ═══════════════════════════════════════
const cron = require('node-cron');

const setupMaintenanceJobs = (supabase) => {
  // Clean expired stories every hour
  cron.schedule('0 * * * *', async () => {
    const { count } = await supabase.from('stories')
      .delete({ count: 'exact' })
      .lt('expires_at', new Date().toISOString());
    if (count > 0) console.log(`🗑️ Deleted ${count} expired stories`);
  });

  // Clean expired OTP codes every 15 minutes
  cron.schedule('*/15 * * * *', async () => {
    await supabase.from('users')
      .update({ otp_code: null, otp_expires_at: null })
      .lt('otp_expires_at', new Date().toISOString())
      .not('otp_code', 'is', null);
  });

  // Reset weekly trending counts every Monday at midnight
  cron.schedule('0 0 * * 1', async () => {
    await supabase.rpc('reset_weekly_trending');
    console.log('📊 Weekly trending counts reset');
  });

  // Daily backup at 2 AM
  cron.schedule('0 2 * * *', async () => {
    console.log('🗄️ Running daily backup...');
    await backupDatabase();
  });

  // Health report every 6 hours
  cron.schedule('0 */6 * * *', async () => {
    const { count: users } = await supabase.from('users').select('id', { count: 'exact', head: true });
    const { count: posts } = await supabase.from('posts').select('id', { count: 'exact', head: true });
    console.log(`📊 Webond Health | Users: ${users} | Posts: ${posts} | Uptime: ${formatUptime(process.uptime())}`);
  });

  // Clean old notifications every week
  cron.schedule('0 3 * * 0', async () => {
    const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const { count } = await supabase.from('notifications')
      .delete({ count: 'exact' })
      .lt('created_at', cutoff)
      .eq('is_read', true);
    if (count > 0) console.log(`🗑️ Deleted ${count} old notifications`);
  });

  console.log('⏰ Maintenance jobs scheduled');
};

// ═══════════════════════════════════════
// 6. UPTIME MONITORING SETUP
// ═══════════════════════════════════════
const uptimeSetup = `
# FREE UPTIME MONITORING OPTIONS:

## Option A: UptimeRobot (Recommended — Free)
1. Go to uptimerobot.com → Create free account
2. Add New Monitor:
   - Type: HTTP(s)
   - URL: https://webond-api.onrender.com/health
   - Interval: 5 minutes
3. Set alert: email + Telegram when down
4. Share status page: status.webond.com

## Option B: Better Uptime (Free tier)
1. betteruptime.com → New monitor
2. URL: https://webond-api.onrender.com/health
3. Check every: 3 minutes
4. Public status page automatically created

## Option C: Render built-in
- Render.com → Your service → Metrics tab
- Shows CPU, memory, request count
`;

// ═══════════════════════════════════════
// 7. ENVIRONMENT VALIDATION ON STARTUP
// ═══════════════════════════════════════
const validateEnvironment = () => {
  const required = [
    'SUPABASE_URL', 'SUPABASE_SERVICE_KEY', 'JWT_SECRET',
    'JWT_REFRESH_SECRET', 'ANTHROPIC_API_KEY',
  ];
  const optional = [
    'RESEND_API_KEY', 'CLOUDINARY_CLOUD_NAME', 'STRIPE_SECRET_KEY',
    'FIREBASE_PROJECT_ID', 'GOOGLE_CLIENT_ID', 'SENTRY_DSN',
  ];

  const missing = required.filter(k => !process.env[k]);
  const missingOptional = optional.filter(k => !process.env[k]);

  if (missing.length > 0) {
    console.error('\n❌ MISSING REQUIRED ENV VARS:');
    missing.forEach(k => console.error(`   - ${k}`));
    console.error('\nCopy .env.example to .env and fill in the values.\n');
    process.exit(1);
  }

  if (missingOptional.length > 0) {
    console.warn('\n⚠️  Optional env vars not set (features will be limited):');
    missingOptional.forEach(k => console.warn(`   - ${k}`));
    console.warn('');
  }

  // Check JWT secrets are strong enough
  if (process.env.JWT_SECRET.length < 32) {
    console.error('❌ JWT_SECRET must be at least 32 characters');
    process.exit(1);
  }

  console.log('✅ Environment validation passed');
};

module.exports = {
  initSentry, captureError, captureMetric,
  healthRouter, backupDatabase, checkForUpdates,
  setupMaintenanceJobs, validateEnvironment,
};
