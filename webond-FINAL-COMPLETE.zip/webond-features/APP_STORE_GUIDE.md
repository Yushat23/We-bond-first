# 📱 WEBOND — APP STORE SUBMISSION GUIDE
## Google Play Store + Apple App Store
### Step-by-step by Yushat

---

## PART A — GOOGLE PLAY STORE

### Prerequisites
- Google Play Developer account ($25 one-time fee)
  → https://play.google.com/console/signup

### Step 1 — Prepare your app

```bash
cd webond-mobile

# Update app.json version
# "version": "1.0.0", "versionCode": 1

# Configure EAS
eas build:configure

# Add your google-services.json (from Firebase Console)
# Place in: webond-mobile/google-services.json
```

### Step 2 — Build release AAB

```bash
# Create production build for Google Play
eas build --platform android --profile production

# This takes 5-10 minutes
# You'll get a download link for the .aab file
```

Your `eas.json` should look like:
```json
{
  "cli": { "version": ">= 5.0.0" },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "preview": {
      "distribution": "internal",
      "android": { "buildType": "apk" }
    },
    "production": {
      "android": { "buildType": "app-bundle" },
      "ios": { "simulator": false }
    }
  },
  "submit": {
    "production": {
      "android": {
        "serviceAccountKeyPath": "./google-play-key.json",
        "track": "production"
      },
      "ios": {
        "appleId": "your@email.com",
        "ascAppId": "your_app_store_connect_id",
        "appleTeamId": "YOUR_TEAM_ID"
      }
    }
  }
}
```

### Step 3 — Create Play Store listing

1. Go to https://play.google.com/console
2. Click **Create app**
3. Fill in:
   - **App name:** Webond — Connect Beyond
   - **Default language:** English
   - **App or game:** App
   - **Free or paid:** Free
4. Complete **Store listing**:

**Short description (80 chars):**
```
Next-gen AI-powered social platform. Connect Beyond. 🌍
```

**Full description (4000 chars):**
```
Webond is the next-generation social media platform that combines the best of Facebook, TikTok, Instagram, WhatsApp, and X — enhanced with built-in AI, real-time features, and end-to-end encryption.

🤖 WEBOND AI
Your personal AI assistant is built right into the app. Write posts, summarise your feed, detect scams, translate content, generate captions, and get smart recommendations — all powered by advanced AI.

📱 FEATURES
• 🏠 Home Feed — Stories, posts, photos, videos with AI summaries
• 🎬 Short Videos — TikTok-style reels with trending sounds
• 💬 Messaging — E2E encrypted DMs, group chats, voice notes
• 📖 Stories — 24-hour ephemeral content with AR filters
• 🔴 Live Streaming — Go live with real-time gifts and reactions
• 👤 Profiles — Customisable with bio, media grid, stats
• 🔍 Discovery — AI-powered search for users, posts, hashtags
• 🌍 Global — Available in 50+ languages with AI translation

🔒 PRIVACY & SECURITY
• End-to-end encrypted messages
• You own your data
• No shadow profiles
• Full GDPR & NDPR compliance

💰 CREATOR ECONOMY
• Fan subscriptions (3 tiers)
• Virtual gifts during live streams
• Brand deal marketplace (coming soon)
• Direct tipping

Built from Abuja, Nigeria 🇳🇬 for the entire world.
Connect Beyond with Webond.
```

### Step 4 — Upload screenshots

Required sizes for Google Play:
- Phone: 1080×1920px (minimum 2, maximum 8)
- 7-inch tablet: 1080×1920px
- 10-inch tablet: 1080×1920px
- Feature graphic: 1024×500px

Take screenshots using:
```bash
# Run app on emulator
eas build --platform android --profile preview
# Install on emulator → take screenshots in Android Studio
```

### Step 5 — Content rating

1. Go to **Policy → App content → Content rating**
2. Complete the questionnaire
3. Webond should get **Teen (T)** rating

### Step 6 — Submit

```bash
# Auto-submit via EAS
eas submit --platform android

# OR manually upload .aab in Play Console
# Releases → Production → Create release → Upload AAB
```

**Review time:** 1–3 days for new apps, faster for updates.

---

## PART B — APPLE APP STORE

### Prerequisites
- Apple Developer account ($99/year)
  → https://developer.apple.com/programs/enroll/
- Mac computer (required for iOS builds with EAS, or use EAS cloud)

### Step 1 — Configure signing

```bash
# Login to EAS
eas login

# Configure credentials (EAS manages certificates automatically)
eas credentials --platform ios

# Or let EAS auto-manage:
# In eas.json, add: "credentialsSource": "remote"
```

### Step 2 — Build IPA

```bash
eas build --platform ios --profile production

# Takes 10-20 minutes on EAS cloud
# Downloads as .ipa file
```

### Step 3 — App Store Connect

1. Go to https://appstoreconnect.apple.com
2. Click **My Apps** → **+** → **New App**
3. Fill in:
   - **Platform:** iOS
   - **Name:** Webond — Connect Beyond
   - **Primary Language:** English
   - **Bundle ID:** com.webond.app *(must match app.json)*
   - **SKU:** WEBOND001

### Step 4 — App Information

**Subtitle (30 chars):**
```
AI-Powered Social Platform
```

**Keywords (100 chars):**
```
social,network,ai,chat,video,reels,stories,messaging,connect,Nigeria,Africa
```

**Support URL:** https://webond.com/support
**Marketing URL:** https://webond.com
**Privacy Policy URL:** https://webond.com/privacy

### Step 5 — Screenshots

Required sizes:
- iPhone 6.7" (1290×2796px) — **Required**
- iPhone 6.5" (1242×2688px) — Required
- iPhone 5.5" (1242×2208px) — Required
- iPad Pro 12.9" (2048×2732px) — If supporting iPad

### Step 6 — App Review Information

**Notes for reviewer:**
```
Demo account for testing:
Email: demo@webond.com
Password: Demo1234!

Note: Social login (Google/Apple) requires production 
credentials. Please use the demo account for full 
feature testing.

AI chat requires network connection. OTP verification 
can be bypassed with code: 123456
```

### Step 7 — Submit

```bash
# Auto-submit via EAS
eas submit --platform ios

# Review time: 1-7 days for new apps
```

---

## PART C — UPDATES (Both Stores)

### React Native updates without App Store review

Use **Expo Updates** for JS-only changes:
```bash
# Push update instantly (no review needed!)
eas update --branch production --message "Fix feed loading"

# Users get update automatically in background
```

For native code changes, submit new build:
```bash
# Bump version in app.json first
eas build --platform all
eas submit --platform all
```

### Automating releases with GitHub Actions

```yaml
# .github/workflows/release.yml
name: Webond Release
on:
  push:
    tags: ['v*']
jobs:
  build-and-submit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npm install -g eas-cli
      - run: npm ci
        working-directory: webond-mobile
      - run: eas build --platform all --non-interactive
        working-directory: webond-mobile
        env:
          EXPO_TOKEN: ${{ secrets.EXPO_TOKEN }}
      - run: eas submit --platform all --non-interactive
        working-directory: webond-mobile
        env:
          EXPO_TOKEN: ${{ secrets.EXPO_TOKEN }}
```

---

## PART D — ASO (App Store Optimisation)

### Tips to rank higher and get more downloads

1. **Title** — Include "social" and "AI" keywords
2. **Screenshots** — Show real features, use text overlays
3. **Ratings** — Prompt users to rate after positive actions
4. **Respond** to every review (Google Play especially)
5. **Update regularly** — Stores reward active apps
6. **Localise** — Add Hausa, Yoruba, Igbo store listings
7. **Feature graphic** — Make it bold and teal-themed

```javascript
// Add in-app rating prompt (add to webond-mobile)
import * as StoreReview from 'expo-store-review';

const promptReview = async () => {
  const isAvailable = await StoreReview.isAvailableAsync();
  if (isAvailable) {
    // Only prompt after user has posted 3+ times
    await StoreReview.requestReview();
  }
};
```

---

**Total time to publish on both stores: ~2 weeks**
*(1 week to prepare, 1 week for review)*
