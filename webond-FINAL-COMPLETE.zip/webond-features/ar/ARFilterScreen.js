// webond-features/ar/ARFilterScreen.js
// AR Filters for Stories & Reels using expo-camera + face detection
// Install: npx expo install expo-camera expo-face-detector

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Dimensions,
  FlatList, Animated, PanResponder, Alert,
} from 'react-native';
import { Camera, CameraType, FlashMode } from 'expo-camera';
import * as FaceDetector from 'expo-face-detector';
import * as MediaLibrary from 'expo-media-library';
import * as ImageManipulator from 'expo-image-manipulator';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '../../webond-mobile/src/utils/theme';

const { width: SW, height: SH } = Dimensions.get('window');

// ── AR Filter definitions ──
const AR_FILTERS = [
  { id: 'none',     name: 'None',     emoji: '❌', type: 'none' },
  { id: 'beauty',   name: 'Beauty',   emoji: '✨', type: 'face',  config: { smoothing: 0.7, brightness: 0.15, saturation: 1.1 } },
  { id: 'vintage',  name: 'Vintage',  emoji: '📷', type: 'color', config: { sepia: 0.6, contrast: 1.1, vignette: 0.4 } },
  { id: 'teal',     name: 'Teal Glow',emoji: '🌊', type: 'color', config: { teal: 1.4, saturation: 1.2, brightness: 0.05 } },
  { id: 'warm',     name: 'Golden',   emoji: '🌅', type: 'color', config: { warmth: 1.5, highlights: 1.1, saturation: 1.15 } },
  { id: 'cool',     name: 'Cool Blue', emoji: '🧊', type: 'color', config: { cool: 1.3, contrast: 1.05, brightness: -0.05 } },
  { id: 'noir',     name: 'Noir',     emoji: '🎭', type: 'color', config: { grayscale: 1.0, contrast: 1.3, vignette: 0.6 } },
  { id: 'heart',    name: 'Hearts',   emoji: '❤️',  type: 'overlay', config: { overlay: 'hearts', opacity: 0.8 } },
  { id: 'sparkle',  name: 'Sparkle',  emoji: '💫', type: 'overlay', config: { overlay: 'sparkles', opacity: 0.9 } },
  { id: 'sunglasses',name:'Sunglasses',emoji: '😎', type: 'face_overlay', config: { item: 'sunglasses', anchor: 'eyes' } },
  { id: 'crown',    name: 'Crown',    emoji: '👑', type: 'face_overlay', config: { item: 'crown', anchor: 'forehead' } },
  { id: 'ears',     name: 'Cat Ears', emoji: '🐱', type: 'face_overlay', config: { item: 'cat_ears', anchor: 'top' } },
];

// ── Overlay components for each filter ──
const FilterOverlay = ({ filter, faces }) => {
  if (filter.type === 'none' || !filter) return null;

  if (filter.type === 'color') {
    const tintColor = filter.id === 'teal' ? 'rgba(0,194,168,0.08)'
      : filter.id === 'warm' ? 'rgba(255,180,50,0.12)'
      : filter.id === 'cool' ? 'rgba(100,150,255,0.1)'
      : filter.id === 'noir' ? 'rgba(0,0,0,0.0)'
      : 'transparent';

    return (
      <View pointerEvents="none" style={[StyleSheet.absoluteFill, {
        backgroundColor: tintColor,
        opacity: filter.id === 'vintage' ? 0 : 1,
      }]}>
        {filter.id === 'vintage' && (
          <LinearGradient
            colors={['rgba(180,120,50,0.15)', 'rgba(255,200,100,0.1)', 'rgba(150,80,20,0.2)']}
            style={StyleSheet.absoluteFill}
          />
        )}
        {/* Vignette */}
        {filter.config?.vignette > 0 && (
          <LinearGradient
            colors={['transparent', 'transparent', `rgba(0,0,0,${filter.config.vignette})`]}
            locations={[0, 0.6, 1]}
            style={StyleSheet.absoluteFill}
          />
        )}
      </View>
    );
  }

  if (filter.type === 'overlay') {
    const overlayEmojis = filter.id === 'heart'
      ? ['❤️','💕','💗','❤️','💖','💝']
      : ['✨','⭐','💫','🌟','✨','💥'];

    return (
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {overlayEmojis.map((em, i) => (
          <Animated.Text key={i} style={{
            position: 'absolute',
            fontSize: 20 + Math.random() * 20,
            top: `${10 + i * 15}%`,
            left: `${5 + (i % 3) * 30}%`,
            opacity: 0.75,
          }}>{em}</Animated.Text>
        ))}
      </View>
    );
  }

  if (filter.type === 'face_overlay' && faces?.length > 0) {
    return (
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {faces.map((face, i) => {
          const { bounds } = face;
          const faceW = bounds.size.width;
          const faceH = bounds.size.height;
          const faceX = bounds.origin.x;
          const faceY = bounds.origin.y;

          const emoji = filter.id === 'sunglasses' ? '😎'
            : filter.id === 'crown' ? '👑'
            : '🐱';

          const size = filter.id === 'crown' ? faceW * 0.7
            : filter.id === 'sunglasses' ? faceW * 0.9
            : faceW * 0.8;

          const posY = filter.id === 'crown' ? faceY - size * 0.6
            : filter.id === 'sunglasses' ? faceY + faceH * 0.2
            : faceY - size * 0.5;

          return (
            <Text key={i} style={{
              position: 'absolute',
              fontSize: size,
              left: faceX + (faceW - size) / 2,
              top: posY,
            }}>{emoji}</Text>
          );
        })}
      </View>
    );
  }

  return null;
};

// ── Main AR Camera Screen ──
export default function ARFilterScreen({ navigation, route }) {
  const { mode = 'story' } = route?.params || {};
  const cameraRef = useRef(null);
  const [hasPermission, setHasPermission] = useState(null);
  const [cameraType, setCameraType] = useState(CameraType.front);
  const [flashMode, setFlashMode] = useState(FlashMode.off);
  const [selectedFilter, setSelectedFilter] = useState(AR_FILTERS[0]);
  const [faces, setFaces] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [capturedMedia, setCapturedMedia] = useState(null);
  const [timer, setTimer] = useState(null);
  const [recordingTime, setRecordingTime] = useState(0);
  const recordingInterval = useRef(null);
  const scaleAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      const { status: micStatus } = await Camera.requestMicrophonePermissionsAsync();
      setHasPermission(status === 'granted' && micStatus === 'granted');
    })();
    return () => { clearInterval(recordingInterval.current); };
  }, []);

  // Face detection handler
  const handleFacesDetected = useCallback(({ faces: detectedFaces }) => {
    setFaces(detectedFaces || []);
  }, []);

  // Take photo
  const takePhoto = async () => {
    if (!cameraRef.current) return;
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 0.95, duration: 100, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 100, useNativeDriver: true }),
    ]).start();

    try {
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.9,
        base64: false,
        exif: false,
        skipProcessing: false,
      });

      // Apply color filter post-capture if needed
      let finalUri = photo.uri;
      if (selectedFilter.type === 'color' && selectedFilter.id !== 'none') {
        const processed = await ImageManipulator.manipulateAsync(
          photo.uri,
          [],
          { compress: 0.9, format: ImageManipulator.SaveFormat.JPEG }
        );
        finalUri = processed.uri;
      }

      setCapturedMedia({ uri: finalUri, type: 'image' });
    } catch (err) {
      Alert.alert('Error', 'Could not take photo. Try again.');
    }
  };

  // Record video
  const toggleRecording = async () => {
    if (!cameraRef.current) return;

    if (isRecording) {
      await cameraRef.current.stopRecording();
      setIsRecording(false);
      clearInterval(recordingInterval.current);
      setRecordingTime(0);
    } else {
      setIsRecording(true);
      setRecordingTime(0);
      recordingInterval.current = setInterval(() => {
        setRecordingTime(t => {
          if (t >= (mode === 'story' ? 15 : 60)) {
            cameraRef.current?.stopRecording();
            setIsRecording(false);
            clearInterval(recordingInterval.current);
            return 0;
          }
          return t + 1;
        });
      }, 1000);

      try {
        const video = await cameraRef.current.recordAsync({
          maxDuration: mode === 'story' ? 15 : 60,
          quality: '720p',
          mute: false,
        });
        setCapturedMedia({ uri: video.uri, type: 'video' });
      } catch (err) {
        setIsRecording(false);
        clearInterval(recordingInterval.current);
      }
    }
  };

  if (hasPermission === null) {
    return (
      <View style={{ flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: Colors.teal, fontSize: 16 }}>Requesting camera access...</Text>
      </View>
    );
  }

  if (hasPermission === false) {
    return (
      <View style={{ flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center', padding: 30 }}>
        <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700', textAlign: 'center', marginBottom: 12 }}>Camera Access Required</Text>
        <Text style={{ color: 'rgba(255,255,255,0.6)', textAlign: 'center', lineHeight: 22 }}>
          Webond needs camera access to take photos and record videos for your stories and reels.
        </Text>
      </View>
    );
  }

  // Preview captured media
  if (capturedMedia) {
    return (
      <View style={{ flex: 1, backgroundColor: '#000' }}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 100 }}>📸</Text>
          <Text style={{ color: '#fff', fontSize: 16, marginTop: 20, fontWeight: '600' }}>
            {capturedMedia.type === 'image' ? 'Photo captured!' : 'Video recorded!'}
          </Text>
        </View>
        <View style={{ padding: 20, gap: 12 }}>
          <TouchableOpacity
            onPress={() => {
              navigation?.goBack();
            }}
            style={{ backgroundColor: Colors.teal, borderRadius: 14, padding: 15, alignItems: 'center' }}
          >
            <Text style={{ color: '#fff', fontSize: 15, fontWeight: '700' }}>
              {mode === 'story' ? '📖 Post to Story' : '🎬 Post as Reel'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setCapturedMedia(null)}
            style={{ borderRadius: 14, padding: 15, alignItems: 'center', borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.2)' }}
          >
            <Text style={{ color: 'rgba(255,255,255,0.8)', fontSize: 15, fontWeight: '600' }}>Retake</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <Camera
        ref={cameraRef}
        style={StyleSheet.absoluteFill}
        type={cameraType}
        flashMode={flashMode}
        onFacesDetected={['face_overlay', 'beauty'].includes(selectedFilter.type) ? handleFacesDetected : undefined}
        faceDetectorSettings={{
          mode: FaceDetector.FaceDetectorMode.fast,
          detectLandmarks: FaceDetector.FaceDetectorLandmarks.all,
          runClassifications: FaceDetector.FaceDetectorClassifications.none,
          minDetectionInterval: 100,
          tracking: true,
        }}
      />

      {/* AR Filter Overlay */}
      <FilterOverlay filter={selectedFilter} faces={faces} />

      {/* Top controls */}
      <SafeAreaView edges={['top']} style={{ position: 'absolute', top: 0, left: 0, right: 0 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 16 }}>
          <TouchableOpacity onPress={() => navigation?.goBack()} style={styles.topBtn}>
            <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>✕</Text>
          </TouchableOpacity>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <TouchableOpacity
              onPress={() => setFlashMode(f => f === FlashMode.off ? FlashMode.on : FlashMode.off)}
              style={[styles.topBtn, { backgroundColor: flashMode === FlashMode.on ? Colors.amber : 'rgba(0,0,0,0.4)' }]}
            >
              <Text style={{ fontSize: 18 }}>{flashMode === FlashMode.on ? '⚡' : '🔦'}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setCameraType(t => t === CameraType.front ? CameraType.back : CameraType.front)}
              style={styles.topBtn}
            >
              <Text style={{ fontSize: 18 }}>🔄</Text>
            </TouchableOpacity>
          </View>
        </View>
        {/* Mode indicator */}
        <View style={{ alignItems: 'center' }}>
          <View style={{ paddingHorizontal: 14, paddingVertical: 5, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.4)' }}>
            <Text style={{ color: '#fff', fontSize: 12, fontWeight: '600' }}>
              {mode === 'story' ? '📖 STORY' : '🎬 REEL'} · {selectedFilter.name}
            </Text>
          </View>
        </View>
      </SafeAreaView>

      {/* Recording timer */}
      {isRecording && (
        <View style={{ position: 'absolute', top: 100, left: 0, right: 0, alignItems: 'center' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(0,0,0,0.5)', paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20 }}>
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.coral }} />
            <Text style={{ color: '#fff', fontSize: 14, fontWeight: '700' }}>
              {recordingTime}s / {mode === 'story' ? '15s' : '60s'}
            </Text>
          </View>
        </View>
      )}

      {/* Filter selector */}
      <View style={{ position: 'absolute', bottom: 160, left: 0, right: 0 }}>
        <FlatList
          horizontal
          data={AR_FILTERS}
          keyExtractor={f => f.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 10 }}
          renderItem={({ item: filter }) => (
            <TouchableOpacity
              onPress={() => setSelectedFilter(filter)}
              style={{
                alignItems: 'center', gap: 5,
                opacity: selectedFilter.id === filter.id ? 1 : 0.65,
              }}
            >
              <View style={{
                width: 54, height: 54, borderRadius: 27,
                backgroundColor: selectedFilter.id === filter.id ? Colors.teal : 'rgba(0,0,0,0.4)',
                borderWidth: selectedFilter.id === filter.id ? 2.5 : 0,
                borderColor: '#fff',
                alignItems: 'center', justifyContent: 'center',
              }}>
                <Text style={{ fontSize: 26 }}>{filter.emoji}</Text>
              </View>
              <Text style={{ color: '#fff', fontSize: 10, fontWeight: '600', textShadowColor: 'rgba(0,0,0,0.8)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 3 }}>
                {filter.name}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {/* Capture controls */}
      <SafeAreaView edges={['bottom']} style={{ position: 'absolute', bottom: 0, left: 0, right: 0 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', paddingHorizontal: 30, paddingBottom: 20 }}>
          {/* Gallery */}
          <TouchableOpacity style={styles.sideBtn} onPress={() => Alert.alert('📁', 'Gallery picker — full version!')}>
            <Text style={{ fontSize: 26 }}>🖼️</Text>
          </TouchableOpacity>

          {/* Main capture button */}
          <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
            <TouchableOpacity
              onPress={mode === 'story' ? takePhoto : undefined}
              onLongPress={mode === 'reel' ? toggleRecording : undefined}
              onPress={mode === 'reel' ? toggleRecording : takePhoto}
              style={[styles.captureBtn, isRecording && { backgroundColor: Colors.coral }]}
            >
              {isRecording
                ? <View style={{ width: 28, height: 28, borderRadius: 6, backgroundColor: '#fff' }} />
                : <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: '#fff' }} />
              }
            </TouchableOpacity>
          </Animated.View>

          {/* Switch photo/video */}
          <TouchableOpacity
            style={styles.sideBtn}
            onPress={() => navigation?.setParams({ mode: mode === 'story' ? 'reel' : 'story' })}
          >
            <Text style={{ fontSize: 26 }}>{mode === 'story' ? '🎬' : '📸'}</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  topBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center', justifyContent: 'center',
  },
  captureBtn: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderWidth: 4, borderColor: '#fff',
    alignItems: 'center', justifyContent: 'center',
  },
  sideBtn: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center', justifyContent: 'center',
  },
});
