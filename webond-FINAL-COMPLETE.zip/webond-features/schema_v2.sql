-- ═══════════════════════════════════════════════════════
-- WEBOND DATABASE — COMPLETE SCHEMA v2.0
-- Includes ALL new tables for every feature
-- Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";    -- Fast text search
CREATE EXTENSION IF NOT EXISTS "unaccent";   -- Search without accents

-- ─────────────────────────────────────────────
-- STEP 1: Add new columns to existing tables
-- ─────────────────────────────────────────────
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS stripe_account_id    VARCHAR(100),
  ADD COLUMN IF NOT EXISTS stripe_customer_id   VARCHAR(100),
  ADD COLUMN IF NOT EXISTS stripe_product_id    VARCHAR(100),
  ADD COLUMN IF NOT EXISTS coin_balance          INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_earned_cents    INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS fcm_token             TEXT,
  ADD COLUMN IF NOT EXISTS is_online             BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS website_url           VARCHAR(255),
  ADD COLUMN IF NOT EXISTS location              VARCHAR(100),
  ADD COLUMN IF NOT EXISTS interests             TEXT[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS is_banned             BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS banned_reason         TEXT,
  ADD COLUMN IF NOT EXISTS warn_count            INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS two_fa_enabled        BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS two_fa_secret         VARCHAR(100);

ALTER TABLE posts
  ADD COLUMN IF NOT EXISTS is_removed    BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS removed_by    UUID REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS removed_at    TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS is_pinned     BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_featured   BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS repost_of     UUID REFERENCES posts(id),
  ADD COLUMN IF NOT EXISTS bookmark_count INTEGER DEFAULT 0;

-- ─────────────────────────────────────────────
-- PUSH NOTIFICATION TOKENS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS push_tokens (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  token        TEXT NOT NULL UNIQUE,
  platform     VARCHAR(10) DEFAULT 'unknown', -- ios, android, web
  is_active    BOOLEAN DEFAULT true,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_push_tokens_user ON push_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_push_tokens_active ON push_tokens(is_active);

-- ─────────────────────────────────────────────
-- MEDIA TABLE (uploaded files)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS media (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  url           TEXT NOT NULL,
  thumbnail_url TEXT,
  public_id     VARCHAR(255) UNIQUE,
  type          VARCHAR(10) DEFAULT 'image', -- image, video, audio
  size          BIGINT,
  duration      REAL,
  width         INTEGER,
  height        INTEGER,
  hls_url       TEXT,
  sd_url        TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_media_user ON media(user_id);

-- ─────────────────────────────────────────────
-- LIVE STREAMS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS live_streams (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  stream_id        VARCHAR(100) UNIQUE NOT NULL,
  host_id          UUID REFERENCES users(id) ON DELETE CASCADE,
  title            VARCHAR(200),
  category         VARCHAR(50) DEFAULT 'General',
  thumbnail_url    TEXT,
  status           VARCHAR(20) DEFAULT 'live', -- live, ended, scheduled
  viewer_count     INTEGER DEFAULT 0,
  peak_viewers     INTEGER DEFAULT 0,
  duration_seconds INTEGER DEFAULT 0,
  total_gifts      INTEGER DEFAULT 0,
  replay_url       TEXT,
  scheduled_at     TIMESTAMPTZ,
  started_at       TIMESTAMPTZ DEFAULT NOW(),
  ended_at         TIMESTAMPTZ,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_livestreams_host ON live_streams(host_id);
CREATE INDEX IF NOT EXISTS idx_livestreams_status ON live_streams(status);

-- ─────────────────────────────────────────────
-- STREAM GIFTS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stream_gifts (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  stream_id   VARCHAR(100) REFERENCES live_streams(stream_id) ON DELETE CASCADE,
  sender_id   UUID REFERENCES users(id) ON DELETE SET NULL,
  host_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  gift_type   VARCHAR(30) NOT NULL,
  coins       INTEGER NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_gifts_stream ON stream_gifts(stream_id);
CREATE INDEX IF NOT EXISTS idx_gifts_host ON stream_gifts(host_id);

-- ─────────────────────────────────────────────
-- SUBSCRIPTIONS (Creator → Fan tiers)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscriptions (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  subscriber_id           UUID REFERENCES users(id) ON DELETE CASCADE,
  creator_id              UUID REFERENCES users(id) ON DELETE CASCADE,
  tier                    VARCHAR(20) NOT NULL, -- fan, supporter, vip
  price                   INTEGER NOT NULL,
  platform_fee            INTEGER DEFAULT 0,
  stripe_subscription_id  VARCHAR(100) UNIQUE,
  status                  VARCHAR(20) DEFAULT 'active',
  current_period_end      TIMESTAMPTZ,
  cancel_at_period_end    BOOLEAN DEFAULT false,
  created_at              TIMESTAMPTZ DEFAULT NOW(),
  updated_at              TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(subscriber_id, creator_id)
);
CREATE INDEX IF NOT EXISTS idx_subs_subscriber ON subscriptions(subscriber_id);
CREATE INDEX IF NOT EXISTS idx_subs_creator ON subscriptions(creator_id);
CREATE INDEX IF NOT EXISTS idx_subs_status ON subscriptions(status);

-- ─────────────────────────────────────────────
-- TRANSACTIONS (tips, purchases, payouts)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS transactions (
  id                        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id                 UUID REFERENCES users(id) ON DELETE SET NULL,
  recipient_id              UUID REFERENCES users(id) ON DELETE SET NULL,
  type                      VARCHAR(30) NOT NULL, -- tip, subscription, coin_purchase, payout
  amount                    INTEGER NOT NULL,
  platform_fee              INTEGER DEFAULT 0,
  creator_amount            INTEGER DEFAULT 0,
  currency                  VARCHAR(10) DEFAULT 'usd',
  stripe_payment_intent_id  VARCHAR(100),
  stripe_transfer_id        VARCHAR(100),
  message                   TEXT,
  status                    VARCHAR(20) DEFAULT 'pending', -- pending, completed, failed, refunded
  created_at                TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tx_sender ON transactions(sender_id);
CREATE INDEX IF NOT EXISTS idx_tx_recipient ON transactions(recipient_id);
CREATE INDEX IF NOT EXISTS idx_tx_status ON transactions(status);

-- ─────────────────────────────────────────────
-- COIN TRANSACTIONS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS coin_transactions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
  type            VARCHAR(30) NOT NULL, -- purchase, gift, earned, refund
  coins           INTEGER NOT NULL,
  amount_paid     INTEGER DEFAULT 0,
  stripe_payment_id VARCHAR(100),
  related_id      UUID,
  balance_after   INTEGER NOT NULL,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_coins_user ON coin_transactions(user_id);

-- ─────────────────────────────────────────────
-- CONTENT REPORTS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reports (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  reported_user  UUID REFERENCES users(id) ON DELETE CASCADE,
  post_id        UUID REFERENCES posts(id) ON DELETE CASCADE,
  comment_id     UUID REFERENCES comments(id) ON DELETE CASCADE,
  reason         VARCHAR(50) NOT NULL, -- spam, harassment, misinformation, nsfw, hate, other
  description    TEXT,
  severity       VARCHAR(10) DEFAULT 'medium', -- low, medium, high
  status         VARCHAR(20) DEFAULT 'pending', -- pending, reviewed, resolved, dismissed
  reviewed_by    UUID REFERENCES users(id),
  reviewed_at    TIMESTAMPTZ,
  action_taken   VARCHAR(50),
  created_at     TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_reporter ON reports(reporter_id);

-- ─────────────────────────────────────────────
-- HASHTAGS (for trending)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS hashtags (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tag          VARCHAR(100) UNIQUE NOT NULL,
  post_count   INTEGER DEFAULT 1,
  week_count   INTEGER DEFAULT 1,
  is_trending  BOOLEAN DEFAULT false,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_hashtags_tag ON hashtags(tag);
CREATE INDEX IF NOT EXISTS idx_hashtags_trending ON hashtags(is_trending, week_count DESC);

-- ─────────────────────────────────────────────
-- USER BLOCKS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS blocks (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  blocker_id   UUID REFERENCES users(id) ON DELETE CASCADE,
  blocked_id   UUID REFERENCES users(id) ON DELETE CASCADE,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(blocker_id, blocked_id)
);

-- ─────────────────────────────────────────────
-- REPOSTS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reposts (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  post_id     UUID REFERENCES posts(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, post_id)
);

-- ─────────────────────────────────────────────
-- STORY VIEWS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS story_views (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  story_id   UUID REFERENCES stories(id) ON DELETE CASCADE,
  viewer_id  UUID REFERENCES users(id) ON DELETE CASCADE,
  viewed_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(story_id, viewer_id)
);

-- ─────────────────────────────────────────────
-- ADMIN LOGS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admin_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id    UUID REFERENCES users(id),
  action      VARCHAR(100) NOT NULL,
  target_type VARCHAR(30), -- user, post, comment, stream
  target_id   UUID,
  details     JSONB,
  ip_address  VARCHAR(45),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_admin_logs_admin ON admin_logs(admin_id);

-- ─────────────────────────────────────────────
-- AR FILTER TEMPLATES
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ar_filters (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name         VARCHAR(100) NOT NULL,
  creator_id   UUID REFERENCES users(id),
  thumbnail    TEXT,
  model_url    TEXT,
  config_json  JSONB,
  use_count    INTEGER DEFAULT 0,
  is_active    BOOLEAN DEFAULT true,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────
-- USEFUL VIEWS
-- ─────────────────────────────────────────────

-- Trending hashtags (last 7 days)
CREATE OR REPLACE VIEW trending_hashtags AS
  SELECT tag, week_count, post_count
  FROM hashtags
  WHERE updated_at > NOW() - INTERVAL '7 days'
  ORDER BY week_count DESC
  LIMIT 20;

-- Active live streams with host info
CREATE OR REPLACE VIEW active_streams AS
  SELECT ls.*, u.name as host_name, u.username as host_username,
         u.avatar_class, u.is_verified
  FROM live_streams ls
  JOIN users u ON u.id = ls.host_id
  WHERE ls.status = 'live'
  ORDER BY ls.viewer_count DESC;

-- Creator earnings summary
CREATE OR REPLACE VIEW creator_earnings AS
  SELECT
    recipient_id as creator_id,
    COUNT(*) as total_transactions,
    SUM(creator_amount) as total_earned,
    SUM(platform_fee) as total_fees,
    SUM(CASE WHEN type = 'tip' THEN creator_amount ELSE 0 END) as tips_earned
  FROM transactions
  WHERE status = 'completed'
  GROUP BY recipient_id;

-- ─────────────────────────────────────────────
-- FUNCTIONS & TRIGGERS
-- ─────────────────────────────────────────────

-- Auto-update hashtag counts when post is created
CREATE OR REPLACE FUNCTION update_hashtag_counts()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.tags IS NOT NULL THEN
    FOREACH tag IN ARRAY NEW.tags LOOP
      INSERT INTO hashtags (tag, post_count, week_count)
      VALUES (lower(tag), 1, 1)
      ON CONFLICT (tag) DO UPDATE
        SET post_count = hashtags.post_count + 1,
            week_count = hashtags.week_count + 1,
            updated_at = NOW();
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER post_hashtags_trigger
  AFTER INSERT ON posts
  FOR EACH ROW EXECUTE FUNCTION update_hashtag_counts();

-- Auto-update coin balance from transactions
CREATE OR REPLACE FUNCTION update_user_earnings()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    UPDATE users
    SET total_earned_cents = total_earned_cents + NEW.creator_amount
    WHERE id = NEW.recipient_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER earnings_trigger
  AFTER UPDATE ON transactions
  FOR EACH ROW EXECUTE FUNCTION update_user_earnings();

-- Reset trending weekly counts
CREATE OR REPLACE FUNCTION reset_weekly_trending()
RETURNS void AS $$
BEGIN
  UPDATE hashtags SET week_count = 0 WHERE updated_at < NOW() - INTERVAL '7 days';
  UPDATE hashtags SET is_trending = (week_count > 10);
END;
$$ LANGUAGE plpgsql;

-- ─────────────────────────────────────────────
-- REALTIME (enable all important tables)
-- ─────────────────────────────────────────────
ALTER PUBLICATION supabase_realtime ADD TABLE live_streams;
ALTER PUBLICATION supabase_realtime ADD TABLE stream_gifts;
ALTER PUBLICATION supabase_realtime ADD TABLE stories;
ALTER PUBLICATION supabase_realtime ADD TABLE reposts;
ALTER PUBLICATION supabase_realtime ADD TABLE bookmarks;

-- ─────────────────────────────────────────────
-- ROW LEVEL SECURITY (new tables)
-- ─────────────────────────────────────────────
ALTER TABLE push_tokens    ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions  ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions   ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports        ENABLE ROW LEVEL SECURITY;
ALTER TABLE blocks         ENABLE ROW LEVEL SECURITY;

-- Users can only see their own tokens
CREATE POLICY "Own push tokens only" ON push_tokens
  FOR ALL USING (user_id::text = auth.uid()::text);

-- Users can see their own subscriptions
CREATE POLICY "Own subscriptions" ON subscriptions
  FOR SELECT USING (subscriber_id::text = auth.uid()::text OR creator_id::text = auth.uid()::text);

-- Users can see their own transactions
CREATE POLICY "Own transactions" ON transactions
  FOR SELECT USING (sender_id::text = auth.uid()::text OR recipient_id::text = auth.uid()::text);

-- Users can create reports
CREATE POLICY "Anyone can report" ON reports FOR INSERT WITH CHECK (reporter_id::text = auth.uid()::text);

-- ─────────────────────────────────────────────
-- SAMPLE SEED DATA (optional, for testing)
-- ─────────────────────────────────────────────
-- Insert test AR filters
INSERT INTO ar_filters (name, thumbnail, config_json, is_active) VALUES
  ('Teal Glow',     '/filters/teal-glow.png',    '{"type":"color_grade","teal":1.2,"saturation":1.1}', true),
  ('Vintage',       '/filters/vintage.png',       '{"type":"lut","file":"vintage.cube","strength":0.8}', true),
  ('Beauty',        '/filters/beauty.png',        '{"type":"face","smoothing":0.6,"brightness":0.1}',   true),
  ('Sunlight',      '/filters/sunlight.png',      '{"type":"color_grade","warmth":1.3,"highlights":1.1}',true),
  ('Night Mode',    '/filters/night.png',         '{"type":"color_grade","brightness":-0.1,"contrast":1.2}',true)
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────────
-- DONE ✅
-- Your Webond database is complete!
-- Total tables: 20
-- Total indexes: 30+
-- Real-time enabled: 7 tables
-- ─────────────────────────────────────────────
