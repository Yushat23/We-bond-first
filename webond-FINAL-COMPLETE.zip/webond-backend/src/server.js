// src/server.js — Webond Backend Server
require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

// Routes
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const postRoutes = require('./routes/posts');
const messageRoutes = require('./routes/messages');
const notifRoutes = require('./routes/notifications');
const aiRoutes = require('./routes/ai');
const storyRoutes = require('./routes/stories');
const searchRoutes = require('./routes/search');

// Middleware
const { authenticateToken } = require('./middleware/auth');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const server = http.createServer(app);

// ── Socket.io setup ──
const io = new Server(server, {
  cors: { origin: process.env.FRONTEND_URL || 'http://localhost:3000', methods: ['GET','POST'] },
});

// Make io accessible in routes
app.set('io', io);

// ── Middleware ──
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(cors({
  origin: [process.env.FRONTEND_URL || 'http://localhost:3000', /\.vercel\.app$/, /\.netlify\.app$/],
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
if (process.env.NODE_ENV !== 'test') app.use(morgan('dev'));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
  message: { error: 'Too many requests. Please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Stricter limit for auth
const authLimiter = rateLimit({ windowMs: 900000, max: 10, message: { error: 'Too many auth attempts.' } });
app.use('/api/auth/', authLimiter);

// ── Health check ──
app.get('/health', (req, res) => res.json({ status: 'ok', app: 'Webond API', version: '1.0.0', time: new Date().toISOString() }));
app.get('/', (req, res) => res.json({ message: '🌍 Webond API — Connect Beyond', docs: '/api/docs' }));

// ── API Routes ──
app.use('/api/auth', authRoutes);
app.use('/api/users', authenticateToken, userRoutes);
app.use('/api/posts', authenticateToken, postRoutes);
app.use('/api/messages', authenticateToken, messageRoutes);
app.use('/api/notifications', authenticateToken, notifRoutes);
app.use('/api/ai', authenticateToken, aiRoutes);
app.use('/api/stories', authenticateToken, storyRoutes);
app.use('/api/search', authenticateToken, searchRoutes);

// ── Socket.io Real-time ──
const onlineUsers = new Map(); // userId -> socketId

io.on('connection', (socket) => {
  console.log(`🔌 Socket connected: ${socket.id}`);

  // User comes online
  socket.on('user:online', (userId) => {
    onlineUsers.set(userId, socket.id);
    socket.userId = userId;
    io.emit('user:status', { userId, online: true });
    console.log(`👤 User ${userId} is online`);
  });

  // Join a conversation room
  socket.on('room:join', (roomId) => {
    socket.join(roomId);
  });

  // Send a message in real-time
  socket.on('message:send', async (data) => {
    const { conversationId, message } = data;
    // Broadcast to all in the room
    socket.to(conversationId).emit('message:received', message);
  });

  // Typing indicator
  socket.on('typing:start', (data) => {
    socket.to(data.conversationId).emit('typing:start', { userId: socket.userId });
  });
  socket.on('typing:stop', (data) => {
    socket.to(data.conversationId).emit('typing:stop', { userId: socket.userId });
  });

  // Post like in real-time
  socket.on('post:like', (data) => {
    io.emit('post:like_update', data);
  });

  // New post notification
  socket.on('post:new', (post) => {
    socket.broadcast.emit('post:new', post);
  });

  // Disconnect
  socket.on('disconnect', () => {
    if (socket.userId) {
      onlineUsers.delete(socket.userId);
      io.emit('user:status', { userId: socket.userId, online: false });
    }
    console.log(`❌ Socket disconnected: ${socket.id}`);
  });
});

// Export for use in routes
app.set('onlineUsers', onlineUsers);

// ── Error handler ──
app.use(errorHandler);

// ── 404 ──
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found', path: req.path });
});

// ── Start server ──
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`\n🚀 Webond API running on port ${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`📡 Real-time: Socket.io enabled`);
  console.log(`🤖 AI: Claude ${process.env.ANTHROPIC_API_KEY ? 'connected' : 'not configured'}`);
  console.log(`🗄️  DB: Supabase ${process.env.SUPABASE_URL ? 'connected' : 'not configured'}\n`);
});

module.exports = { app, server, io };
