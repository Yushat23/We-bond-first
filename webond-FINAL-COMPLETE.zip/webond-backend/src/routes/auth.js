// src/routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const validator = require('validator');
const { supabase } = require('../../config/supabase');

const router = express.Router();

// ── Token helpers ──
const signAccess = (userId) =>
  jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '15m' });

const signRefresh = (userId) =>
  jwt.sign({ userId }, process.env.JWT_REFRESH_SECRET, { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d' });

// ── OTP helper ──
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// Send OTP email (uses Resend.com)
const sendOTPEmail = async (email, name, otp) => {
  if (!process.env.RESEND_API_KEY) {
    console.log(`📧 [DEV] OTP for ${email}: ${otp}`);
    return;
  }
  try {
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM || 'noreply@webond.com',
        to: email,
        subject: `${otp} is your Webond verification code`,
        html: `
          <div style="font-family:Inter,sans-serif;max-width:480px;margin:0 auto;padding:40px 20px">
            <div style="font-size:28px;font-weight:900;color:#1A1A2E;letter-spacing:-1px">web<span style="color:#00C2A8">ond</span></div>
            <h2 style="margin-top:24px;color:#1A1A2E">Hi ${name} 👋</h2>
            <p style="color:#5A5A7A;line-height:1.6">Your Webond verification code is:</p>
            <div style="background:#E6FAF8;border-radius:16px;padding:24px;text-align:center;margin:20px 0">
              <div style="font-size:40px;font-weight:900;color:#00A892;letter-spacing:8px">${otp}</div>
            </div>
            <p style="color:#9A9AB0;font-size:13px">This code expires in 10 minutes. Never share it with anyone.</p>
            <p style="color:#9A9AB0;font-size:12px;margin-top:32px">© 2025 Webond — Connect Beyond 🌍</p>
          </div>
        `,
      }),
    });
  } catch (e) {
    console.error('Email send failed:', e.message);
  }
};

// ═══════════════════════════
// POST /api/auth/register
// ═══════════════════════════
router.post('/register', async (req, res, next) => {
  try {
    const { name, username, email, password, phone, dob, avatarClass } = req.body;

    // Validate
    if (!name || !username || !email || !password) {
      return res.status(400).json({ error: 'Name, username, email and password are required' });
    }
    if (!validator.isEmail(email)) return res.status(400).json({ error: 'Invalid email' });
    if (password.length < 8) return res.status(400).json({ error: 'Password must be 8+ characters' });
    if (!/^[a-zA-Z0-9_]{3,30}$/.test(username)) return res.status(400).json({ error: 'Invalid username — 3-30 chars, letters/numbers/underscore' });

    // Check existing
    const { data: existing } = await supabase.from('users').select('id').or(`email.eq.${email},username.eq.${username}`).single();
    if (existing) return res.status(409).json({ error: 'Email or username already taken' });

    // Hash password
    const password_hash = await bcrypt.hash(password, 12);

    // Generate OTP
    const otp = generateOTP();
    const otp_expires_at = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 min

    // Create user
    const { data: user, error } = await supabase.from('users').insert({
      name: name.trim(),
      username: username.toLowerCase().trim(),
      email: email.toLowerCase().trim(),
      password_hash,
      phone: phone || null,
      avatar_class: avatarClass || 'av-g',
      otp_code: otp,
      otp_expires_at,
      email_verified: false,
    }).select('id, name, username, email').single();

    if (error) throw error;

    // Send OTP email
    await sendOTPEmail(email, name, otp);

    res.status(201).json({
      message: 'Account created. Check your email for the verification code.',
      userId: user.id,
      email: user.email,
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/auth/verify-otp
// ═══════════════════════════
router.post('/verify-otp', async (req, res, next) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) return res.status(400).json({ error: 'Email and OTP required' });

    const { data: user, error } = await supabase
      .from('users')
      .select('id, name, username, email, otp_code, otp_expires_at, avatar_class, bio')
      .eq('email', email.toLowerCase())
      .single();

    if (error || !user) return res.status(404).json({ error: 'User not found' });
    if (user.otp_code !== otp) return res.status(400).json({ error: 'Invalid verification code' });
    if (new Date(user.otp_expires_at) < new Date()) return res.status(400).json({ error: 'Code expired. Request a new one.' });

    // Mark email verified
    await supabase.from('users').update({ email_verified: true, otp_code: null, otp_expires_at: null }).eq('id', user.id);

    // Issue tokens
    const accessToken = signAccess(user.id);
    const refreshToken = signRefresh(user.id);
    await supabase.from('users').update({ refresh_token: refreshToken }).eq('id', user.id);

    res.json({
      message: 'Email verified successfully!',
      accessToken,
      refreshToken,
      user: { id: user.id, name: user.name, username: user.username, email: user.email, avatarClass: user.avatar_class, bio: user.bio },
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/auth/login
// ═══════════════════════════
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const { data: user, error } = await supabase
      .from('users')
      .select('id, name, username, email, password_hash, email_verified, avatar_class, bio, follower_count, following_count, post_count')
      .eq('email', email.toLowerCase())
      .single();

    if (error || !user) return res.status(401).json({ error: 'Invalid email or password' });
    if (!user.email_verified) return res.status(403).json({ error: 'Please verify your email first', code: 'EMAIL_NOT_VERIFIED' });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid email or password' });

    const accessToken = signAccess(user.id);
    const refreshToken = signRefresh(user.id);

    await supabase.from('users').update({ refresh_token: refreshToken, last_seen: new Date().toISOString() }).eq('id', user.id);

    res.json({
      message: 'Welcome back to Webond! 🌍',
      accessToken,
      refreshToken,
      user: {
        id: user.id, name: user.name, username: user.username, email: user.email,
        avatarClass: user.avatar_class, bio: user.bio,
        followerCount: user.follower_count, followingCount: user.following_count, postCount: user.post_count,
      },
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/auth/social
// (Google, Apple, Meta, X)
// ═══════════════════════════
router.post('/social', async (req, res, next) => {
  try {
    const { provider, providerId, email, name, avatarUrl } = req.body;
    if (!provider || !providerId || !email) return res.status(400).json({ error: 'Provider, providerId, and email required' });

    // Check if user exists
    let { data: user } = await supabase.from('users').select('*').eq('email', email.toLowerCase()).single();

    if (!user) {
      // Auto-create username from name
      const baseUsername = name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20);
      let username = baseUsername;
      let suffix = 1;
      while (true) {
        const { data: existing } = await supabase.from('users').select('id').eq('username', username).single();
        if (!existing) break;
        username = `${baseUsername}${suffix++}`;
      }

      const { data: newUser, error } = await supabase.from('users').insert({
        name: name.trim(),
        username,
        email: email.toLowerCase(),
        provider,
        provider_id: providerId,
        avatar_url: avatarUrl || null,
        email_verified: true,
        password_hash: await bcrypt.hash(uuidv4(), 10), // random password for social users
      }).select('id, name, username, email, avatar_class, bio').single();

      if (error) throw error;
      user = newUser;
    }

    const accessToken = signAccess(user.id);
    const refreshToken = signRefresh(user.id);
    await supabase.from('users').update({ refresh_token: refreshToken, last_seen: new Date().toISOString() }).eq('id', user.id);

    res.json({
      message: `Signed in with ${provider}! Welcome to Webond 🌍`,
      accessToken,
      refreshToken,
      user: { id: user.id, name: user.name, username: user.username, email: user.email, avatarClass: user.avatar_class, bio: user.bio },
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/auth/refresh
// ═══════════════════════════
router.post('/refresh', async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ error: 'Refresh token required' });

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const { data: user } = await supabase.from('users').select('id, refresh_token').eq('id', decoded.userId).single();

    if (!user || user.refresh_token !== refreshToken) return res.status(401).json({ error: 'Invalid refresh token' });

    const newAccessToken = signAccess(user.id);
    const newRefreshToken = signRefresh(user.id);
    await supabase.from('users').update({ refresh_token: newRefreshToken }).eq('id', user.id);

    res.json({ accessToken: newAccessToken, refreshToken: newRefreshToken });
  } catch (err) {
    if (err.name === 'TokenExpiredError') return res.status(401).json({ error: 'Refresh token expired, please login again' });
    next(err);
  }
});

// ═══════════════════════════
// POST /api/auth/forgot-password
// ═══════════════════════════
router.post('/forgot-password', async (req, res, next) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required' });

    const { data: user } = await supabase.from('users').select('id, name').eq('email', email.toLowerCase()).single();
    if (!user) return res.json({ message: 'If that email exists, a reset link was sent.' }); // Don't reveal existence

    const otp = generateOTP();
    const otp_expires_at = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    await supabase.from('users').update({ otp_code: otp, otp_expires_at }).eq('id', user.id);
    await sendOTPEmail(email, user.name, otp);

    res.json({ message: 'Password reset code sent to your email.' });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/auth/reset-password
// ═══════════════════════════
router.post('/reset-password', async (req, res, next) => {
  try {
    const { email, otp, newPassword } = req.body;
    if (!email || !otp || !newPassword) return res.status(400).json({ error: 'Email, OTP and new password required' });
    if (newPassword.length < 8) return res.status(400).json({ error: 'Password must be 8+ characters' });

    const { data: user } = await supabase.from('users').select('id, otp_code, otp_expires_at').eq('email', email).single();
    if (!user || user.otp_code !== otp) return res.status(400).json({ error: 'Invalid or expired reset code' });
    if (new Date(user.otp_expires_at) < new Date()) return res.status(400).json({ error: 'Code expired' });

    const password_hash = await bcrypt.hash(newPassword, 12);
    await supabase.from('users').update({ password_hash, otp_code: null, otp_expires_at: null }).eq('id', user.id);

    res.json({ message: 'Password reset successfully! Please login.' });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/auth/logout
// ═══════════════════════════
router.post('/logout', async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET).userId;
      await supabase.from('users').update({ refresh_token: null }).eq('id', decoded);
    }
    res.json({ message: 'Logged out successfully' });
  } catch (err) {
    res.json({ message: 'Logged out' }); // Always succeed
  }
});

// ═══════════════════════════
// GET /api/auth/check-username
// ═══════════════════════════
router.get('/check-username/:username', async (req, res, next) => {
  try {
    const { username } = req.params;
    if (!/^[a-zA-Z0-9_]{3,30}$/.test(username)) return res.json({ available: false, error: 'Invalid username format' });

    const { data } = await supabase.from('users').select('id').eq('username', username.toLowerCase()).single();
    res.json({ available: !data, username: username.toLowerCase() });
  } catch (err) {
    res.json({ available: true });
  }
});

module.exports = router;
