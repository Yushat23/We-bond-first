// src/routes/posts.js
const express = require('express');
const { supabase } = require('../../config/supabase');

const router = express.Router();

// ═══════════════════════════
// GET /api/posts/feed
// Get home feed (following + explore)
// ═══════════════════════════
router.get('/feed', async (req, res, next) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const userId = req.user.id;

    // Get IDs of people user follows
    const { data: follows } = await supabase
      .from('follows')
      .select('following_id')
      .eq('follower_id', userId);

    const followingIds = follows?.map(f => f.following_id) || [];
    followingIds.push(userId); // Include own posts

    // Fetch posts with user info
    const { data: posts, error, count } = await supabase
      .from('posts')
      .select(`
        *,
        user:users(id, name, username, avatar_class, avatar_url, is_verified),
        likes!inner(user_id)
      `, { count: 'exact' })
      .in('user_id', followingIds.length > 0 ? followingIds : [userId])
      .eq('privacy', 'public')
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    // Check which posts current user liked
    const { data: userLikes } = await supabase
      .from('likes')
      .select('post_id')
      .eq('user_id', userId)
      .in('post_id', posts?.map(p => p.id) || []);

    const likedIds = new Set(userLikes?.map(l => l.post_id) || []);

    // Check bookmarks
    const { data: userBookmarks } = await supabase
      .from('bookmarks')
      .select('post_id')
      .eq('user_id', userId)
      .in('post_id', posts?.map(p => p.id) || []);

    const bookmarkedIds = new Set(userBookmarks?.map(b => b.post_id) || []);

    const formattedPosts = (posts || []).map(p => ({
      id: p.id,
      content: p.content,
      mediaUrls: p.media_urls,
      tags: p.tags,
      privacy: p.privacy,
      likeCount: p.like_count,
      commentCount: p.comment_count,
      shareCount: p.share_count,
      viewCount: p.view_count,
      aiSummary: p.ai_summary,
      location: p.location,
      createdAt: p.created_at,
      user: p.user,
      isLiked: likedIds.has(p.id),
      isBookmarked: bookmarkedIds.has(p.id),
    }));

    res.json({ posts: formattedPosts, total: count, page: parseInt(page), hasMore: offset + limit < count });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/posts
// Create a new post
// ═══════════════════════════
router.post('/', async (req, res, next) => {
  try {
    const { content, mediaUrls = [], tags = [], privacy = 'public', location } = req.body;
    if (!content?.trim()) return res.status(400).json({ error: 'Content is required' });
    if (content.length > 5000) return res.status(400).json({ error: 'Post too long (max 5000 chars)' });

    // Extract hashtags from content
    const hashtagMatches = content.match(/#[a-zA-Z0-9_]+/g) || [];
    const allTags = [...new Set([...tags, ...hashtagMatches.map(t => t.slice(1))])];

    const { data: post, error } = await supabase.from('posts').insert({
      user_id: req.user.id,
      content: content.trim(),
      media_urls: mediaUrls,
      tags: allTags,
      privacy,
      location: location || null,
    }).select(`*, user:users(id, name, username, avatar_class, is_verified)`).single();

    if (error) throw error;

    // Increment user's post count
    await supabase.rpc('increment', { table: 'users', column: 'post_count', row_id: req.user.id }).catch(() => {});

    // Broadcast new post via Socket.io
    const io = req.app.get('io');
    io?.emit('post:new', { ...post, isLiked: false, isBookmarked: false });

    res.status(201).json({ message: 'Post created!', post: { ...post, isLiked: false, isBookmarked: false } });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/posts/:id/like
// Toggle like on a post
// ═══════════════════════════
router.post('/:id/like', async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    // Check if already liked
    const { data: existing } = await supabase.from('likes').select('id').eq('user_id', userId).eq('post_id', id).single();

    if (existing) {
      // Unlike
      await supabase.from('likes').delete().eq('user_id', userId).eq('post_id', id);
      await supabase.from('posts').update({ like_count: supabase.rpc('greatest', { val: 0 }) }).eq('id', id);
      // Simpler: just decrement
      const { data: post } = await supabase.from('posts').select('like_count').eq('id', id).single();
      await supabase.from('posts').update({ like_count: Math.max(0, (post?.like_count || 1) - 1) }).eq('id', id);

      req.app.get('io')?.emit('post:like_update', { postId: id, liked: false, userId });
      return res.json({ liked: false, message: 'Post unliked' });
    } else {
      // Like
      await supabase.from('likes').insert({ user_id: userId, post_id: id });
      const { data: post } = await supabase.from('posts').select('like_count, user_id').eq('id', id).single();
      await supabase.from('posts').update({ like_count: (post?.like_count || 0) + 1 }).eq('id', id);

      // Create notification for post owner
      if (post?.user_id !== userId) {
        await supabase.from('notifications').insert({ user_id: post.user_id, actor_id: userId, type: 'like', post_id: id });
      }

      req.app.get('io')?.emit('post:like_update', { postId: id, liked: true, userId });
      return res.json({ liked: true, message: 'Post liked!' });
    }
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// GET /api/posts/:id/comments
// ═══════════════════════════
router.get('/:id/comments', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const { data: comments, error } = await supabase
      .from('comments')
      .select(`*, user:users(id, name, username, avatar_class, is_verified)`)
      .eq('post_id', id)
      .is('parent_id', null)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;
    res.json({ comments: comments || [] });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/posts/:id/comments
// ═══════════════════════════
router.post('/:id/comments', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { content, parentId } = req.body;
    if (!content?.trim()) return res.status(400).json({ error: 'Comment content required' });

    const { data: comment, error } = await supabase.from('comments').insert({
      user_id: req.user.id,
      post_id: id,
      content: content.trim(),
      parent_id: parentId || null,
    }).select(`*, user:users(id, name, username, avatar_class)`).single();

    if (error) throw error;

    // Update comment count
    const { data: post } = await supabase.from('posts').select('comment_count, user_id').eq('id', id).single();
    await supabase.from('posts').update({ comment_count: (post?.comment_count || 0) + 1 }).eq('id', id);

    // Notify post owner
    if (post?.user_id !== req.user.id) {
      await supabase.from('notifications').insert({ user_id: post.user_id, actor_id: req.user.id, type: 'comment', post_id: id, comment_id: comment.id });
    }

    req.app.get('io')?.to(`post:${id}`).emit('comment:new', comment);
    res.status(201).json({ comment });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// POST /api/posts/:id/bookmark
// ═══════════════════════════
router.post('/:id/bookmark', async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const { data: existing } = await supabase.from('bookmarks').select('id').eq('user_id', userId).eq('post_id', id).single();

    if (existing) {
      await supabase.from('bookmarks').delete().eq('user_id', userId).eq('post_id', id);
      return res.json({ bookmarked: false });
    } else {
      await supabase.from('bookmarks').insert({ user_id: userId, post_id: id });
      return res.json({ bookmarked: true });
    }
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════
// DELETE /api/posts/:id
// ═══════════════════════════
router.delete('/:id', async (req, res, next) => {
  try {
    const { data: post } = await supabase.from('posts').select('user_id').eq('id', req.params.id).single();
    if (!post) return res.status(404).json({ error: 'Post not found' });
    if (post.user_id !== req.user.id) return res.status(403).json({ error: 'Not authorized' });

    await supabase.from('posts').delete().eq('id', req.params.id);
    res.json({ message: 'Post deleted' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
