// src/routes/messages.js
const express = require('express');
const { supabase } = require('../../config/supabase');
const router = express.Router();

// GET /api/messages/conversations
router.get('/conversations', async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { data, error } = await supabase.from('conversations')
      .select('*').contains('participant_ids', [userId])
      .order('last_message_at', { ascending: false });
    if (error) throw error;

    // Enrich with other participant's info
    const enriched = await Promise.all((data || []).map(async (conv) => {
      const otherId = conv.participant_ids.find(id => id !== userId);
      const { data: other } = await supabase.from('users').select('id,name,username,avatar_class,avatar_url').eq('id', otherId).single();
      const { count } = await supabase.from('messages').select('id', { count: 'exact', head: true }).eq('conversation_id', conv.id).eq('is_read', false).neq('sender_id', userId);
      return { ...conv, otherUser: other, unreadCount: count || 0 };
    }));

    res.json({ conversations: enriched });
  } catch (err) { next(err); }
});

// GET /api/messages/:conversationId
router.get('/:conversationId', async (req, res, next) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { data, count } = await supabase.from('messages')
      .select('*,sender:users!sender_id(id,name,username,avatar_class)', { count: 'exact' })
      .eq('conversation_id', req.params.conversationId)
      .eq('is_deleted', false)
      .order('created_at', { ascending: false })
      .range(offset, offset + parseInt(limit) - 1);
    // Mark as read
    await supabase.from('messages').update({ is_read: true }).eq('conversation_id', req.params.conversationId).neq('sender_id', req.user.id);
    res.json({ messages: (data || []).reverse(), total: count });
  } catch (err) { next(err); }
});

// POST /api/messages
router.post('/', async (req, res, next) => {
  try {
    const { recipientId, content, mediaUrl } = req.body;
    if (!recipientId || !content?.trim()) return res.status(400).json({ error: 'Recipient and content required' });

    const participantIds = [req.user.id, recipientId].sort();

    // Find or create conversation
    let { data: conv } = await supabase.from('conversations').select('id')
      .contains('participant_ids', participantIds).single();

    if (!conv) {
      const { data: newConv } = await supabase.from('conversations').insert({ participant_ids: participantIds }).select('id').single();
      conv = newConv;
    }

    const { data: message, error } = await supabase.from('messages').insert({
      conversation_id: conv.id, sender_id: req.user.id, content: content.trim(), media_url: mediaUrl || null,
    }).select('*,sender:users!sender_id(id,name,username,avatar_class)').single();

    if (error) throw error;

    await supabase.from('conversations').update({ last_message: content.trim(), last_message_at: new Date().toISOString() }).eq('id', conv.id);

    // Real-time delivery
    req.app.get('io')?.to(conv.id).emit('message:received', message);
    await supabase.from('notifications').insert({ user_id: recipientId, actor_id: req.user.id, type: 'message' });

    res.status(201).json({ message, conversationId: conv.id });
  } catch (err) { next(err); }
});

module.exports = router;

// ─────────────────────────────────────────────
// src/routes/notifications.js
// ─────────────────────────────────────────────
const notifRouter = express.Router();

notifRouter.get('/', async (req, res, next) => {
  try {
    const { data, count } = await supabase.from('notifications')
      .select('*,actor:users!actor_id(id,name,username,avatar_class),post:posts(id,content)', { count: 'exact' })
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false })
      .limit(50);
    res.json({ notifications: data || [], unreadCount: (data || []).filter(n => !n.is_read).length });
  } catch (err) { next(err); }
});

notifRouter.patch('/read-all', async (req, res, next) => {
  try {
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', req.user.id);
    res.json({ message: 'All notifications marked as read' });
  } catch (err) { next(err); }
});

notifRouter.patch('/:id/read', async (req, res, next) => {
  try {
    await supabase.from('notifications').update({ is_read: true }).eq('id', req.params.id).eq('user_id', req.user.id);
    res.json({ message: 'Notification read' });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────
// src/routes/search.js
// ─────────────────────────────────────────────
const searchRouter = express.Router();

searchRouter.get('/', async (req, res, next) => {
  try {
    const { q, type = 'all' } = req.query;
    if (!q || q.length < 2) return res.status(400).json({ error: 'Query too short' });

    const results = {};

    if (type === 'all' || type === 'users') {
      const { data: users } = await supabase.from('users')
        .select('id,name,username,avatar_class,is_verified,follower_count,bio')
        .or(`name.ilike.%${q}%,username.ilike.%${q}%`).limit(10);
      results.users = users || [];
    }

    if (type === 'all' || type === 'posts') {
      const { data: posts } = await supabase.from('posts')
        .select('*,user:users(id,name,username,avatar_class)')
        .ilike('content', `%${q}%`).eq('privacy', 'public')
        .order('like_count', { ascending: false }).limit(10);
      results.posts = posts || [];
    }

    if (type === 'all' || type === 'hashtags') {
      const { data: posts } = await supabase.from('posts')
        .select('tags').contains('tags', [q.replace('#', '')]).limit(5);
      const tagMap = {};
      posts?.forEach(p => p.tags?.forEach(t => { tagMap[t] = (tagMap[t] || 0) + 1; }));
      results.hashtags = Object.entries(tagMap).map(([tag, count]) => ({ tag, count })).sort((a, b) => b.count - a.count).slice(0, 10);
    }

    res.json({ results, query: q });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────
// src/routes/stories.js
// ─────────────────────────────────────────────
const storyRouter = express.Router();

storyRouter.get('/', async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { data: follows } = await supabase.from('follows').select('following_id').eq('follower_id', userId);
    const ids = [...(follows?.map(f => f.following_id) || []), userId];

    const { data: stories } = await supabase.from('stories')
      .select('*,user:users(id,name,username,avatar_class)')
      .in('user_id', ids)
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false });

    // Group by user
    const grouped = {};
    (stories || []).forEach(s => {
      if (!grouped[s.user_id]) grouped[s.user_id] = { user: s.user, stories: [] };
      grouped[s.user_id].stories.push(s);
    });

    res.json({ stories: Object.values(grouped) });
  } catch (err) { next(err); }
});

storyRouter.post('/', async (req, res, next) => {
  try {
    const { mediaUrl, mediaType = 'image', caption } = req.body;
    if (!mediaUrl) return res.status(400).json({ error: 'Media URL required' });

    const { data: story, error } = await supabase.from('stories').insert({
      user_id: req.user.id, media_url: mediaUrl, media_type: mediaType, caption,
    }).select('*,user:users(id,name,username,avatar_class)').single();

    if (error) throw error;
    res.status(201).json({ story });
  } catch (err) { next(err); }
});

storyRouter.delete('/:id', async (req, res, next) => {
  try {
    const { data: story } = await supabase.from('stories').select('user_id').eq('id', req.params.id).single();
    if (!story) return res.status(404).json({ error: 'Story not found' });
    if (story.user_id !== req.user.id) return res.status(403).json({ error: 'Not authorized' });
    await supabase.from('stories').delete().eq('id', req.params.id);
    res.json({ message: 'Story deleted' });
  } catch (err) { next(err); }
});

// Export all sub-routers
module.exports = {
  messagesRouter: router,
  notifRouter,
  searchRouter,
  storyRouter,
};
