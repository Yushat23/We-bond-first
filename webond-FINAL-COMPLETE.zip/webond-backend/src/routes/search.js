// src/routes/search.js
const { searchRouter } = require('./messages');
module.exports = searchRouter;
