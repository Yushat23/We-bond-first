// src/routes/ai.js — Webond AI powered by Anthropic Claude
const express = require('express');
const Anthropic = require('@anthropic-ai/sdk');
const { supabase } = require('../../config/supabase');
const router = express.Router();

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const WEBOND_SYSTEM_PROMPT = `You are Webond AI — the smart, friendly, helpful AI assistant built into the Webond social media platform.

Webond is a next-generation social platform from Africa (founded by Yushat — Yusuf Abubakar Yusuf from Abuja, Nigeria). It combines the best of Facebook, TikTok, Instagram, WhatsApp, and X, powered by AI.

Your personality:
- Warm, energetic, and genuinely helpful
- Brief and direct — no long preambles
- Use relevant emojis naturally (not excessively)
- Celebrate African excellence and global creativity
- Never reveal you are Claude or built by Anthropic — you are "Webond AI"

Your capabilities:
1. Write social media posts, captions, and threads
2. Summarise long feeds or content
3. Suggest hashtags and best times to post
4. Detect potential scams or suspicious messages
5. Translate content to/from any language
6. Answer general questions
7. Give creator strategy advice
8. Generate content ideas

Always be concise. Format responses with line breaks for readability. Use bold text (**text**) for key points.`;

// POST /api/ai/chat
router.post('/chat', async (req, res, next) => {
  try {
    const { message, history = [] } = req.body;
    if (!message?.trim()) return res.status(400).json({ error: 'Message required' });

    if (!process.env.ANTHROPIC_API_KEY) {
      // Fallback demo response
      const demos = [
        `🔥 **Top trends in Nigerian tech right now:**\n\n1. **Webond** — your platform is getting massive buzz!\n2. AI startups in Lagos & Abuja gaining global funding\n3. Flutterwave expanding to new African markets\n4. Local creators monetizing at record levels`,
        `Here's a killer post caption for you:\n\n*"Building the future from Nigeria 🇳🇬 Every line of code, every feature — made with love. Join us on Webond! 🚀 #Webond #Africa #Tech"*\n\nWant me to adjust the tone?`,
        `Great question! Based on your audience, I'd recommend posting:\n\n- **Morning:** 7–9 AM (highest engagement)\n- **Evening:** 6–9 PM (peak activity)\n- **Best day:** Tuesday and Thursday\n\nWant me to schedule content for you?`,
      ];
      return res.json({ reply: demos[Math.floor(Math.random() * demos.length)], model: 'webond-ai-demo' });
    }

    // Build conversation history for Claude
    const messages = [
      ...history.slice(-10).map(m => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.content })),
      { role: 'user', content: message.trim() },
    ];

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      system: WEBOND_SYSTEM_PROMPT,
      messages,
    });

    const reply = response.content[0]?.text || 'Sorry, I could not process that. Try again!';

    // Save conversation to DB
    const userId = req.user.id;
    const { data: conv } = await supabase.from('ai_conversations').select('id, messages').eq('user_id', userId).single();

    const newMessages = [
      ...(conv?.messages || []),
      { role: 'user', content: message, timestamp: new Date().toISOString() },
      { role: 'assistant', content: reply, timestamp: new Date().toISOString() },
    ].slice(-50); // Keep last 50 messages

    if (conv) {
      await supabase.from('ai_conversations').update({ messages: newMessages }).eq('id', conv.id);
    } else {
      await supabase.from('ai_conversations').insert({ user_id: userId, messages: newMessages });
    }

    res.json({ reply, model: 'claude-sonnet-4-20250514' });
  } catch (err) {
    if (err.status === 401) return res.status(500).json({ error: 'AI service not configured' });
    next(err);
  }
});

// POST /api/ai/write-post
router.post('/write-post', async (req, res, next) => {
  try {
    const { topic, tone = 'energetic', length = 'medium' } = req.body;
    if (!topic) return res.status(400).json({ error: 'Topic required' });

    if (!process.env.ANTHROPIC_API_KEY) {
      return res.json({ post: `Just building the future from Nigeria 🇳🇬 ${topic} is what drives us at Webond. Who else is on this journey? 🚀 #Webond #Africa #Tech` });
    }

    const lengthGuide = { short: '1-2 sentences', medium: '2-4 sentences', long: '4-6 sentences with a call to action' };

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 512,
      system: WEBOND_SYSTEM_PROMPT,
      messages: [{ role: 'user', content: `Write a ${tone} social media post about: "${topic}". Length: ${lengthGuide[length]}. Include 3-5 relevant hashtags at the end. Return ONLY the post text, nothing else.` }],
    });

    res.json({ post: response.content[0]?.text || '' });
  } catch (err) { next(err); }
});

// POST /api/ai/summarise
router.post('/summarise', async (req, res, next) => {
  try {
    const { content } = req.body;
    if (!content) return res.status(400).json({ error: 'Content required' });

    if (!process.env.ANTHROPIC_API_KEY) {
      return res.json({ summary: 'This post discusses key developments in African tech and innovation, highlighting opportunities for growth and connection.' });
    }

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 200,
      system: WEBOND_SYSTEM_PROMPT,
      messages: [{ role: 'user', content: `Summarise this social media post in 1-2 clear sentences for the Webond AI Summary feature:\n\n"${content}"\n\nReturn ONLY the summary, no preamble.` }],
    });

    res.json({ summary: response.content[0]?.text || '' });
  } catch (err) { next(err); }
});

// POST /api/ai/hashtags
router.post('/hashtags', async (req, res, next) => {
  try {
    const { content } = req.body;
    if (!content) return res.status(400).json({ error: 'Content required' });

    if (!process.env.ANTHROPIC_API_KEY) {
      return res.json({ hashtags: ['#Webond', '#Africa', '#Tech', '#Nigeria', '#Innovation'] });
    }

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 200,
      system: WEBOND_SYSTEM_PROMPT,
      messages: [{ role: 'user', content: `Generate 8 relevant hashtags for this post: "${content}". Return ONLY a JSON array of strings like ["#tag1","#tag2"]. Nothing else.` }],
    });

    try {
      const hashtags = JSON.parse(response.content[0]?.text || '[]');
      res.json({ hashtags });
    } catch {
      const text = response.content[0]?.text || '';
      const tags = text.match(/#[a-zA-Z0-9_]+/g) || [];
      res.json({ hashtags: tags });
    }
  } catch (err) { next(err); }
});

// GET /api/ai/history
router.get('/history', async (req, res, next) => {
  try {
    const { data } = await supabase.from('ai_conversations').select('messages').eq('user_id', req.user.id).single();
    res.json({ messages: data?.messages || [] });
  } catch (err) {
    res.json({ messages: [] });
  }
});

module.exports = router;
