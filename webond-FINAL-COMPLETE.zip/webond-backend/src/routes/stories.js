// src/routes/stories.js
const { storyRouter } = require('./messages');
module.exports = storyRouter;
