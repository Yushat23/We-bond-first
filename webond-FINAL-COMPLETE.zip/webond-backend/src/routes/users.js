// src/routes/users.js
const express = require('express');
const bcrypt = require('bcryptjs');
const { supabase } = require('../../config/supabase');
const router = express.Router();

// GET /api/users/me
router.get('/me', async (req, res) => {
  const { data: user } = await supabase
    .from('users')
    .select('id,name,username,email,bio,avatar_class,avatar_url,is_verified,is_creator,follower_count,following_count,post_count,created_at')
    .eq('id', req.user.id).single();
  res.json({ user });
});

// PATCH /api/users/me
router.patch('/me', async (req, res, next) => {
  try {
    const { name, bio, avatarClass, username } = req.body;
    const updates = {};
    if (name) updates.name = name.trim();
    if (bio !== undefined) updates.bio = bio;
    if (avatarClass) updates.avatar_class = avatarClass;
    if (username) {
      if (!/^[a-zA-Z0-9_]{3,30}$/.test(username)) return res.status(400).json({ error: 'Invalid username' });
      const { data: ex } = await supabase.from('users').select('id').eq('username', username).neq('id', req.user.id).single();
      if (ex) return res.status(409).json({ error: 'Username taken' });
      updates.username = username.toLowerCase();
    }
    const { data, error } = await supabase.from('users').update(updates).eq('id', req.user.id).select('id,name,username,bio,avatar_class,is_verified').single();
    if (error) throw error;
    res.json({ user: data });
  } catch (err) { next(err); }
});

// GET /api/users/:username
router.get('/:username', async (req, res, next) => {
  try {
    const { data: user, error } = await supabase
      .from('users')
      .select('id,name,username,bio,avatar_class,avatar_url,is_verified,is_creator,follower_count,following_count,post_count,created_at')
      .eq('username', req.params.username.toLowerCase()).single();
    if (error || !user) return res.status(404).json({ error: 'User not found' });

    const { data: isFollowing } = await supabase.from('follows').select('id').eq('follower_id', req.user.id).eq('following_id', user.id).single();
    res.json({ user: { ...user, isFollowing: !!isFollowing } });
  } catch (err) { next(err); }
});

// GET /api/users/:username/posts
router.get('/:username/posts', async (req, res, next) => {
  try {
    const { data: user } = await supabase.from('users').select('id').eq('username', req.params.username).single();
    if (!user) return res.status(404).json({ error: 'User not found' });
    const { page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { data: posts, count } = await supabase.from('posts')
      .select('*,user:users(id,name,username,avatar_class,is_verified)', { count: 'exact' })
      .eq('user_id', user.id).order('created_at', { ascending: false })
      .range(offset, offset + parseInt(limit) - 1);
    res.json({ posts: posts || [], total: count, hasMore: offset + parseInt(limit) < count });
  } catch (err) { next(err); }
});

// POST /api/users/:id/follow
router.post('/:id/follow', async (req, res, next) => {
  try {
    const targetId = req.params.id;
    if (targetId === req.user.id) return res.status(400).json({ error: 'Cannot follow yourself' });
    const { data: ex } = await supabase.from('follows').select('id').eq('follower_id', req.user.id).eq('following_id', targetId).single();
    if (ex) {
      await supabase.from('follows').delete().eq('follower_id', req.user.id).eq('following_id', targetId);
      const { data: t } = await supabase.from('users').select('follower_count').eq('id', targetId).single();
      await supabase.from('users').update({ follower_count: Math.max(0, (t?.follower_count || 1) - 1) }).eq('id', targetId);
      const { data: m } = await supabase.from('users').select('following_count').eq('id', req.user.id).single();
      await supabase.from('users').update({ following_count: Math.max(0, (m?.following_count || 1) - 1) }).eq('id', req.user.id);
      return res.json({ following: false });
    } else {
      await supabase.from('follows').insert({ follower_id: req.user.id, following_id: targetId });
      const { data: t } = await supabase.from('users').select('follower_count').eq('id', targetId).single();
      await supabase.from('users').update({ follower_count: (t?.follower_count || 0) + 1 }).eq('id', targetId);
      const { data: m } = await supabase.from('users').select('following_count').eq('id', req.user.id).single();
      await supabase.from('users').update({ following_count: (m?.following_count || 0) + 1 }).eq('id', req.user.id);
      await supabase.from('notifications').insert({ user_id: targetId, actor_id: req.user.id, type: 'follow' });
      return res.json({ following: true });
    }
  } catch (err) { next(err); }
});

// GET /api/users/:id/followers
router.get('/:id/followers', async (req, res, next) => {
  try {
    const { data } = await supabase.from('follows')
      .select('follower:users!follower_id(id,name,username,avatar_class,is_verified)')
      .eq('following_id', req.params.id);
    res.json({ followers: data?.map(d => d.follower) || [] });
  } catch (err) { next(err); }
});

// GET /api/users/:id/following
router.get('/:id/following', async (req, res, next) => {
  try {
    const { data } = await supabase.from('follows')
      .select('following:users!following_id(id,name,username,avatar_class,is_verified)')
      .eq('follower_id', req.params.id);
    res.json({ following: data?.map(d => d.following) || [] });
  } catch (err) { next(err); }
});

module.exports = router;
