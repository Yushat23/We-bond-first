// src/routes/notifications.js
const { notifRouter } = require('./messages');
module.exports = notifRouter;
