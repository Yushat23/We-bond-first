# Webond — Installation & Hosting Guide
## By Yusuf Abubakar Yusuf (Yushat) | Built with React

---

## 📦 PROJECT STRUCTURE

```
webond-react/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── auth/index.jsx        ← Splash, Welcome, Login, Signup (3 steps), OTP, Setup, Interests
│   │   ├── feed/index.jsx        ← Home feed, Posts, Stories, Create Post
│   │   ├── profile/index.jsx     ← Full profile, stats, media grid
│   │   ├── video/index.jsx       ← Short video feed + fullscreen reel
│   │   ├── messages/index.jsx    ← Messages list, online users
│   │   ├── chat/index.jsx        ← Webond AI chat with smart replies
│   │   ├── settings/index.jsx    ← Full settings with toggles
│   │   └── shared/index.jsx      ← Reusable UI components
│   ├── store/
│   │   └── useStore.js           ← Zustand state management
│   ├── styles/
│   │   └── globals.css           ← Global styles, variables, animations
│   ├── App.jsx                   ← Main app with routing & transitions
│   └── index.jsx                 ← React entry point
├── package.json
└── README.md
```

---

## 🚀 QUICK START — Run Locally

### Step 1: Prerequisites
- Install **Node.js** (v18+): https://nodejs.org
- Install **npm** or **yarn**: included with Node.js

### Step 2: Install dependencies
```bash
cd webond-react
npm install
```

### Step 3: Start development server
```bash
npm start
```
Open: **http://localhost:3000**

### Step 4: Build for production
```bash
npm run build
```
This creates a `/build` folder — upload this to host.

---

## 🌍 HOSTING OPTIONS (Ranked Best to Good)

---

### ✅ OPTION 1: Vercel (RECOMMENDED — FREE, Fastest)
**Best for:** Maximum speed, free SSL, global CDN, auto-deploy from GitHub

**Step 1:** Push code to GitHub
```bash
git init
git add .
git commit -m "Initial Webond commit"
git remote add origin https://github.com/YOURUSERNAME/webond.git
git push -u origin main
```

**Step 2:** Go to https://vercel.com → Sign up with GitHub

**Step 3:** Click "New Project" → Import your GitHub repo

**Step 4:** Vercel auto-detects React → Click "Deploy"

**Step 5:** Your app is live at:
`https://webond.vercel.app` (or custom domain!)

**Custom domain:** Settings → Domains → Add `webond.com`

✅ Free SSL, auto HTTPS, 100GB bandwidth free/month, deploys in 30 seconds.

---

### ✅ OPTION 2: Netlify (FREE, Easy)
**Best for:** Simple drag-and-drop hosting

**Step 1:** Build the app
```bash
npm run build
```

**Step 2:** Go to https://netlify.com → Drag the `/build` folder onto the dashboard

**Done!** Live in 60 seconds at `https://webond.netlify.app`

OR connect to GitHub for auto-deploy on every git push.

---

### ✅ OPTION 3: GitHub Pages (FREE)
```bash
npm install --save-dev gh-pages
```

Add to `package.json`:
```json
"homepage": "https://YOURUSERNAME.github.io/webond",
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d build"
}
```

Then deploy:
```bash
npm run deploy
```
Live at: `https://YOURUSERNAME.github.io/webond`

---

### ✅ OPTION 4: AWS Amplify (Scalable, for growth)
**Best for:** When Webond gets millions of users

```bash
npm install -g @aws-amplify/cli
amplify configure
amplify init
amplify add hosting
amplify publish
```

OR: AWS Console → Amplify → Connect GitHub repo → Deploy

**Cost:** ~$0.01/GB transfer. Scales infinitely.

---

### ✅ OPTION 5: Firebase Hosting (Google, Fast)
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# Choose: build as public directory
# Single-page app: Yes
npm run build
firebase deploy
```
Live at: `https://webond.web.app`

---

## 📱 MOBILE APP (iOS + Android)

To convert to a real mobile app:

### Option A: Expo (Easiest — React Native)
```bash
npm install -g expo-cli
npx create-expo-app webond-mobile
# Copy components, adapt styles
npx expo start
```
Then publish to App Store & Google Play via Expo EAS.

### Option B: Progressive Web App (PWA)
Add to `public/manifest.json`:
```json
{
  "name": "Webond",
  "short_name": "Webond",
  "start_url": "/",
  "display": "standalone",
  "theme_color": "#00C2A8",
  "background_color": "#1a1a2e",
  "icons": [{ "src": "icon.png", "sizes": "512x512", "type": "image/png" }]
}
```
Users can then "Add to Home Screen" on both iOS and Android.

---

## 🔧 ADDING A REAL BACKEND

For the full production Webond with real users, connect:

### Database: Supabase (Free PostgreSQL)
```bash
npm install @supabase/supabase-js
```
```js
import { createClient } from '@supabase/supabase-js'
const supabase = createClient('YOUR_URL', 'YOUR_ANON_KEY')

// Real-time posts
const { data } = await supabase.from('posts').select('*')
supabase.channel('posts').on('INSERT', handleNewPost).subscribe()
```

### Auth: Firebase Auth (Google/Apple/Email)
```bash
npm install firebase
```
```js
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth'
// Replaces the demo social auth with real OAuth
```

### AI: Anthropic Claude API
```js
const response = await fetch('/api/ai', {
  method: 'POST',
  body: JSON.stringify({ message: userInput })
})
// Powered by Claude Sonnet — the same AI as this chat!
```

### Real-time: Socket.io
```bash
npm install socket.io-client
```
For live notifications, real-time likes, and live chat.

---

## 💰 ESTIMATED MONTHLY COSTS (Production)

| Service            | Free Tier            | Paid (10k users)  |
|--------------------|----------------------|-------------------|
| Vercel hosting     | 100GB/month FREE     | $20/month         |
| Supabase DB        | 500MB FREE           | $25/month         |
| Firebase Auth      | 10k users FREE       | $0.0055/user      |
| Cloudflare CDN     | Unlimited FREE       | FREE              |
| Claude AI API      | Pay per use          | ~$50/month        |
| **Total**          | **$0/month**         | **~$100/month**   |

---

## 🔐 ENVIRONMENT VARIABLES

Create `.env` in project root:
```env
REACT_APP_SUPABASE_URL=your_supabase_url
REACT_APP_SUPABASE_ANON_KEY=your_anon_key
REACT_APP_FIREBASE_API_KEY=your_firebase_key
REACT_APP_ANTHROPIC_API_KEY=your_claude_key
```

---

## 📋 FEATURES INCLUDED IN THIS SOURCE CODE

✅ Complete auth flow (Splash → Welcome → Signup 3-step → OTP → Profile Setup → Interests)
✅ Social sign-in (Google, Apple, Meta, X) with confirmation sheets
✅ Login with email/password validation
✅ Forgot password flow
✅ localStorage session persistence (stay logged in on reload)
✅ Home feed with posts, likes, bookmarks, share
✅ Stories bar with add story
✅ AI Brief bar (links to Webond AI chat)
✅ Create post modal with AI Write feature
✅ Short video feed with play cards
✅ Fullscreen reel player with all actions
✅ Messages screen with online indicators
✅ Webond AI chat with smart replies & quick prompts
✅ Profile screen with stats, media grid, tab pills
✅ Settings with toggles (notifications, dark mode, AI)
✅ Animated screen transitions (Framer Motion)
✅ Toast notifications (react-hot-toast)
✅ Zustand global state management
✅ Fully responsive (mobile-first, works on desktop too)

---

## 🆘 SUPPORT

Built by Yushat — Webond Founder
For questions: Open an issue on GitHub
Webond © 2025 — Connect Beyond 🌍
