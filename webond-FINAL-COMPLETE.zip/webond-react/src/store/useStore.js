import { create } from 'zustand';

const DEMO_POSTS = [
  { id: '1', userId: 'user1', username: 'Yushat', handle: '@yushat', avatarClass: 'av-g', content: 'Just launched Webond — the social platform that connects beyond all limits! 🚀 Join us and be part of something historic. #Webond #Tech #Africa', images: ['🌍', '🚀', '💡'], likes: 2500, comments: 418, isLiked: true, createdAt: new Date(), privacy: 'Everyone', aiSummary: null },
  { id: '2', userId: 'user2', username: 'Amira Hassan', handle: '@amira_h', avatarColor: 'linear-gradient(135deg,#B3EFE9,#06b6d4)', content: 'Abuja sunsets are something else 🌅 Who\'s watching from their balcony right now? Drop your city below! 👇', images: ['🌅'], likes: 891, comments: 132, isLiked: false, createdAt: new Date(Date.now() - 840000), privacy: 'Public', aiSummary: null },
  { id: '3', userId: 'user3', username: 'Tech_Chidi', handle: '@tech_chidi', avatarColor: 'linear-gradient(135deg,#fde68a,#fb923c)', content: 'Nigeria\'s tech ecosystem is growing faster than anyone predicted. We\'re building world-class solutions from Lagos to Abuja 🌍🚀 The future is African. #NaijaTech', images: [], likes: 3100, comments: 504, isLiked: false, createdAt: new Date(Date.now() - 3600000), privacy: 'Public', verified: true, aiSummary: 'Tech_Chidi discusses Nigeria\'s growing tech scene and African innovation. Mentions Webond as an example of pan-African platforms.' },
];

const DEMO_MESSAGES = [
  { id: 'm1', name: 'Webond AI', handle: '@webond_ai', avatar: '🤖', avatarBg: 'linear-gradient(135deg,#00C2A8,#00a892)', lastMessage: 'Ask me anything — always online!', time: 'Now', unread: 0, isAI: true, online: true },
  { id: 'm2', name: 'Amira Hassan', handle: '@amira_h', avatarColor: 'linear-gradient(135deg,#B3EFE9,#06b6d4)', lastMessage: 'Can\'t wait for the Webond launch! 🚀', time: 'Just now', unread: 2, online: true },
  { id: 'm3', name: 'Tech_Chidi', handle: '@tech_chidi', avatarColor: 'linear-gradient(135deg,#fde68a,#fb923c)', lastMessage: 'Bro send me the invite link!', time: '2m', unread: 3, online: true },
  { id: 'm4', name: 'Fatima Umar', handle: '@fatima_u', avatarColor: 'linear-gradient(135deg,#c4b5fd,#f9a8d4)', lastMessage: 'Sent you a photo 📸', time: '15m', unread: 1, online: false },
  { id: 'm5', name: 'Ngozi Creates', handle: '@ngozi_c', avatarColor: 'linear-gradient(135deg,#86efac,#67e8f9)', lastMessage: '🎵 Sent an audio clip', time: '3h', unread: 0, online: true },
];

const AI_REPLIES = [
  'Great question! Here\'s what I found: 🔍 Based on current trends in African tech, this topic is gaining significant momentum.',
  '🔥 I\'ve analysed your network. Here are the top 3 insights relevant to you right now.',
  'Smart choice! Here\'s my recommendation based on your interests and activity on Webond 💡',
  '✅ Done! I\'ve also generated 3 caption ideas you can use for your next post.',
  'I found some great insights on that! Want me to create a full report or turn this into a post? 🚀',
  '🤖 Processing your request... Based on what\'s trending in Nigeria and across Africa, here\'s what matters most.',
];

const useStore = create((set, get) => ({
  // Auth state
  user: null,
  isAuthenticated: false,
  avClass: 'av-g',
  tmpSignup: {},

  // App state
  currentScreen: 'splash',
  previousScreen: null,
  currentTab: 'profile',

  // Feed state
  posts: DEMO_POSTS,
  stories: ['Amira','Chidi','Fatima','Emeka','Ngozi','Tolu'],

  // Messages state
  conversations: DEMO_MESSAGES,
  chatMessages: [
    { id: 'c1', role: 'ai', content: 'Hi Yushat! I\'m your Webond AI. I can write posts, answer questions, summarise your feed, detect scams, translate content, and much more. What can I do? ✨', time: '9:38 AM' },
    { id: 'c2', role: 'user', content: 'What\'s trending in Nigerian tech right now?', time: '9:38 AM' },
    { id: 'c3', role: 'ai', content: '🔥 Top trending in Nigerian tech:\n\n1. Webond — your platform is getting massive buzz! 🚀\n2. AI startups in Lagos & Abuja gaining global funding\n3. Flutterwave expanding to new African markets\n4. Local creators monetizing at record levels\n5. Nigeria ranked #1 for crypto adoption in Africa', time: '9:39 AM' },
    { id: 'c4', role: 'user', content: 'Help me write a launch post for Webond', time: '9:40 AM' },
    { id: 'c5', role: 'ai', content: 'Here\'s a killer launch post: 🎉\n\n"Excited to announce Webond is LIVE! 🚀 The social platform built for Africa and the world. Connect, share, and grow beyond borders. Join us today! #Webond #Africa #Tech"\n\nWant me to make it shorter, longer, or add more hashtags?', time: '9:41 AM' },
  ],

  // Settings state
  notifications: true,
  darkMode: false,
  aiEnabled: true,

  // Actions
  setUser: (user) => set({ user, isAuthenticated: true }),
  setAvClass: (cls) => set({ avClass: cls }),
  setTmpSignup: (data) => set((state) => ({ tmpSignup: { ...state.tmpSignup, ...data } })),

  goTo: (screen) => set((state) => ({ previousScreen: state.currentScreen, currentScreen: screen })),

  navTo: (tab) => set({ currentTab: tab, currentScreen: tab, previousScreen: null }),

  logout: () => {
    try { localStorage.removeItem('wb_user'); } catch(e) {}
    set({ user: null, isAuthenticated: false, currentScreen: 'welcome', currentTab: 'profile' });
  },

  saveUser: (user) => {
    try { localStorage.setItem('wb_user', JSON.stringify(user)); } catch(e) {}
    set({ user, isAuthenticated: true });
  },

  loadSavedUser: () => {
    try {
      const s = localStorage.getItem('wb_user');
      if (s) {
        const user = JSON.parse(s);
        set({ user, isAuthenticated: true, currentScreen: 'profile', currentTab: 'profile' });
        return true;
      }
    } catch(e) {}
    return false;
  },

  likePost: (postId) => set((state) => ({
    posts: state.posts.map(p =>
      p.id === postId
        ? { ...p, isLiked: !p.isLiked, likes: p.isLiked ? p.likes - 1 : p.likes + 1 }
        : p
    )
  })),

  addPost: (content) => set((state) => ({
    posts: [{
      id: Date.now().toString(),
      userId: state.user?.id || 'user1',
      username: state.user?.name || 'Yushat',
      handle: '@' + (state.user?.username || 'yushat'),
      avatarClass: state.avClass,
      content,
      images: [],
      likes: 0,
      comments: 0,
      isLiked: false,
      createdAt: new Date(),
      privacy: 'Everyone',
    }, ...state.posts]
  })),

  sendChatMessage: (text) => {
    const now = new Date();
    const timeStr = now.getHours() % 12 || 12 + ':' + (now.getMinutes() < 10 ? '0' : '') + now.getMinutes() + (now.getHours() < 12 ? ' AM' : ' PM');
    const userMsg = { id: Date.now().toString(), role: 'user', content: text, time: timeStr };
    set((state) => ({ chatMessages: [...state.chatMessages, userMsg] }));
    setTimeout(() => {
      const aiReply = AI_REPLIES[Math.floor(Math.random() * AI_REPLIES.length)];
      const aiMsg = { id: (Date.now() + 1).toString(), role: 'ai', content: aiReply, time: timeStr };
      set((state) => ({ chatMessages: [...state.chatMessages, aiMsg] }));
    }, 1400);
  },

  toggleSetting: (key) => set((state) => ({ [key]: !state[key] })),
}));

export default useStore;
