// src/utils/api.js — Webond API Client

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Token management
export const getToken = () => localStorage.getItem('wb_token');
export const setToken = (t) => localStorage.setItem('wb_token', t);
export const setRefresh = (t) => localStorage.setItem('wb_refresh', t);
export const getRefresh = () => localStorage.getItem('wb_refresh');
export const clearTokens = () => { localStorage.removeItem('wb_token'); localStorage.removeItem('wb_refresh'); };

// Base fetch with auto auth + refresh
const apiFetch = async (path, opts = {}) => {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json', ...(token && { Authorization: `Bearer ${token}` }), ...opts.headers };
  const res = await fetch(`${BASE_URL}${path}`, { ...opts, headers });

  // Auto-refresh on 401
  if (res.status === 401) {
    const err = await res.json();
    if (err.code === 'TOKEN_EXPIRED') {
      const refresh = getRefresh();
      if (refresh) {
        const rRes = await fetch(`${BASE_URL}/auth/refresh`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken: refresh }) });
        if (rRes.ok) {
          const { accessToken, refreshToken } = await rRes.json();
          setToken(accessToken); setRefresh(refreshToken);
          // Retry original
          const retryHeaders = { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}`, ...opts.headers };
          return fetch(`${BASE_URL}${path}`, { ...opts, headers: retryHeaders });
        }
      }
      clearTokens();
      window.location.reload();
    }
  }
  return res;
};

const handleRes = async (res) => {
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
};

// ─────────────────────────────
// AUTH
// ─────────────────────────────
export const api = {
  auth: {
    register: (body) => apiFetch('/auth/register', { method: 'POST', body: JSON.stringify(body) }).then(handleRes),
    verifyOtp: (body) => apiFetch('/auth/verify-otp', { method: 'POST', body: JSON.stringify(body) }).then(handleRes),
    login: (body) => apiFetch('/auth/login', { method: 'POST', body: JSON.stringify(body) }).then(handleRes),
    social: (body) => apiFetch('/auth/social', { method: 'POST', body: JSON.stringify(body) }).then(handleRes),
    forgot: (email) => apiFetch('/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) }).then(handleRes),
    reset: (body) => apiFetch('/auth/reset-password', { method: 'POST', body: JSON.stringify(body) }).then(handleRes),
    logout: () => { const r = getRefresh(); clearTokens(); return apiFetch('/auth/logout', { method: 'POST', body: JSON.stringify({ refreshToken: r }) }).then(handleRes).catch(() => {}); },
    checkUsername: (u) => apiFetch(`/auth/check-username/${u}`).then(handleRes),
  },

  users: {
    me: () => apiFetch('/users/me').then(handleRes),
    update: (body) => apiFetch('/users/me', { method: 'PATCH', body: JSON.stringify(body) }).then(handleRes),
    get: (username) => apiFetch(`/users/${username}`).then(handleRes),
    posts: (username, page = 1) => apiFetch(`/users/${username}/posts?page=${page}`).then(handleRes),
    follow: (id) => apiFetch(`/users/${id}/follow`, { method: 'POST' }).then(handleRes),
    followers: (id) => apiFetch(`/users/${id}/followers`).then(handleRes),
    following: (id) => apiFetch(`/users/${id}/following`).then(handleRes),
  },

  posts: {
    feed: (page = 1) => apiFetch(`/posts/feed?page=${page}`).then(handleRes),
    create: (body) => apiFetch('/posts', { method: 'POST', body: JSON.stringify(body) }).then(handleRes),
    like: (id) => apiFetch(`/posts/${id}/like`, { method: 'POST' }).then(handleRes),
    bookmark: (id) => apiFetch(`/posts/${id}/bookmark`, { method: 'POST' }).then(handleRes),
    comments: (id, page = 1) => apiFetch(`/posts/${id}/comments?page=${page}`).then(handleRes),
    addComment: (id, content) => apiFetch(`/posts/${id}/comments`, { method: 'POST', body: JSON.stringify({ content }) }).then(handleRes),
    delete: (id) => apiFetch(`/posts/${id}`, { method: 'DELETE' }).then(handleRes),
  },

  messages: {
    conversations: () => apiFetch('/messages/conversations').then(handleRes),
    get: (convId, page = 1) => apiFetch(`/messages/${convId}?page=${page}`).then(handleRes),
    send: (body) => apiFetch('/messages', { method: 'POST', body: JSON.stringify(body) }).then(handleRes),
  },

  notifications: {
    get: () => apiFetch('/notifications').then(handleRes),
    readAll: () => apiFetch('/notifications/read-all', { method: 'PATCH' }).then(handleRes),
    read: (id) => apiFetch(`/notifications/${id}/read`, { method: 'PATCH' }).then(handleRes),
  },

  ai: {
    chat: (message, history) => apiFetch('/ai/chat', { method: 'POST', body: JSON.stringify({ message, history }) }).then(handleRes),
    writePost: (topic, tone, length) => apiFetch('/ai/write-post', { method: 'POST', body: JSON.stringify({ topic, tone, length }) }).then(handleRes),
    summarise: (content) => apiFetch('/ai/summarise', { method: 'POST', body: JSON.stringify({ content }) }).then(handleRes),
    hashtags: (content) => apiFetch('/ai/hashtags', { method: 'POST', body: JSON.stringify({ content }) }).then(handleRes),
    history: () => apiFetch('/ai/history').then(handleRes),
  },

  search: {
    query: (q, type = 'all') => apiFetch(`/search?q=${encodeURIComponent(q)}&type=${type}`).then(handleRes),
  },

  stories: {
    get: () => apiFetch('/stories').then(handleRes),
    create: (body) => apiFetch('/stories', { method: 'POST', body: JSON.stringify(body) }).then(handleRes),
    delete: (id) => apiFetch(`/stories/${id}`, { method: 'DELETE' }).then(handleRes),
  },
};

export default api;
