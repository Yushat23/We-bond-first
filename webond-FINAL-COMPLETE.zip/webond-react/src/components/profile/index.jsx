// src/components/profile/index.jsx
import React, { useState } from 'react';
import useStore from '../../store/useStore';
import { IconBtn } from '../shared';
import toast from 'react-hot-toast';

const TABS = ['All', 'Posts', 'Media', 'Videos', 'Reels'];
const GRID_ITEMS = [
  { emoji: '🌅', bg: 'linear-gradient(135deg,#E6FAF8,#B3EFE9)' },
  { emoji: '🚀', bg: 'linear-gradient(135deg,#FFF8E7,#FFE5A0)' },
  { emoji: '💻', bg: 'linear-gradient(135deg,#EDE9FE,#DDD6FE)' },
  { emoji: '🎵', bg: 'linear-gradient(135deg,#FFF0F0,#FFD6D6)', video: true },
  { emoji: '🌍', bg: 'linear-gradient(135deg,#EFF6FF,#BFDBFE)' },
  { emoji: '🏙️', bg: 'linear-gradient(135deg,#F0FDF4,#BBF7D0)' },
];

export const Profile = () => {
  const { user, avClass, navTo } = useStore();
  const [activeTab, setActiveTab] = useState('All');
  const initial = (user?.name || 'Y')[0].toUpperCase();

  return (
    <div>
      {/* Header */}
      <div style={{ background: '#fff', padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5, borderBottom: '1px solid var(--bd)' }}>
        <span style={{ fontSize: 18, fontWeight: 700, color: 'var(--t1)' }}>Profile</span>
        <div style={{ display: 'flex', gap: 8 }}>
          <IconBtn><svg viewBox="0 0 24 24" fill="none" stroke="var(--t2)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></IconBtn>
          <IconBtn onClick={() => navTo('settings')}><svg viewBox="0 0 24 24" fill="none" stroke="var(--t2)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" fill="none"/></svg></IconBtn>
        </div>
      </div>

      {/* Avatar + Info */}
      <div style={{ background: '#fff', padding: 18, display: 'flex', gap: 14, alignItems: 'flex-start', borderBottom: '1px solid var(--bd)' }}>
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <div className={avClass} style={{ width: 72, height: 72, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontWeight: 800, color: '#fff', border: '3px solid #fff', boxShadow: '0 2px 12px rgba(0,194,168,.3)' }}>{initial}</div>
          <div onClick={() => toast.success('📷 Change photo — full version!')} style={{ position: 'absolute', bottom: 0, right: 0, width: 22, height: 22, background: 'var(--teal)', borderRadius: '50%', border: '2px solid #fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <svg viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </div>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--t1)', marginBottom: 2 }}>{user?.name || 'Yushat'}</div>
          <div style={{ fontSize: 12, color: 'var(--teal)', fontWeight: 500, marginBottom: 8 }}>@{user?.username || 'yushat'} · Webond Founder</div>
          <div style={{ fontSize: 13, color: 'var(--t2)', lineHeight: 1.55 }}>{user?.bio || 'Building the future of social media from Abuja, Nigeria 🇳🇬 | Tech founder | AI enthusiast | Connecting the world 🌍'}</div>
        </div>
      </div>

      {/* Stats */}
      <div style={{ background: '#fff', padding: '14px 18px', display: 'flex', alignItems: 'center', borderBottom: '1px solid var(--bd)' }}>
        {[['126', 'Following', 'var(--teal)'], [null, null, null], ['30', 'Stars', null], [null, null, null], ['48.9k', 'Followers', 'var(--teal)']].map((s, i) => {
          if (!s[0]) return <div key={i} style={{ width: 1, height: 30, background: 'var(--bd)', margin: '0 10px' }} />;
          return (
            <div key={i} style={{ flex: 1, textAlign: 'center' }}>
              <div style={{ fontSize: 17, fontWeight: 800, color: s[2] || 'var(--t1)' }}>{s[0]}</div>
              <div style={{ fontSize: 11, color: 'var(--t3)', fontWeight: 500, marginTop: 1 }}>{s[1]}</div>
            </div>
          );
        })}
      </div>

      {/* Action buttons */}
      <div style={{ background: '#fff', padding: '12px 18px', display: 'flex', alignItems: 'center', gap: 20, borderBottom: '1px solid var(--bd)' }}>
        {[
          { icon: <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>, label: 'Like', action: () => toast.success('❤️ Liked!') },
          { icon: <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>, label: 'Message', action: () => navTo('chat') },
          { icon: <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>, label: 'Stars', action: () => toast.success('⭐ Added to Stars!') },
        ].map(({ icon, label, action }) => (
          <div key={label} onClick={action} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, cursor: 'pointer', padding: '8px 4px', borderRadius: 12, transition: '.18s' }}>
            <div style={{ width: 40, height: 40, borderRadius: 13, background: 'var(--teal3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</div>
            <span style={{ fontSize: 11, color: 'var(--t2)', fontWeight: 600 }}>{label}</span>
          </div>
        ))}
      </div>

      {/* Home Feed button */}
      <div onClick={() => navTo('feed')} style={{ margin: '14px 18px 0', background: 'var(--teal)', borderRadius: 14, padding: 13, textAlign: 'center', fontSize: 14, fontWeight: 700, color: '#fff', cursor: 'pointer', boxShadow: '0 4px 16px rgba(0,194,168,.35)' }}>🏠 Home feed</div>
      <div onClick={() => toast.success('🔗 Link copied!')} style={{ margin: '10px 18px', fontSize: 12, color: 'var(--teal)', fontWeight: 500, textAlign: 'center', cursor: 'pointer' }}>🔗 Share profile to Instagram &amp; other platforms</div>

      {/* Tab pills */}
      <div style={{ display: 'flex', margin: '0 18px', gap: 10, overflowX: 'auto', scrollbarWidth: 'none', paddingBottom: 2 }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setActiveTab(t)} style={{ padding: '7px 16px', borderRadius: 22, fontSize: 12, fontWeight: 600, cursor: 'pointer', transition: '.18s', whiteSpace: 'nowrap', border: 'none', fontFamily: 'var(--ff)', background: activeTab === t ? 'var(--teal)' : '#fff', color: activeTab === t ? '#fff' : 'var(--t2)', boxShadow: activeTab === t ? '0 3px 10px rgba(0,194,168,.3)' : 'none', borderWidth: activeTab === t ? 0 : 1, borderStyle: activeTab === t ? 'none' : 'solid', borderColor: 'var(--bd)' }}>
            {t}
          </button>
        ))}
      </div>

      {/* Post card */}
      <div style={{ margin: '12px 0 0', background: '#fff', borderTop: '1px solid var(--bd)', borderBottom: '1px solid var(--bd)', padding: '13px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 9 }}>
          <div className={avClass} style={{ width: 36, height: 36, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: '#fff' }}>{initial}</div>
          <div><div style={{ fontSize: 13, fontWeight: 600, color: 'var(--t1)' }}>{user?.name || 'Yushat'}</div><div style={{ fontSize: 11, color: 'var(--t3)' }}>Just now</div></div>
        </div>
        <div style={{ fontSize: 13, color: 'var(--t2)', lineHeight: 1.55, marginBottom: 10 }}>Building the next big thing from Nigeria 🇳🇬 Webond is live! Check it out and join the waitlist 🚀 #Webond #Tech</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 3, marginBottom: 10 }}>
          <div style={{ aspectRatio: '1', background: 'linear-gradient(135deg,#E6FAF8,#B3EFE9)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36, borderRadius: '10px 0 0 10px' }}>🏙️</div>
          <div style={{ aspectRatio: '1', background: 'linear-gradient(135deg,#EDE9FE,#DDD6FE)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36, borderRadius: '0 10px 10px 0' }}>💻</div>
        </div>
        <div style={{ display: 'flex', gap: 14 }}>
          {[['❤️', '1.2k'], ['💬', '243'], ['🔗', 'Share']].map(([ic, v]) => (
            <div key={v} onClick={() => toast.success('👍')} style={{ display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer', fontSize: 12, fontWeight: 600, color: 'var(--t3)' }}>{ic} {v}</div>
          ))}
        </div>
      </div>

      {/* Media grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 2, marginTop: 2 }}>
        {GRID_ITEMS.map((item, i) => (
          <div key={i} onClick={() => toast.success('🖼️ Opening media...')} style={{ aspectRatio: '1', background: item.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30, cursor: 'pointer', position: 'relative' }}>
            {item.emoji}
            {item.video && <div style={{ position: 'absolute', bottom: 7, right: 7, background: 'rgba(0,0,0,.45)', borderRadius: '50%', width: 21, height: 21, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><svg viewBox="0 0 24 24" width="10" height="10" fill="#fff"><polygon points="5 3 19 12 5 21 5 3"/></svg></div>}
          </div>
        ))}
      </div>
      <div style={{ height: 20 }} />
    </div>
  );
};
