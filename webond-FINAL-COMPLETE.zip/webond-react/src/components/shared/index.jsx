// src/components/shared/index.jsx
import React from 'react';

export const Avatar = ({ user, size = 40, className = '' }) => {
  const initial = (user?.name || user?.username || 'Y')[0].toUpperCase();
  const avClass = user?.avClass || 'av-g';
  return (
    <div
      className={`${avClass} ${className}`}
      style={{
        width: size, height: size, borderRadius: '50%',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: size * 0.38, fontWeight: 800, color: '#fff',
        flexShrink: 0,
      }}
    >
      {initial}
    </div>
  );
};

export const IconBtn = ({ children, onClick, className = '', badge = false, style = {} }) => (
  <button className={`icon-btn ${className}`} onClick={onClick} style={style}>
    {children}
    {badge && <div className="notif-dot" />}
  </button>
);

export const Toggle = ({ on, onToggle }) => (
  <button className={`toggle ${on ? 'on' : ''}`} onClick={onToggle} />
);

export const Pill = ({ children, color = 'teal' }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 4,
    padding: '4px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600,
    background: color === 'teal' ? 'var(--teal3)' : color === 'coral' ? 'var(--coral2)' : 'var(--purple2)',
    color: color === 'teal' ? 'var(--teal2)' : color === 'coral' ? 'var(--coral)' : 'var(--purple)',
  }}>{children}</span>
);

export const TopBar = ({ title, left, right }) => (
  <div className="top-bar">
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      {left}
      {title && <span className="top-bar-title">{title}</span>}
    </div>
    <div style={{ display: 'flex', gap: 8 }}>{right}</div>
  </div>
);

export const BackBtn = ({ onClick }) => (
  <button className="icon-btn" onClick={onClick} style={{ background: 'var(--bg)' }}>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  </button>
);

export const Divider = ({ label = 'or' }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '6px 0 16px' }}>
    <div style={{ flex: 1, height: 1, background: 'var(--bd)' }} />
    <span style={{ fontSize: 12, color: 'var(--t3)', fontWeight: 500 }}>{label}</span>
    <div style={{ flex: 1, height: 1, background: 'var(--bd)' }} />
  </div>
);

export const Field = ({ label, children, error, hint }) => (
  <div style={{ marginBottom: 15 }}>
    {label && <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: 'var(--t2)', marginBottom: 7, textTransform: 'uppercase', letterSpacing: '.6px' }}>{label}</label>}
    {children}
    {error && <div style={{ fontSize: 12, color: 'var(--coral)', marginTop: 4 }}>{error}</div>}
    {hint && !error && <div style={{ fontSize: 12, color: 'var(--t3)', marginTop: 4 }}>{hint}</div>}
  </div>
);

export const Input = ({ style = {}, ...props }) => (
  <input
    style={{
      width: '100%', padding: '13px 15px',
      border: '1.5px solid var(--bd)', borderRadius: 12,
      fontSize: 14, fontFamily: 'var(--ff)', color: 'var(--t1)',
      outline: 'none', background: 'var(--bg)', transition: '.2s', ...style
    }}
    onFocus={e => { e.target.style.borderColor = 'var(--teal)'; e.target.style.boxShadow = '0 0 0 3px rgba(0,194,168,.12)'; e.target.style.background = '#fff'; }}
    onBlur={e => { e.target.style.borderColor = 'var(--bd)'; e.target.style.boxShadow = 'none'; e.target.style.background = 'var(--bg)'; }}
    {...props}
  />
);

export const BtnFull = ({ children, variant = 'teal', onClick, disabled = false, loading = false, style = {} }) => {
  const bg = variant === 'teal' ? 'var(--teal)' : 'none';
  const color = variant === 'teal' ? '#fff' : 'var(--t1)';
  const border = variant === 'ghost' ? '1.5px solid var(--bd)' : 'none';
  const boxShadow = variant === 'teal' ? '0 6px 20px rgba(0,194,168,.4)' : 'none';
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      style={{
        width: '100%', padding: 15, borderRadius: 14, border, background: bg, color,
        fontSize: 15, fontWeight: 700, fontFamily: 'var(--ff)', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9,
        boxShadow, transition: '.15s', opacity: disabled ? .7 : 1, ...style
      }}
    >
      {loading && <div className="spinner active" />}
      {children}
    </button>
  );
};

export const SocialBtn = ({ icon, children, onClick }) => (
  <button
    onClick={onClick}
    style={{
      width: '100%', padding: '13px 16px', borderRadius: 13,
      border: '1.5px solid var(--bd)', background: 'var(--white)',
      fontSize: 14, fontWeight: 600, color: 'var(--t1)',
      fontFamily: 'var(--ff)', cursor: 'pointer',
      display: 'flex', alignItems: 'center', gap: 12,
      marginBottom: 10, transition: '.18s', textAlign: 'left',
    }}
    onMouseDown={e => e.currentTarget.style.background = 'var(--bg)'}
    onMouseUp={e => e.currentTarget.style.background = 'var(--white)'}
  >
    {icon}
    <span>{children}</span>
  </button>
);

export const PasswordInput = ({ id, placeholder, value, onChange }) => {
  const [show, setShow] = React.useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <Input
        id={id}
        type={show ? 'text' : 'password'}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        style={{ paddingRight: 44 }}
      />
      <button
        type="button"
        onClick={() => setShow(!show)}
        style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', cursor: 'pointer', padding: 4, border: 'none', background: 'none' }}
      >
        <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="var(--t3)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          {show
            ? <><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></>
            : <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>
          }
        </svg>
      </button>
    </div>
  );
};

export const Steps = ({ current, total = 3 }) => (
  <div style={{ display: 'flex', gap: 5, marginBottom: 20 }}>
    {Array.from({ length: total }).map((_, i) => (
      <div key={i} style={{ flex: 1, height: 3, borderRadius: 2, background: i < current ? 'var(--teal)' : 'var(--bd)', transition: '.3s' }} />
    ))}
  </div>
);

export const AuthHead = ({ title, subtitle, center = false }) => (
  <div style={{ marginBottom: 22, textAlign: center ? 'center' : 'left' }}>
    <h2 style={{ fontSize: 26, fontWeight: 800, color: 'var(--t1)', letterSpacing: '-.5px', marginBottom: 6 }}>{title}</h2>
    <p style={{ fontSize: 14, color: 'var(--t2)', lineHeight: 1.6 }}>{subtitle}</p>
  </div>
);

export const AuthBody = ({ children }) => (
  <div style={{ padding: '22px 18px', background: 'var(--white)', flex: 1, overflowY: 'auto' }}>{children}</div>
);

export const AuthTop = ({ onBack, title, right }) => (
  <div style={{ background: 'var(--white)', padding: '13px 18px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid var(--bd)', position: 'sticky', top: 0, zIndex: 10 }}>
    {onBack ? <BackBtn onClick={onBack} /> : <div style={{ width: 36 }} />}
    <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--t1)', flex: 1 }}>{title}</span>
    {right}
  </div>
);

export const OTPInput = ({ onComplete }) => {
  const [values, setValues] = React.useState(['','','','','','']);
  const refs = React.useRef([]);

  const handleChange = (i, val) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...values];
    next[i] = val;
    setValues(next);
    if (val && i < 5) refs.current[i + 1]?.focus();
    if (next.every(v => v) && next.join('').length === 6) {
      onComplete(next.join(''));
    }
  };

  const handleKeyDown = (i, e) => {
    if (e.key === 'Backspace' && !values[i] && i > 0) refs.current[i - 1]?.focus();
  };

  return (
    <div style={{ display: 'flex', gap: 10, justifyContent: 'center', margin: '20px 0' }}>
      {values.map((v, i) => (
        <input
          key={i}
          ref={el => refs.current[i] = el}
          maxLength={1}
          type="text"
          inputMode="numeric"
          value={v}
          onChange={e => handleChange(i, e.target.value)}
          onKeyDown={e => handleKeyDown(i, e)}
          style={{
            width: 52, height: 60, border: `1.5px solid ${v ? 'var(--teal)' : 'var(--bd)'}`,
            borderRadius: 13, fontSize: 26, fontWeight: 700, fontFamily: 'var(--ff)',
            color: v ? 'var(--teal2)' : 'var(--t1)', textAlign: 'center', outline: 'none',
            background: v ? 'var(--teal3)' : 'var(--bg)', transition: '.2s',
          }}
        />
      ))}
    </div>
  );
};

export const SetItem = ({ icon, iconBg, label, sub, right, onClick }) => (
  <div
    onClick={onClick}
    style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '14px 16px', borderBottom: '1px solid var(--bd)', cursor: 'pointer', transition: '.15s' }}
    onMouseDown={e => e.currentTarget.style.background = 'var(--bg)'}
    onMouseUp={e => e.currentTarget.style.background = 'transparent'}
  >
    <div style={{ width: 34, height: 34, borderRadius: 10, background: iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
      {icon}
    </div>
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--t1)' }}>{label}</div>
      {sub && <div style={{ fontSize: 12, color: 'var(--t3)', marginTop: 1 }}>{sub}</div>}
    </div>
    {right}
  </div>
);
