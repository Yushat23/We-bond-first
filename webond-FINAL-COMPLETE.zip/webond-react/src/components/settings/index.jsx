// src/components/settings/index.jsx
import React, { useState } from 'react';
import useStore from '../../store/useStore';
import { IconBtn, SetItem, Toggle } from '../shared';
import toast from 'react-hot-toast';

export const Settings = () => {
  const { user, avClass, navTo, logout } = useStore();
  const [notifs, setNotifs] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [aiEnabled, setAiEnabled] = useState(true);
  const initial = (user?.name || 'Y')[0].toUpperCase();

  const arrowIcon = (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="var(--t3)" strokeWidth="2" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
    </div>
  );

  return (
    <div>
      <div style={{ background: '#fff', padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5, borderBottom: '1px solid var(--bd)' }}>
        <span style={{ fontSize: 18, fontWeight: 700, color: 'var(--t1)' }}>Settings</span>
        <IconBtn onClick={() => navTo('profile')}>
          <svg viewBox="0 0 24 24" fill="none" stroke="var(--t2)" strokeWidth="2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </IconBtn>
      </div>

      {/* Profile card */}
      <div style={{ background: '#fff', padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 13, borderBottom: '1px solid var(--bd)', marginBottom: 10 }}>
        <div className={avClass} style={{ width: 56, height: 56, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 21, fontWeight: 800, color: '#fff', flexShrink: 0 }}>{initial}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--t1)' }}>{user?.name || 'Yushat'}</div>
          <div style={{ fontSize: 12, color: 'var(--teal)', fontWeight: 500, marginTop: 2 }}>@{user?.username || 'yushat'}</div>
          <div style={{ fontSize: 11, color: 'var(--t3)', marginTop: 1 }}>{user?.email || 'you@example.com'}</div>
        </div>
        <div className={avClass} style={{ width: 48, height: 48, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 800, color: '#fff', flexShrink: 0 }}>{initial}</div>
      </div>

      {/* Account */}
      <div style={{ margin: '0 14px 7px', fontSize: 11, fontWeight: 700, color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: '.7px' }}>Account</div>
      <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', margin: '0 14px 14px', boxShadow: '0 2px 12px rgba(0,0,0,.06)' }}>
        <SetItem
          iconBg="var(--teal3)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>}
          label="Edit profile"
          sub="Name, bio, photo"
          right={arrowIcon}
          onClick={() => toast.success('✏️ Edit profile — full version!')}
        />
        <SetItem
          iconBg="var(--teal3)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>}
          label="Phone number"
          sub="+234 ··· ···· ····"
          right={arrowIcon}
          onClick={() => toast.success('📱 Phone — full version!')}
        />
        <SetItem
          iconBg="#FEF9EE"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--amber)" strokeWidth="2" strokeLinecap="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>}
          label="Email address"
          sub={user?.email || 'you@example.com'}
          right={arrowIcon}
          onClick={() => toast.success('📧 Email — full version!')}
        />
      </div>

      {/* Privacy */}
      <div style={{ margin: '0 14px 7px', fontSize: 11, fontWeight: 700, color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: '.7px' }}>Privacy &amp; Safety</div>
      <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', margin: '0 14px 14px', boxShadow: '0 2px 12px rgba(0,0,0,.06)' }}>
        <SetItem
          iconBg="var(--coral2)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--coral)" strokeWidth="2" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>}
          label="Privacy"
          sub="Who can see your content"
          right={arrowIcon}
          onClick={() => toast.success('🔒 Privacy — full version!')}
        />
        <SetItem
          iconBg="var(--purple2)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--purple)" strokeWidth="2" strokeLinecap="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>}
          label="Security"
          sub="2FA, login activity"
          right={arrowIcon}
          onClick={() => toast.success('🛡️ Security — full version!')}
        />
        <SetItem
          iconBg="var(--blue2)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--blue)" strokeWidth="2" strokeLinecap="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>}
          label="Blocked accounts"
          right={arrowIcon}
          onClick={() => toast.success('🚫 Blocked — full version!')}
        />
      </div>

      {/* Preferences */}
      <div style={{ margin: '0 14px 7px', fontSize: 11, fontWeight: 700, color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: '.7px' }}>Preferences</div>
      <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', margin: '0 14px 14px', boxShadow: '0 2px 12px rgba(0,0,0,.06)' }}>
        <SetItem
          iconBg="var(--teal3)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>}
          label="Notifications"
          sub={notifs ? 'All notifications on' : 'Muted'}
          right={<Toggle on={notifs} onToggle={() => setNotifs(!notifs)} />}
        />
        <SetItem
          iconBg="#F5F5F5"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#666" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>}
          label="Dark mode"
          sub={darkMode ? 'Dark' : 'Light'}
          right={<Toggle on={darkMode} onToggle={() => { setDarkMode(!darkMode); toast.success(darkMode ? '☀️ Light mode' : '🌙 Dark mode — full version!'); }} />}
        />
        <SetItem
          iconBg="var(--teal3)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>}
          label="Language"
          sub="English"
          right={arrowIcon}
          onClick={() => toast.success('🌐 Language — full version!')}
        />
        <SetItem
          iconBg="var(--teal3)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>}
          label="Webond AI"
          sub={aiEnabled ? 'Smart assistant enabled' : 'Disabled'}
          right={<Toggle on={aiEnabled} onToggle={() => setAiEnabled(!aiEnabled)} />}
        />
      </div>

      {/* Creator */}
      <div style={{ margin: '0 14px 7px', fontSize: 11, fontWeight: 700, color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: '.7px' }}>Creator Tools</div>
      <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', margin: '0 14px 14px', boxShadow: '0 2px 12px rgba(0,0,0,.06)' }}>
        <SetItem
          iconBg="var(--amber2)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--amber)" strokeWidth="2" strokeLinecap="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>}
          label="Monetisation"
          sub="Tips, subscriptions, brand deals"
          right={arrowIcon}
          onClick={() => toast.success('💰 Monetisation — full version!')}
        />
        <SetItem
          iconBg="var(--purple2)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--purple)" strokeWidth="2" strokeLinecap="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>}
          label="Analytics"
          sub="Impressions, reach, engagement"
          right={arrowIcon}
          onClick={() => toast.success('📊 Analytics — full version!')}
        />
      </div>

      {/* Support */}
      <div style={{ margin: '0 14px 7px', fontSize: 11, fontWeight: 700, color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: '.7px' }}>Support</div>
      <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', margin: '0 14px 14px', boxShadow: '0 2px 12px rgba(0,0,0,.06)' }}>
        <SetItem
          iconBg="var(--blue2)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--blue)" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>}
          label="Help Center"
          right={arrowIcon}
          onClick={() => toast.success('❓ Help — full version!')}
        />
        <SetItem
          iconBg="var(--teal3)"
          icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>}
          label="Terms &amp; Privacy"
          right={arrowIcon}
          onClick={() => toast.success('📄 Terms — full version!')}
        />
      </div>

      {/* Logout */}
      <div style={{ margin: '0 14px 14px' }}>
        <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', boxShadow: '0 2px 12px rgba(0,0,0,.06)' }}>
          <SetItem
            iconBg="var(--coral2)"
            icon={<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--coral)" strokeWidth="2" strokeLinecap="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>}
            label={<span style={{ color: 'var(--coral)', fontWeight: 700 }}>Log out</span>}
            onClick={logout}
          />
        </div>
      </div>

      <div style={{ padding: '4px 18px 20px', textAlign: 'center' }}>
        <div style={{ fontSize: 12, color: 'var(--t3)', fontWeight: 500 }}>Webond v1.0.0 · Made with ❤️ by Yushat</div>
        <div style={{ fontSize: 11, color: 'var(--t3)', marginTop: 4 }}>© 2025 Webond. All rights reserved.</div>
      </div>
    </div>
  );
};
