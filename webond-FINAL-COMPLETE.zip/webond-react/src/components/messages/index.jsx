// src/components/messages/index.jsx
import React from 'react';
import useStore from '../../store/useStore';
import { IconBtn } from '../shared';
import toast from 'react-hot-toast';

const OnlineBar = () => {
  const users = [
    { name: 'Amira', bg: 'linear-gradient(135deg,#B3EFE9,#06b6d4)', online: true },
    { name: 'Chidi', bg: 'linear-gradient(135deg,#fde68a,#fb923c)', online: true },
    { name: 'Fatima', bg: 'linear-gradient(135deg,#c4b5fd,#f9a8d4)', online: true },
    { name: 'Emeka', bg: 'linear-gradient(135deg,#fbcfe8,#fde68a)', online: false, away: true },
    { name: 'Ngozi', bg: 'linear-gradient(135deg,#86efac,#67e8f9)', online: true },
  ];
  return (
    <div style={{ padding: '10px 14px 14px', display: 'flex', gap: 12, overflowX: 'auto', scrollbarWidth: 'none' }}>
      {users.map(u => (
        <div key={u.name} onClick={() => toast.success(`💬 Opening chat with ${u.name}`)} style={{ position: 'relative', flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, cursor: 'pointer' }}>
          <div style={{ width: 48, height: 48, borderRadius: '50%', background: u.bg }} />
          <div style={{ position: 'absolute', top: 2, right: 2, width: 10, height: 10, background: u.away ? '#F59E0B' : '#22C55E', borderRadius: '50%', border: '2px solid var(--bg)' }} />
          <span style={{ fontSize: 10, color: 'var(--t2)', fontWeight: 500 }}>{u.name}</span>
        </div>
      ))}
    </div>
  );
};

export const Messages = () => {
  const { conversations, navTo } = useStore();

  return (
    <div>
      <div style={{ background: '#fff', padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5, borderBottom: '1px solid var(--bd)' }}>
        <span style={{ fontSize: 18, fontWeight: 700, color: 'var(--t1)' }}>Messages</span>
        <div style={{ display: 'flex', gap: 8 }}>
          <IconBtn><svg viewBox="0 0 24 24" fill="none" stroke="var(--t2)" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></IconBtn>
          <IconBtn><svg viewBox="0 0 24 24" fill="none" stroke="var(--t2)" strokeWidth="2" strokeLinecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></IconBtn>
        </div>
      </div>
      <OnlineBar />

      {/* Webond AI */}
      <div onClick={() => navTo('chat')} style={{ margin: '0 14px 8px', background: 'linear-gradient(135deg,var(--teal3),#fff)', borderRadius: 14, padding: '13px 14px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', border: '1px solid var(--bd)', transition: '.18s' }}>
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'linear-gradient(135deg,var(--teal),#00a892)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🤖</div>
          <div style={{ position: 'absolute', bottom: 0, right: 0, width: 18, height: 18, borderRadius: '50%', border: '2px solid #fff', background: 'var(--teal)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg viewBox="0 0 24 24" width="8" height="8" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" fill="white"/></svg>
          </div>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--teal2)', marginBottom: 2 }}>Webond AI</div>
          <div style={{ fontSize: 13, color: 'var(--teal2)', fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Ask me anything — always online!</div>
        </div>
        <div style={{ width: 8, height: 8, background: '#22C55E', borderRadius: '50%', flexShrink: 0 }} />
      </div>

      <div style={{ margin: '12px 14px 4px', fontSize: 11, fontWeight: 700, color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: '.7px' }}>Recent messages</div>

      {/* Conversation list */}
      <div style={{ background: '#fff', borderRadius: '16px 16px 0 0' }}>
        {conversations.filter(c => !c.isAI).map((c, i) => (
          <div key={c.id} onClick={() => navTo('chat')} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 18px', borderBottom: i < conversations.length - 2 ? '1px solid var(--bd)' : 'none', cursor: 'pointer', transition: '.15s' }}
            onMouseDown={e => e.currentTarget.style.background = 'var(--teal3)'}
            onMouseUp={e => e.currentTarget.style.background = 'transparent'}
          >
            <div style={{ position: 'relative', flexShrink: 0 }}>
              {c.avatarColor
                ? <div style={{ width: 48, height: 48, borderRadius: '50%', background: c.avatarColor }} />
                : <div className={c.avatarClass || 'av-g'} style={{ width: 48, height: 48, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17, fontWeight: 700, color: '#fff' }}>{c.name[0]}</div>
              }
              {c.online && <div style={{ position: 'absolute', bottom: 2, right: 2, width: 11, height: 11, background: '#22C55E', borderRadius: '50%', border: '2px solid var(--bg)' }} />}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--t1)', marginBottom: 2 }}>{c.name}</div>
              <div style={{ fontSize: 13, color: c.unread ? 'var(--t1)' : 'var(--t3)', fontWeight: c.unread ? 600 : 400, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.lastMessage}</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 5 }}>
              <span style={{ fontSize: 11, color: 'var(--t3)' }}>{c.time}</span>
              {c.unread > 0 && (
                <div style={{ width: 20, height: 20, background: 'var(--coral)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#fff' }}>{c.unread}</div>
              )}
            </div>
          </div>
        ))}
      </div>
      <div style={{ height: 16 }} />
    </div>
  );
};
