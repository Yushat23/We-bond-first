// src/components/video/index.jsx
import React, { useState } from 'react';
import useStore from '../../store/useStore';
import { IconBtn } from '../shared';
import toast from 'react-hot-toast';

const SHORT_VIDEOS = [
  { id: 'v1', user: '@ngozi_creates', verified: true, avatarBg: 'linear-gradient(135deg,#B3EFE9,#06b6d4)', desc: 'Night life in Abuja is something else 🔥 This city never sleeps! POV: rooftop in Maitama', emoji: '👩‍💼', bg: 'img-dark', likes: '48.2k', comments: '2.8k', duration: '0:42', liked: true },
  { id: 'v2', user: '@tech_chidi', verified: true, avatarBg: 'linear-gradient(135deg,#fde68a,#fb923c)', desc: 'Everything you need to know about building a startup in Lagos ⚡ Full street verification', emoji: '🏙️', bg: 'img-blue', likes: '12.4k', comments: '893', duration: '1:14', liked: false },
];

const TABS_VID = ['Text', 'Videos', 'Photos', 'Reels', 'LIVE'];

const ShortCard = ({ video, onPlay }) => {
  const [liked, setLiked] = useState(video.liked);
  const [saved, setSaved] = useState(false);

  return (
    <div style={{ background: '#fff', borderRadius: 16, margin: '0 14px 10px', overflow: 'hidden', boxShadow: '0 2px 12px rgba(0,0,0,.06)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: video.avatarBg, flexShrink: 0 }} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--t1)' }}>{video.user} {video.verified && '✓'}</div>
            <div style={{ fontSize: 11, color: 'var(--t3)' }}>2 hours ago</div>
          </div>
        </div>
        <IconBtn style={{ background: 'var(--bg)' }}><svg viewBox="0 0 24 24" fill="none" stroke="var(--t3)" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg></IconBtn>
      </div>
      <div className={video.bg} onClick={onPlay} style={{ width: '100%', aspectRatio: '4/3', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', position: 'relative' }}>
        <span style={{ fontSize: 70 }}>{video.emoji}</span>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'rgba(0,0,0,.4)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg viewBox="0 0 24 24" width="22" height="22" fill="#fff"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          </div>
        </div>
        <div style={{ position: 'absolute', top: 10, right: 10, background: 'rgba(0,0,0,.5)', borderRadius: 20, padding: '3px 10px', fontSize: 11, color: '#fff', fontWeight: 600 }}>{video.duration}</div>
      </div>
      <div style={{ padding: 12 }}>
        <div style={{ fontSize: 13, color: 'var(--t1)', marginBottom: 9, lineHeight: 1.5 }}>{video.desc}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          {[
            { icon: <svg viewBox="0 0 24 24" width="17" height="17" fill={liked ? 'var(--coral)' : 'none'} stroke={liked ? 'var(--coral)' : 'currentColor'} strokeWidth="2" strokeLinecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>, val: video.likes, action: () => setLiked(!liked), active: liked },
            { icon: <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>, val: video.comments, action: () => {} },
            { icon: <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>, val: 'Share', action: () => toast.success('🔗 Link copied!') },
          ].map(({ icon, val, action, active }) => (
            <button key={val} onClick={action} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 600, color: active ? 'var(--coral)' : 'var(--t3)', cursor: 'pointer', border: 'none', background: 'none', fontFamily: 'var(--ff)' }}>{icon}{val}</button>
          ))}
          <button onClick={() => setSaved(!saved)} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 600, color: saved ? 'var(--teal)' : 'var(--t3)', cursor: 'pointer', border: 'none', background: 'none', fontFamily: 'var(--ff)', marginLeft: 'auto' }}>
            <svg viewBox="0 0 24 24" width="17" height="17" fill={saved ? 'var(--teal)' : 'none'} stroke={saved ? 'var(--teal)' : 'currentColor'} strokeWidth="2" strokeLinecap="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export const VideoFeed = () => {
  const { navTo } = useStore();
  const [activeTab, setActiveTab] = useState('Text');
  return (
    <div>
      <div style={{ background: '#fff', padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5, borderBottom: '1px solid var(--bd)' }}>
        <span style={{ fontSize: 18, fontWeight: 700, color: 'var(--t1)' }}>Short video feed</span>
        <IconBtn><svg viewBox="0 0 24 24" fill="none" stroke="var(--t2)" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></IconBtn>
      </div>
      <div style={{ background: '#fff', padding: '0 14px', display: 'flex', gap: 8, borderBottom: '1px solid var(--bd)', overflowX: 'auto', scrollbarWidth: 'none' }}>
        {TABS_VID.map(t => (
          <div key={t} onClick={() => setActiveTab(t)} style={{ padding: '12px 14px', fontSize: 13, fontWeight: 600, color: activeTab === t ? 'var(--teal)' : 'var(--t3)', cursor: 'pointer', borderBottom: `2.5px solid ${activeTab === t ? 'var(--teal)' : 'transparent'}`, whiteSpace: 'nowrap', transition: '.18s', flexShrink: 0 }}>{t}</div>
        ))}
      </div>
      <div style={{ marginTop: 12 }}>
        {SHORT_VIDEOS.map(v => <ShortCard key={v.id} video={v} onPlay={() => navTo('reel')} />)}
      </div>
      <div style={{ height: 16 }} />
    </div>
  );
};

export const ReelScreen = () => {
  const { navTo, avClass, user } = useStore();
  const [liked, setLiked] = useState(true);
  const [saved, setSaved] = useState(false);
  const initial = (user?.name || 'Y')[0].toUpperCase();

  return (
    <div style={{ position: 'absolute', inset: 0, background: '#000', padding: 0 }}>
      <div style={{ width: '100%', height: '100%', background: 'linear-gradient(180deg,#0a1628,#0d2d2a 40%,#1a0a28)', position: 'relative' }}>
        <div style={{ position: 'absolute', top: '20%', left: 0, right: 70, bottom: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 100 }}>👩‍💼</div>
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg,rgba(0,0,0,.88) 0%,rgba(0,0,0,.04) 45%,rgba(0,0,0,.3) 100%)' }} />

        {/* Top */}
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: 14 }}>
            {['Following', 'For You', 'LIVE'].map(t => (
              <span key={t} onClick={() => {}} style={{ fontSize: 14, fontWeight: 600, color: t === 'For You' ? '#fff' : 'rgba(255,255,255,.4)', cursor: 'pointer', paddingBottom: 3, borderBottom: t === 'For You' ? '2px solid var(--teal)' : 'none' }}>{t}</span>
            ))}
          </div>
          <button onClick={() => navTo('video')} style={{ width: 38, height: 38, borderRadius: 12, background: 'rgba(255,255,255,.15)', backdropFilter: 'blur(6px)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg viewBox="0 0 24 24" width="18" height="18" stroke="#fff" fill="none" strokeWidth="2" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>

        {/* Right actions */}
        <div style={{ position: 'absolute', right: 12, bottom: 110, display: 'flex', flexDirection: 'column', gap: 20, alignItems: 'center' }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
            <div className={avClass} style={{ width: 44, height: 44, borderRadius: '50%', border: '2.5px solid rgba(255,255,255,.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 800, color: '#fff' }}>{initial}</div>
            <div onClick={() => toast.success('✅ Following!')} style={{ width: 19, height: 19, background: 'var(--teal)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', marginTop: -10 }}>
              <svg viewBox="0 0 24 24" width="10" height="10" stroke="#fff" fill="none" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </div>
          </div>
          {[
            { icon: <svg viewBox="0 0 24 24" width="20" height="20" fill={liked ? 'var(--coral)' : 'none'} stroke={liked ? 'var(--coral)' : '#fff'} strokeWidth="2" strokeLinecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>, val: liked ? '48.3k' : '48.2k', action: () => setLiked(!liked), bg: liked ? 'rgba(255,107,107,.15)' : 'rgba(255,255,255,.12)' },
            { icon: <svg viewBox="0 0 24 24" width="20" height="20" fill={saved ? 'var(--teal)' : 'none'} stroke={saved ? 'var(--teal)' : '#fff'} strokeWidth="2" strokeLinecap="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>, val: 'Save', action: () => setSaved(!saved), bg: saved ? 'rgba(0,194,168,.15)' : 'rgba(255,255,255,.12)' },
            { icon: <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>, val: '2.8k', action: () => {}, bg: 'rgba(255,255,255,.12)' },
            { icon: <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>, val: 'Share', action: () => toast.success('🔗 Copied!'), bg: 'rgba(255,255,255,.12)' },
            { icon: <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" style={{ animation: 'spin 8s linear infinite' }}><circle cx="12" cy="12" r="3"/><path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83"/></svg>, val: 'Sound', action: () => {}, bg: 'rgba(255,255,255,.12)' },
          ].map(({ icon, val, action, bg }) => (
            <div key={val} onClick={action} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, cursor: 'pointer' }}>
              <div style={{ width: 44, height: 44, borderRadius: '50%', background: bg, backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</div>
              <span style={{ fontSize: 11, color: '#fff', fontWeight: 600, textShadow: '0 1px 3px rgba(0,0,0,.5)' }}>{val}</span>
            </div>
          ))}
        </div>

        {/* Bottom info */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 68, padding: '18px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'linear-gradient(135deg,var(--teal),#00a892)', border: '2px solid rgba(255,255,255,.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 800, color: '#fff', flexShrink: 0 }}>N</div>
            <span style={{ fontSize: 15, fontWeight: 700, color: '#fff' }}>@ngozi_creates ✓</span>
            <div onClick={() => toast.success('✅ Following!')} style={{ padding: '4px 12px', background: 'rgba(0,194,168,.3)', borderRadius: 16, fontSize: 11, fontWeight: 700, color: 'var(--teal)', border: '1px solid rgba(0,194,168,.5)', cursor: 'pointer', backdropFilter: 'blur(4px)' }}>+ Follow</div>
          </div>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,.85)', lineHeight: 1.5, marginBottom: 8 }}>Night life in Abuja is something else 🔥 This city never sleeps! POV: rooftop in Maitama</div>
          <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap', marginBottom: 10 }}>
            {['#Abuja', '#NightLife', '#Webond'].map(t => (
              <span key={t} style={{ fontSize: 11, color: 'var(--teal)', background: 'rgba(0,194,168,.15)', padding: '3px 9px', borderRadius: 14, fontWeight: 500, border: '1px solid rgba(0,194,168,.25)' }}>{t}</span>
            ))}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="rgba(255,255,255,.7)" strokeWidth="2" strokeLinecap="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
            <span style={{ fontSize: 11, color: 'rgba(255,255,255,.65)' }}>Afrobeats Mix — DJ Neptune ft. Wizkid</span>
          </div>
        </div>

        {/* Progress bar */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 2.5, background: 'rgba(255,255,255,.15)' }}>
          <div style={{ height: '100%', background: 'var(--teal)', borderRadius: 2, animation: 'vidprog 12s linear infinite' }} />
        </div>
      </div>
    </div>
  );
};
