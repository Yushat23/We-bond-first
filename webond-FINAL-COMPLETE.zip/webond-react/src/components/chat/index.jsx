// src/components/chat/index.jsx
import React, { useState, useRef, useEffect } from 'react';
import useStore from '../../store/useStore';
import { IconBtn } from '../shared';

export const Chat = () => {
  const { chatMessages, sendChatMessage, navTo } = useStore();
  const [input, setInput] = useState('');
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSend = () => {
    const text = input.trim();
    if (!text) return;
    setInput('');
    sendChatMessage(text);
  };

  const formatTime = (t) => {
    if (t) return t;
    const n = new Date();
    const h = n.getHours() % 12 || 12;
    const m = n.getMinutes();
    return `${h}:${m < 10 ? '0' : ''}${m} ${n.getHours() < 12 ? 'AM' : 'PM'}`;
  };

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      {/* Header */}
      <div style={{ background: '#fff', padding: '12px 15px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid var(--bd)', position: 'sticky', top: 0, zIndex: 5, flexShrink: 0 }}>
        <button onClick={() => navTo('messages')} style={{ width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', borderRadius: 9, background: 'var(--bg)', border: 'none' }}>
          <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--t1)" strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'linear-gradient(135deg,var(--teal),#00a892)', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🤖</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--t1)' }}>Webond AI</div>
          <div style={{ fontSize: 12, color: 'var(--teal)', fontWeight: 500 }}>● Always online · Powered by AI</div>
        </div>
        <IconBtn style={{ background: 'var(--teal3)' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
        </IconBtn>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 14px', display: 'flex', flexDirection: 'column', gap: 10, scrollbarWidth: 'none' }}>
        {chatMessages.map((msg) => (
          <div key={msg.id} style={{ display: 'flex', flexDirection: 'column', alignItems: msg.role === 'user' ? 'flex-start' : 'flex-end', animation: 'fadeUp .3s ease' }}>
            {msg.role === 'user' ? (
              /* AI message (left) */
              <div style={{ maxWidth: '76%', background: '#fff', color: 'var(--t1)', borderRadius: '18px 18px 18px 4px', padding: '11px 14px', fontSize: 14, lineHeight: 1.55, boxShadow: 'var(--sh)', alignSelf: 'flex-start' }}>
                <div style={{ background: 'linear-gradient(135deg,var(--teal3),#fff)', border: '1px solid var(--teal4)', borderRadius: 12, padding: '10px 12px', display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                  <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--teal)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 800, color: '#fff', flexShrink: 0 }}>W</div>
                  <div style={{ fontSize: 13, color: 'var(--t2)', lineHeight: 1.55 }} dangerouslySetInnerHTML={{ __html: msg.content.replace(/\n/g, '<br>').replace(/\*\*(.*?)\*\*/g, '<strong style="color:var(--teal2)">$1</strong>').replace(/<em>(.*?)<\/em>/g, '<em>$1</em>') }} />
                </div>
                <div style={{ fontSize: 10, opacity: .55, marginTop: 4, textAlign: 'left', color: 'var(--t3)' }}>{formatTime(msg.time)}</div>
              </div>
            ) : (
              /* User message (right) */
              <div style={{ maxWidth: '76%', background: 'var(--teal)', color: '#fff', borderRadius: '18px 18px 4px 18px', padding: '11px 14px', fontSize: 14, lineHeight: 1.55, alignSelf: 'flex-end' }}>
                {msg.content}
                <div style={{ fontSize: 10, opacity: .55, marginTop: 4, textAlign: 'right' }}>{formatTime(msg.time)}</div>
              </div>
            )}
          </div>
        ))}

        {/* Typing indicator */}
        <div style={{ display: 'flex', gap: 5, alignItems: 'center', padding: '10px 13px', background: '#fff', borderRadius: 17, borderBottomLeftRadius: 4, alignSelf: 'flex-start', boxShadow: 'var(--sh)' }}>
          {[0, .2, .4].map((d, i) => (
            <div key={i} style={{ width: 7, height: 7, background: 'var(--t3)', borderRadius: '50%', animation: `typing 1.2s ease infinite ${d}s` }} />
          ))}
        </div>
        <div ref={bottomRef} />
      </div>

      {/* Quick prompts */}
      <div style={{ padding: '8px 14px 4px', display: 'flex', gap: 7, overflowX: 'auto', scrollbarWidth: 'none', flexShrink: 0 }}>
        {['Write me a post', 'What\'s trending?', 'Summarise my feed', 'Help with caption'].map(p => (
          <button key={p} onClick={() => { setInput(p); }} style={{ padding: '6px 12px', borderRadius: 20, border: '1px solid var(--bd)', background: '#fff', fontSize: 12, fontWeight: 500, color: 'var(--t2)', cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'var(--ff)', transition: '.18s', flexShrink: 0 }}>
            {p}
          </button>
        ))}
      </div>

      {/* Input bar */}
      <div style={{ background: '#fff', padding: '10px 13px', display: 'flex', alignItems: 'center', gap: 8, borderTop: '1px solid var(--bd)', flexShrink: 0 }}>
        <IconBtn style={{ background: 'var(--teal3)', flexShrink: 0 }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
        </IconBtn>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="Ask Webond AI anything..."
          style={{ flex: 1, padding: '10px 14px', background: 'var(--bg)', borderRadius: 20, border: 'none', outline: 'none', fontSize: 14, fontFamily: 'var(--ff)', color: 'var(--t1)' }}
        />
        <IconBtn style={{ background: 'var(--teal3)', flexShrink: 0 }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2" fill="none" strokeLinecap="round"/><line x1="9" y1="9" x2="9.01" y2="9" strokeWidth="2.5"/><line x1="15" y1="9" x2="15.01" y2="9" strokeWidth="2.5"/></svg>
        </IconBtn>
        <button onClick={handleSend} style={{ width: 40, height: 40, background: 'var(--teal)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0, border: 'none', boxShadow: '0 3px 10px rgba(0,194,168,.35)', transition: '.18s' }}>
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
        </button>
      </div>
    </div>
  );
};
