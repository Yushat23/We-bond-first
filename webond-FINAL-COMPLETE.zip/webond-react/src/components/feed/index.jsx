// src/components/feed/index.jsx
import React, { useState } from 'react';
import useStore from '../../store/useStore';
import { IconBtn, Avatar, TopBar } from '../shared';
import toast from 'react-hot-toast';

const HeartIcon = ({ filled }) => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill={filled ? 'var(--coral)' : 'none'} stroke={filled ? 'var(--coral)' : 'currentColor'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
  </svg>
);

const CommentIcon = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
  </svg>
);

const ShareIcon = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
  </svg>
);

const BookmarkIcon = ({ filled }) => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill={filled ? 'var(--teal)' : 'none'} stroke={filled ? 'var(--teal)' : 'currentColor'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
  </svg>
);

const imgColors = ['img-teal', 'img-coral', 'img-amber', 'img-blue', 'img-purple', 'img-green'];

const PostCard = ({ post }) => {
  const { likePost, user } = useStore();
  const [bookmarked, setBookmarked] = useState(false);
  const [showHeart, setShowHeart] = useState(false);

  const formatNum = (n) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : n;

  const handleLike = () => {
    likePost(post.id);
    if (!post.isLiked) { setShowHeart(true); setTimeout(() => setShowHeart(false), 600); }
  };

  const handleDoubleTap = (() => {
    let last = 0;
    return () => {
      const now = Date.now();
      if (now - last < 300) { if (!post.isLiked) handleLike(); }
      last = now;
    };
  })();

  const timeAgo = (date) => {
    const diff = Date.now() - new Date(date).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return 'Just now';
    if (m < 60) return `${m}m`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h`;
    return `${Math.floor(h / 24)}d`;
  };

  return (
    <div style={{ background: '#fff', marginBottom: 8, position: 'relative' }}>
      {showHeart && (
        <div style={{ position: 'absolute', top: '40%', left: '50%', transform: 'translate(-50%,-50%)', fontSize: 60, zIndex: 10, animation: 'heartPop .6s ease forwards', pointerEvents: 'none' }}>❤️</div>
      )}
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '13px 15px 9px' }}>
        {post.avatarClass
          ? <div className={post.avatarClass} style={{ width: 40, height: 40, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, fontWeight: 700, color: '#fff', flexShrink: 0 }}>{post.username[0]}</div>
          : <div style={{ width: 40, height: 40, borderRadius: '50%', background: post.avatarColor || 'var(--teal)', flexShrink: 0 }} />
        }
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--t1)', display: 'flex', alignItems: 'center', gap: 5 }}>
            {post.username}
            {post.verified && <span style={{ color: 'var(--teal)', fontSize: 13 }}>✓</span>}
            {post.userId === user?.id && (
              <span style={{ fontSize: 9, background: 'var(--teal3)', color: 'var(--teal2)', padding: '2px 5px', borderRadius: 4, fontWeight: 700 }}>You</span>
            )}
          </div>
          <div style={{ fontSize: 11, color: 'var(--t3)', marginTop: 1 }}>{timeAgo(post.createdAt)} · 🌍 {post.privacy}</div>
        </div>
        <button style={{ padding: 6, background: 'none', border: 'none', cursor: 'pointer' }}>
          <svg viewBox="0 0 24 24" width="16" height="16" stroke="var(--t3)" fill="none" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>
        </button>
      </div>

      {/* Content */}
      <div onClick={handleDoubleTap} style={{ padding: '0 15px 10px', fontSize: 14, color: 'var(--t1)', lineHeight: 1.65 }}
        dangerouslySetInnerHTML={{ __html: post.content.replace(/(#\w+)/g, '<span style="color:var(--teal)">$1</span>') }}
      />

      {/* AI Summary */}
      {post.aiSummary && (
        <div style={{ margin: '0 15px 10px', padding: 13, background: 'var(--teal3)', borderRadius: 12, borderLeft: '3px solid var(--teal)' }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--teal2)', marginBottom: 4 }}>🤖 Webond AI summary</div>
          <div style={{ fontSize: 12, color: 'var(--t2)', lineHeight: 1.5 }}>{post.aiSummary}</div>
        </div>
      )}

      {/* Images */}
      {post.images?.length > 0 && (
        <div style={{ display: 'grid', gap: 2, gridTemplateColumns: post.images.length === 1 ? '1fr' : '1fr 1fr', cursor: 'pointer' }} onClick={handleDoubleTap}>
          {post.images.length === 1 && (
            <div className={imgColors[0]} style={{ width: '100%', aspectRatio: '16/9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 60 }}>{post.images[0]}</div>
          )}
          {post.images.length === 2 && post.images.map((img, i) => (
            <div key={i} className={imgColors[i]} style={{ aspectRatio: '1', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 44 }}>{img}</div>
          ))}
          {post.images.length >= 3 && (
            <>
              <div className={imgColors[0]} style={{ aspectRatio: '3/4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 44 }}>{post.images[0]}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {post.images.slice(1, 3).map((img, i) => (
                  <div key={i} className={imgColors[i + 1]} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36 }}>{img}</div>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* Actions */}
      <div style={{ display: 'flex', alignItems: 'center', padding: '8px 11px', gap: 2 }}>
        <button onClick={handleLike} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 10px', borderRadius: 10, cursor: 'pointer', border: 'none', background: 'none', fontSize: 12, fontWeight: 600, color: post.isLiked ? 'var(--coral)' : 'var(--t2)', fontFamily: 'var(--ff)', transition: '.18s' }}>
          <HeartIcon filled={post.isLiked} /><span>{formatNum(post.likes)}</span>
        </button>
        <button style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 10px', borderRadius: 10, cursor: 'pointer', border: 'none', background: 'none', fontSize: 12, fontWeight: 600, color: 'var(--t2)', fontFamily: 'var(--ff)' }}>
          <CommentIcon /><span>{formatNum(post.comments)}</span>
        </button>
        <button onClick={() => toast.success('🔗 Link copied!')} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 10px', borderRadius: 10, cursor: 'pointer', border: 'none', background: 'none', fontSize: 12, fontWeight: 600, color: 'var(--t2)', fontFamily: 'var(--ff)' }}>
          <ShareIcon /><span>Share</span>
        </button>
        <button onClick={() => setBookmarked(!bookmarked)} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 10px', borderRadius: 10, cursor: 'pointer', border: 'none', background: 'none', fontFamily: 'var(--ff)', marginLeft: 'auto' }}>
          <BookmarkIcon filled={bookmarked} />
        </button>
      </div>
    </div>
  );
};

const StoriesBar = () => {
  const { user, avClass } = useStore();
  const stories = [
    { name: 'Amira', bg: 'linear-gradient(135deg,#B3EFE9,#81d4fa)' },
    { name: 'Chidi', bg: 'linear-gradient(135deg,#fde68a,#fca5a5)' },
    { name: 'Fatima', bg: 'linear-gradient(135deg,#c4b5fd,#f9a8d4)' },
    { name: 'Emeka', bg: 'linear-gradient(135deg,#fbcfe8,#fde68a)' },
    { name: 'Ngozi', bg: 'linear-gradient(135deg,#86efac,#67e8f9)' },
  ];
  return (
    <div style={{ background: '#fff', borderBottom: '1px solid var(--bd)', padding: '12px 14px', display: 'flex', gap: 13, overflowX: 'auto', scrollbarWidth: 'none' }}>
      <div onClick={() => toast.success('📖 Add story — full version!')} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, flexShrink: 0, cursor: 'pointer' }}>
        <div style={{ width: 58, height: 58, borderRadius: '50%', border: '2px dashed var(--bd)', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        </div>
        <span style={{ fontSize: 10, color: 'var(--teal)', fontWeight: 700 }}>Your story</span>
      </div>
      {stories.map((s) => (
        <div key={s.name} onClick={() => toast.success(`👁 Viewing ${s.name}'s story`)} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, flexShrink: 0, cursor: 'pointer' }}>
          <div style={{ width: 58, height: 58, borderRadius: '50%', padding: 2.5, background: 'conic-gradient(var(--teal),var(--coral),var(--amber),var(--teal))' }}>
            <div style={{ width: '100%', height: '100%', borderRadius: '50%', border: '2.5px solid #fff', background: s.bg }} />
          </div>
          <span style={{ fontSize: 10, color: 'var(--t2)', fontWeight: 500, maxWidth: 62, textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap', textAlign: 'center' }}>{s.name}</span>
        </div>
      ))}
    </div>
  );
};

export const Feed = () => {
  const { posts, navTo, user, avClass } = useStore();
  return (
    <div>
      {/* Top bar */}
      <div style={{ background: '#fff', padding: '12px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5, borderBottom: '1px solid var(--bd)' }}>
        <span style={{ fontSize: 22, fontWeight: 900, letterSpacing: -1 }}>web<span style={{ color: 'var(--teal)' }}>ond</span></span>
        <div style={{ display: 'flex', gap: 8 }}>
          <IconBtn badge><svg viewBox="0 0 24 24" fill="none" stroke="var(--t2)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg></IconBtn>
          <IconBtn badge onClick={() => navTo('messages')}><svg viewBox="0 0 24 24" fill="none" stroke="var(--t2)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></IconBtn>
        </div>
      </div>
      <StoriesBar />
      {/* AI Brief */}
      <div style={{ margin: '10px 14px', background: 'linear-gradient(135deg,var(--teal),#00a892)', borderRadius: 14, padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 11, cursor: 'pointer' }} onClick={() => navTo('chat')}>
        <div style={{ width: 34, height: 34, borderRadius: 10, background: 'rgba(255,255,255,.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>Webond AI Brief</div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,.7)', marginTop: 1 }}>6 trending topics in your network ✨</div>
        </div>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.6)" strokeWidth="2" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
      </div>
      {posts.map(p => <PostCard key={p.id} post={p} />)}
      <div style={{ height: 16 }} />
    </div>
  );
};

// CREATE POST MODAL
export const CreatePostModal = ({ onClose }) => {
  const { addPost, user, avClass } = useStore();
  const [text, setText] = useState('');
  const [writing, setWriting] = useState(false);
  const initial = (user?.name || 'Y')[0].toUpperCase();

  const aiWrite = () => {
    setWriting(true);
    setText('');
    const lines = [
      "Just had the best day building Webond with my team 🚀 The future of social media is here! #Webond",
      "Innovation is not about being first — it's about being best. Webond is proof 💡 #Tech #Africa",
      "Grateful for everyone who believed in Webond from day one. We're just getting started 🙌 #Webond",
    ];
    const line = lines[Math.floor(Math.random() * lines.length)];
    let i = 0;
    const iv = setInterval(() => {
      if (i <= line.length) { setText(line.slice(0, i)); i++; }
      else { clearInterval(iv); setWriting(false); }
    }, 28);
  };

  const handlePost = () => {
    if (!text.trim()) { toast.error('⚠️ Write something first!'); return; }
    addPost(text.trim());
    onClose();
    toast.success('✅ Posted to Webond!');
  };

  const tools = [
    { icon: <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>, label: 'Photo', action: () => toast.success('📷 Photo — full version!') },
    { icon: <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>, label: 'Video', action: () => toast.success('🎬 Video — full version!') },
    { icon: <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>, label: 'AI Write', action: aiWrite },
    { icon: <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>, label: 'Location', action: () => toast.success('📍 Location — full version!') },
    { icon: <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--teal)" strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 12h3M9 9v6M15 9h-2a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h2"/></svg>, label: 'GIF', action: () => toast.success('😊 GIF — full version!') },
  ];

  return (
    <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.45)', zIndex: 30, display: 'flex', alignItems: 'flex-end' }}>
      <div onClick={e => e.stopPropagation()} style={{ background: '#fff', borderRadius: '24px 24px 0 0', padding: '0 0 20px', width: '100%', animation: 'slideUp .3s cubic-bezier(.4,0,.2,1)' }}>
        <div style={{ width: 36, height: 4, background: 'var(--bd)', borderRadius: 2, margin: '11px auto' }} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 18px 13px', borderBottom: '1px solid var(--bd)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div className={avClass} style={{ width: 33, height: 33, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#fff' }}>{initial}</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>{user?.name || 'Yushat'}</div>
              <div style={{ padding: '3px 9px', background: 'var(--teal3)', borderRadius: 12, fontSize: 10, fontWeight: 600, color: 'var(--teal2)', display: 'inline-block', marginTop: 2 }}>🌍 Everyone</div>
            </div>
          </div>
          <button onClick={handlePost} style={{ padding: '9px 22px', background: 'var(--teal)', border: 'none', borderRadius: 20, color: '#fff', fontSize: 14, fontWeight: 700, fontFamily: 'var(--ff)', cursor: 'pointer', boxShadow: '0 3px 12px rgba(0,194,168,.35)' }}>Post</button>
        </div>
        <div style={{ padding: '13px 18px' }}>
          <textarea value={text} onChange={e => setText(e.target.value)} placeholder={writing ? 'AI is writing...' : "What's on your mind?"} rows={3} style={{ width: '100%', border: 'none', outline: 'none', fontSize: 15, fontFamily: 'var(--ff)', color: 'var(--t1)', resize: 'none', minHeight: 85, lineHeight: 1.65, background: 'none' }} />
          <div style={{ display: 'flex', gap: 8, marginTop: 11, overflowX: 'auto', scrollbarWidth: 'none', paddingBottom: 4 }}>
            {tools.map(({ icon, label, action }) => (
              <button key={label} onClick={action} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, padding: '11px 14px', border: '1.5px dashed var(--bd)', borderRadius: 12, cursor: 'pointer', flexShrink: 0, transition: '.2s', background: 'none', fontFamily: 'var(--ff)' }}>
                {icon}
                <span style={{ fontSize: 11, color: 'var(--t2)', fontWeight: 500, whiteSpace: 'nowrap' }}>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
