// src/components/auth/index.jsx
import React, { useState, useEffect } from 'react';
import useStore from '../../store/useStore';
import {
  AuthTop, AuthBody, AuthHead, BtnFull, SocialBtn, Field, Input,
  PasswordInput, Divider, Steps, OTPInput, Avatar
} from '../shared';
import toast from 'react-hot-toast';

const SOCIAL_CONFIG = {
  google: { title: 'Continue with Google', sub: 'Choose your Google account', bg: '#4285F4', name: 'Yusuf Abubakar', email: 'yushat.work@gmail.com' },
  apple: { title: 'Sign in with Apple', sub: 'Continue to Webond', bg: '#000', name: 'Yusuf Abubakar', email: 'Hidden by Apple' },
  meta: { title: 'Continue with Meta', sub: 'Facebook or Instagram', bg: '#0866FF', name: 'Yusuf Abubakar', email: 'yushat@facebook.com' },
  x: { title: 'Sign in with X', sub: 'Connect your X account', bg: '#000', name: 'Yusuf Abubakar', email: '@yushat' },
};

const GoogleIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

// Social Auth Sheet
const SocialAuthSheet = ({ provider, onClose, onConfirm }) => {
  const [loading, setLoading] = useState(false);
  const c = SOCIAL_CONFIG[provider] || {};

  const handleConfirm = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); onConfirm(c); }, 1600);
  };

  return (
    <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.5)', zIndex: 50, display: 'flex', alignItems: 'flex-end' }}>
      <div onClick={e => e.stopPropagation()} style={{ background: '#fff', borderRadius: '24px 24px 0 0', padding: '0 0 28px', width: '100%', animation: 'slideUp .3s cubic-bezier(.4,0,.2,1)' }}>
        <div style={{ width: 36, height: 4, background: 'var(--bd)', borderRadius: 2, margin: '11px auto' }} />
        <div style={{ padding: '16px 20px 14px', borderBottom: '1px solid var(--bd)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 40, height: 40, borderRadius: 11, background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            {provider === 'google' ? <GoogleIcon /> : <span style={{ fontSize: 20, color: '#fff', fontWeight: 800 }}>{c.name?.[0]}</span>}
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--t1)' }}>{c.title}</div>
            <div style={{ fontSize: 12, color: 'var(--t3)', marginTop: 2 }}>{c.sub}</div>
          </div>
        </div>
        <div style={{ padding: '16px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: 13, background: 'var(--bg)', borderRadius: 13, marginBottom: 12, border: '1.5px solid var(--bd)' }}>
            <div style={{ width: 40, height: 40, borderRadius: '50%', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
              {c.name?.[0]}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--t1)' }}>{c.name}</div>
              <div style={{ fontSize: 12, color: 'var(--t3)' }}>{c.email}</div>
            </div>
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#22C55E" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
          <BtnFull style={{ background: c.bg, marginBottom: 8 }} onClick={handleConfirm} loading={loading}>
            Continue as {c.name?.split(' ')[0]}
          </BtnFull>
          <button onClick={onClose} style={{ width: '100%', padding: 13, borderRadius: 13, border: '1.5px solid var(--bd)', background: 'none', fontSize: 14, fontWeight: 600, fontFamily: 'var(--ff)', color: 'var(--t1)', cursor: 'pointer' }}>
            Use a different account
          </button>
        </div>
      </div>
    </div>
  );
};

// SPLASH
export const Splash = () => {
  const goTo = useStore(s => s.goTo);
  const loadSavedUser = useStore(s => s.loadSavedUser);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!loadSavedUser()) goTo('welcome');
    }, 2200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(145deg,#0a1628,#0d2d2a 50%,#0a1628)', position: 'relative', overflow: 'hidden' }}>
      {[340, 260, 180].map((s, i) => (
        <div key={i} style={{ position: 'absolute', width: s, height: s, borderRadius: '50%', border: `1px solid rgba(0,194,168,${.1 + i * .07})`, top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }} />
      ))}
      <div style={{ fontSize: 46, fontWeight: 900, color: '#fff', letterSpacing: -2, animation: 'pop .6s cubic-bezier(.34,1.56,.64,1) both', position: 'relative', zIndex: 1 }}>
        web<span style={{ color: 'var(--teal)' }}>ond</span>
      </div>
      <div style={{ fontSize: 14, color: 'rgba(255,255,255,.45)', marginTop: 8, position: 'relative', zIndex: 1, animation: 'pop .6s .15s both' }}>Connect Beyond</div>
      <div style={{ position: 'absolute', bottom: 50, display: 'flex', gap: 7, zIndex: 1 }}>
        {[0, .2, .4].map((d, i) => (
          <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: 'rgba(255,255,255,.4)', animation: `blink 1.2s ease infinite ${d}s` }} />
        ))}
      </div>
    </div>
  );
};

// WELCOME
export const Welcome = () => {
  const goTo = useStore(s => s.goTo);
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#fff' }}>
      <div style={{ flex: 1.2, background: 'linear-gradient(160deg,#0a1628,#0d3d38 50%,#0a1628)', position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '50px 30px 60px' }}>
        {[{ w: 320, t: '-80px', l: '-100px' }, { w: 240, b: '-50px', r: '-70px' }, { w: 180, mid: true }].map((c, i) => (
          <div key={i} style={{ position: 'absolute', width: c.w, height: c.w, borderRadius: '50%', border: '1px solid rgba(0,194,168,.18)', top: c.mid ? '35%' : c.t, left: c.mid ? '50%' : c.l, bottom: c.b, right: c.r, transform: c.mid ? 'translate(-50%,-50%)' : undefined }} />
        ))}
        <div style={{ fontSize: 52, fontWeight: 900, color: '#fff', letterSpacing: -3, position: 'relative', zIndex: 1, marginBottom: 8 }}>
          web<span style={{ color: 'var(--teal)' }}>ond</span>
        </div>
        <div style={{ fontSize: 14, color: 'rgba(255,255,255,.55)', textAlign: 'center', maxWidth: 230, lineHeight: 1.7, position: 'relative', zIndex: 1 }}>
          Next-gen social platform. AI-powered. Built for everyone on earth.
        </div>
        <div style={{ display: 'flex', gap: 8, position: 'relative', zIndex: 1, marginTop: 18, flexWrap: 'wrap', justifyContent: 'center' }}>
          {['🤖 AI-First', '🔒 E2E Encrypted', '⚡ Real-time', '🌍 Global'].map(f => (
            <span key={f} style={{ padding: '5px 12px', border: '1px solid rgba(255,255,255,.15)', borderRadius: 20, fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,.65)' }}>{f}</span>
          ))}
        </div>
      </div>
      <div style={{ padding: '26px 22px 36px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <BtnFull onClick={() => goTo('signup')}>Create your account</BtnFull>
        <BtnFull variant="ghost" onClick={() => goTo('login')}>Sign in to Webond</BtnFull>
        <p style={{ fontSize: 11, color: 'var(--t3)', textAlign: 'center', lineHeight: 1.7, marginTop: 4 }}>
          By continuing you agree to our <span style={{ color: 'var(--teal)', fontWeight: 600 }}>Terms</span> and <span style={{ color: 'var(--teal)', fontWeight: 600 }}>Privacy Policy</span>
        </p>
      </div>
    </div>
  );
};

// LOGIN
export const Login = () => {
  const { goTo, saveUser, avClass } = useStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [socialProvider, setSocialProvider] = useState(null);

  const validate = () => {
    const e = {};
    if (!email || !/\S+@\S+\.\S+/.test(email)) e.email = 'Enter a valid email';
    if (!password || password.length < 6) e.password = '6+ characters required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = () => {
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const user = { id: 'u1', name: 'Yushat', username: 'yushat', email, avClass };
      saveUser(user);
      goTo('profile');
    }, 1400);
  };

  const handleSocialConfirm = (c) => {
    const user = { id: 'u1', name: c.name, username: 'yushat', email: c.email, avClass };
    saveUser(user);
    setSocialProvider(null);
    toast.success(`✅ Signed in with ${socialProvider}`);
    setTimeout(() => goTo('profile'), 400);
  };

  return (
    <div style={{ height: '100%', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <AuthTop onBack={() => goTo('welcome')} title="Sign in" />
      <AuthBody>
        <AuthHead title="Welcome back 👋" subtitle="Sign in to your Webond account and start connecting" />
        <SocialBtn icon={<GoogleIcon />} onClick={() => setSocialProvider('google')}>Continue with Google</SocialBtn>
        <SocialBtn icon={<svg viewBox="0 0 24 24" width="22" height="22" fill="#000"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.18 1.27-2.16 3.8.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.78M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>} onClick={() => setSocialProvider('apple')}>Continue with Apple</SocialBtn>
        <SocialBtn icon={<svg viewBox="0 0 24 24" width="22" height="22" fill="#0866FF"><path d="M12 2.04C6.5 2.04 2 6.53 2 12.06 2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.85C10.44 7.34 11.93 5.96 14.22 5.96 15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96A10 10 0 0 0 22 12.06C22 6.53 17.5 2.04 12 2.04Z"/></svg>} onClick={() => setSocialProvider('meta')}>Continue with Meta</SocialBtn>
        <SocialBtn icon={<svg viewBox="0 0 24 24" width="22" height="22" fill="#000"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.748l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>} onClick={() => setSocialProvider('x')}>Continue with X</SocialBtn>
        <Divider label="or sign in with email" />
        <Field label="Email" error={errors.email}>
          <Input type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
        </Field>
        <Field label="Password" error={errors.password}>
          <PasswordInput placeholder="Your password" value={password} onChange={e => setPassword(e.target.value)} />
        </Field>
        <div style={{ textAlign: 'right', marginBottom: 18 }}>
          <span onClick={() => goTo('forgot')} style={{ fontSize: 13, color: 'var(--teal)', fontWeight: 600, cursor: 'pointer' }}>Forgot password?</span>
        </div>
        <BtnFull onClick={handleLogin} loading={loading}>Sign in</BtnFull>
        <div style={{ textAlign: 'center', marginTop: 14, fontSize: 14, color: 'var(--t2)' }}>
          No account? <span onClick={() => goTo('signup')} style={{ color: 'var(--teal)', fontWeight: 700, cursor: 'pointer' }}>Sign up free</span>
        </div>
      </AuthBody>
      {socialProvider && <SocialAuthSheet provider={socialProvider} onClose={() => setSocialProvider(null)} onConfirm={handleSocialConfirm} />}
    </div>
  );
};

// SIGNUP STEP 1
export const Signup = () => {
  const { goTo, setTmpSignup } = useStore();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [unError, setUnError] = useState('');
  const [unHint, setUnHint] = useState('Your unique @handle on Webond');
  const [socialProvider, setSocialProvider] = useState(null);
  const { saveUser, avClass } = useStore();

  const checkUsername = (val) => {
    const v = val.replace('@', '');
    setUsername('@' + v);
    if (v.length >= 3 && /^[a-zA-Z0-9_]+$/.test(v)) {
      setUnError('');
      setUnHint(`✓ @${v} is available!`);
    } else if (v.length > 0) {
      setUnError('3+ chars, letters/numbers only');
      setUnHint('');
    } else {
      setUnError('');
      setUnHint('Your unique @handle on Webond');
    }
  };

  const handleNext = () => {
    if (!firstName || !lastName) { toast.error('Enter your full name'); return; }
    const un = username.replace('@', '');
    if (!un || un.length < 3 || !/^[a-zA-Z0-9_]+$/.test(un)) { setUnError('3+ chars, letters/numbers only'); return; }
    setTmpSignup({ name: `${firstName} ${lastName}`, username: un });
    goTo('signup2');
  };

  const handleSocialConfirm = (c) => {
    const user = { id: 'u1', name: c.name, username: 'yushat', email: c.email, avClass };
    saveUser(user);
    setSocialProvider(null);
    setTimeout(() => goTo('profile'), 400);
  };

  return (
    <div style={{ height: '100%', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <AuthTop onBack={() => goTo('welcome')} title="Create account" />
      <AuthBody>
        <Steps current={1} />
        <AuthHead title="Your name 👤" subtitle="This will appear on your Webond profile for everyone to see" />
        <SocialBtn icon={<GoogleIcon />} onClick={() => setSocialProvider('google')}>Sign up with Google</SocialBtn>
        <Divider label="or fill in details" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <Field label="First name"><Input placeholder="Yusuf" value={firstName} onChange={e => setFirstName(e.target.value)} /></Field>
          <Field label="Last name"><Input placeholder="Abubakar" value={lastName} onChange={e => setLastName(e.target.value)} /></Field>
        </div>
        <Field label="Username" error={unError} hint={unError ? '' : unHint}>
          <Input placeholder="@yushat" value={username} onChange={e => checkUsername(e.target.value)} />
        </Field>
        <BtnFull onClick={handleNext} style={{ marginTop: 6 }}>Continue →</BtnFull>
        <div style={{ textAlign: 'center', marginTop: 14, fontSize: 14, color: 'var(--t2)' }}>
          Already on Webond? <span onClick={() => goTo('login')} style={{ color: 'var(--teal)', fontWeight: 700, cursor: 'pointer' }}>Sign in</span>
        </div>
      </AuthBody>
      {socialProvider && <SocialAuthSheet provider={socialProvider} onClose={() => setSocialProvider(null)} onConfirm={handleSocialConfirm} />}
    </div>
  );
};

// SIGNUP STEP 2
export const Signup2 = () => {
  const { goTo, setTmpSignup } = useStore();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleNext = () => {
    if (!email || !/\S+@\S+\.\S+/.test(email)) { setError('Enter a valid email'); return; }
    setError('');
    setTmpSignup({ email });
    goTo('signup3');
  };

  return (
    <div style={{ height: '100%', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <AuthTop onBack={() => goTo('signup')} title="Contact details" />
      <AuthBody>
        <Steps current={2} />
        <AuthHead title="How to reach you? 📱" subtitle="We'll use this to keep your account secure and recoverable" />
        <Field label="Email address" error={error}>
          <Input type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
        </Field>
        <Field label="Phone (optional)">
          <div style={{ display: 'flex', gap: 8 }}>
            <select style={{ padding: '12px 10px', border: '1.5px solid var(--bd)', borderRadius: 12, fontSize: 14, fontFamily: 'var(--ff)', color: 'var(--t1)', background: 'var(--bg)', outline: 'none', cursor: 'pointer', flexShrink: 0 }}>
              <option>🇳🇬 +234</option><option>🇺🇸 +1</option><option>🇬🇧 +44</option><option>🇬🇭 +233</option>
            </select>
            <Input type="tel" placeholder="080xxxxxxxx" style={{ flex: 1 }} />
          </div>
        </Field>
        <Field label="Date of birth" hint="You must be 13+ to join Webond">
          <Input type="date" />
        </Field>
        <BtnFull onClick={handleNext} style={{ marginTop: 6 }}>Continue →</BtnFull>
      </AuthBody>
    </div>
  );
};

// SIGNUP STEP 3
export const Signup3 = () => {
  const { goTo, tmpSignup } = useStore();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [strength, setStrength] = useState(0);

  const checkStr = (v) => {
    let s = 0;
    if (v.length >= 8) s++;
    if (/[A-Z]/.test(v)) s++;
    if (/[0-9]/.test(v)) s++;
    if (/[^A-Za-z0-9]/.test(v)) s++;
    setStrength(s);
  };

  const strColors = ['', '#EF4444', '#EF4444', 'var(--amber)', 'var(--teal)', 'var(--teal)'];
  const strLabels = ['', 'Weak', 'Weak', 'Medium', 'Strong', 'Very Strong'];

  const handleCreate = () => {
    if (password.length < 8) { toast.error('Password too short'); return; }
    if (password !== confirm) { setError('Passwords do not match'); return; }
    setError('');
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      goTo('otp');
    }, 1200);
  };

  return (
    <div style={{ height: '100%', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <AuthTop onBack={() => goTo('signup2')} title="Secure account" />
      <AuthBody>
        <Steps current={3} />
        <AuthHead title="Create password 🔐" subtitle="Make it strong to protect your Webond account" />
        <Field label="Password">
          <PasswordInput placeholder="Create password" value={password} onChange={e => { setPassword(e.target.value); checkStr(e.target.value); }} />
          <div style={{ display: 'flex', gap: 4, marginTop: 7 }}>
            {[1,2,3,4].map(i => <div key={i} style={{ flex: 1, height: 3, borderRadius: 2, background: i <= strength ? strColors[strength] : 'var(--bd)', transition: '.3s' }} />)}
          </div>
          {strength > 0 && <div style={{ fontSize: 11, fontWeight: 600, marginTop: 4, color: strColors[strength] }}>{strLabels[strength]}</div>}
        </Field>
        <Field label="Confirm password" error={error}>
          <PasswordInput placeholder="Repeat password" value={confirm} onChange={e => setConfirm(e.target.value)} />
        </Field>
        <div style={{ background: 'var(--teal3)', borderRadius: 11, padding: 12, marginBottom: 16 }}>
          {[['r1', password.length >= 8, 'At least 8 characters'], ['r2', /[A-Z]/.test(password), 'One uppercase letter'], ['r3', /[0-9]/.test(password) || /[^A-Za-z0-9]/.test(password), 'One number or symbol']].map(([key, ok, label]) => (
            <div key={key} style={{ fontSize: 12, color: ok ? 'var(--teal)' : 'var(--t3)', marginBottom: 3 }}>{ok ? '✓' : '○'} {label}</div>
          ))}
        </div>
        <BtnFull onClick={handleCreate} loading={loading}>Create account</BtnFull>
      </AuthBody>
    </div>
  );
};

// OTP VERIFICATION
export const OTPScreen = () => {
  const { goTo, tmpSignup } = useStore();
  const [timer, setTimer] = useState(60);

  useEffect(() => {
    const interval = setInterval(() => setTimer(t => Math.max(0, t - 1)), 1000);
    return () => clearInterval(interval);
  }, []);

  const handleComplete = (code) => {
    if (code === '123456' || code.length === 6) {
      toast.success('✅ Email verified!');
      setTimeout(() => goTo('setup'), 700);
    } else {
      toast.error('❌ Wrong code — try 123456');
    }
  };

  return (
    <div style={{ height: '100%', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <AuthTop onBack={() => goTo('signup3')} title="Verify email" />
      <AuthBody>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: 68, height: 68, borderRadius: 22, background: 'var(--teal3)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
            <svg viewBox="0 0 24 24" width="32" height="32" stroke="var(--teal)" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
            </svg>
          </div>
          <AuthHead title="Check your inbox 📬" subtitle={`We sent a 6-digit code to\n${tmpSignup.email || 'your email'}`} center />
          <OTPInput onComplete={handleComplete} />
          <div style={{ fontSize: 13, color: 'var(--t2)' }}>Resend in <strong style={{ color: 'var(--teal)' }}>{timer}s</strong></div>
          <div style={{ marginTop: 7, fontSize: 12, color: 'var(--t3)' }}>Demo: enter <strong style={{ color: 'var(--teal)' }}>123456</strong></div>
          <BtnFull onClick={() => handleComplete('123456')} style={{ marginTop: 20 }}>Verify &amp; Continue</BtnFull>
        </div>
      </AuthBody>
    </div>
  );
};

// FORGOT PASSWORD
export const ForgotPassword = () => {
  const { goTo } = useStore();
  const [email, setEmail] = useState('');

  const handleReset = () => {
    if (!email || !/\S+@\S+\.\S+/.test(email)) { toast.error('Enter a valid email'); return; }
    toast.success(`📧 Reset link sent to ${email}`);
    setTimeout(() => goTo('login'), 1200);
  };

  return (
    <div style={{ height: '100%', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <AuthTop onBack={() => goTo('login')} title="Reset password" />
      <AuthBody>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: 68, height: 68, borderRadius: 22, background: 'var(--coral2)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
            <svg viewBox="0 0 24 24" width="32" height="32" stroke="var(--coral)" fill="none" strokeWidth="2" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          </div>
          <AuthHead title="Forgot password? 🔑" subtitle="Enter your email and we'll send a reset link instantly" center />
          <Field label="Email" style={{ textAlign: 'left' }}>
            <Input type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
          </Field>
          <BtnFull onClick={handleReset}>Send reset link</BtnFull>
          <div style={{ textAlign: 'center', marginTop: 14, fontSize: 14 }}>
            <span onClick={() => goTo('login')} style={{ color: 'var(--teal)', fontWeight: 700, cursor: 'pointer' }}>← Back to sign in</span>
          </div>
        </div>
      </AuthBody>
    </div>
  );
};

// PROFILE SETUP
export const ProfileSetup = () => {
  const { goTo, setAvClass, avClass, tmpSignup, saveUser } = useStore();
  const [bio, setBio] = useState('');
  const avOptions = [
    { cls: 'av-g', label: 'G' }, { cls: 'av-c', label: 'C' }, { cls: 'av-p', label: 'P' },
    { cls: 'av-b', label: 'B' }, { cls: 'av-a', label: 'A' },
  ];
  const initial = (tmpSignup.name || 'Y')[0].toUpperCase();

  const handleFinish = () => {
    const user = { id: 'u1', name: tmpSignup.name || 'Yushat', username: tmpSignup.username || 'yushat', email: tmpSignup.email || '', avClass, bio };
    saveUser(user);
    toast.success(`🎉 Welcome to Webond, ${(tmpSignup.name || 'Yushat').split(' ')[0]}!`);
    setTimeout(() => goTo('interests'), 600);
  };

  return (
    <div style={{ height: '100%', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <AuthTop title="Set up profile" right={<span onClick={handleFinish} style={{ fontSize: 14, fontWeight: 600, color: 'var(--t3)', cursor: 'pointer' }}>Skip</span>} />
      <AuthBody>
        <div style={{ textAlign: 'center' }}>
          <AuthHead title="Make it yours ✨" subtitle="Add a photo and bio so friends can find and recognise you" center />
          <div onClick={() => toast.success('📷 Camera — full version!')} style={{ width: 70, height: 70, borderRadius: '50%', border: '2px dashed var(--bd)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', margin: '0 auto 12px', transition: '.2s' }}>
            <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="var(--t3)" strokeWidth="2" strokeLinecap="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
          </div>
          <p style={{ fontSize: 12, color: 'var(--t3)', marginBottom: 14 }}>Tap to upload profile photo</p>
          <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--t2)', textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 9, textAlign: 'left' }}>Or pick a colour avatar</p>
          <div style={{ display: 'flex', gap: 11, justifyContent: 'center', margin: '0 0 8px' }}>
            {avOptions.map(({ cls }) => (
              <div key={cls} onClick={() => setAvClass(cls)} className={cls} style={{ width: 52, height: 52, borderRadius: '50%', cursor: 'pointer', border: `3px solid ${avClass === cls ? 'var(--teal)' : 'transparent'}`, boxShadow: avClass === cls ? '0 0 0 3px rgba(0,194,168,.2)' : 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 19, fontWeight: 800, color: '#fff', transition: '.2s' }}>
                {initial}
              </div>
            ))}
          </div>
          <Field label="Bio (optional)" style={{ textAlign: 'left', marginTop: 14 }}>
            <textarea value={bio} onChange={e => setBio(e.target.value)} placeholder="Tech founder. Building Webond from Abuja, Nigeria 🇳🇬" style={{ width: '100%', padding: '13px 15px', border: '1.5px solid var(--bd)', borderRadius: 12, fontSize: 14, fontFamily: 'var(--ff)', color: 'var(--t1)', outline: 'none', background: 'var(--bg)', resize: 'none', height: 80, lineHeight: 1.6 }} />
          </Field>
          <BtnFull onClick={handleFinish}>Finish — Let's go! 🚀</BtnFull>
        </div>
      </AuthBody>
    </div>
  );
};

// INTERESTS
export const Interests = () => {
  const { goTo, navTo } = useStore();
  const [selected, setSelected] = useState(new Set(['💻 Technology', '⚽ Sports', '🚀 Startups']));
  const interests = [
    '💻 Technology', '🎵 Music', '⚽ Sports', '🎨 Art & Design',
    '🚀 Startups', '🍕 Food', '✈️ Travel', '📸 Photography',
    '🤖 AI & Future', '💰 Finance', '🎮 Gaming', '💚 Health',
  ];

  const toggle = (i) => {
    setSelected(prev => { const s = new Set(prev); s.has(i) ? s.delete(i) : s.add(i); return s; });
  };

  const handleDone = () => {
    navTo('profile');
    setTimeout(() => toast.success('🚀 Your Webond feed is ready!'), 400);
  };

  return (
    <div style={{ height: '100%', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <AuthTop title="Your interests" right={<span onClick={handleDone} style={{ fontSize: 14, fontWeight: 600, color: 'var(--t3)', cursor: 'pointer' }}>Skip</span>} />
      <AuthBody>
        <AuthHead title="What do you love? ❤️" subtitle="Pick 3+ topics so Webond AI can perfectly personalise your feed" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, margin: '12px 0' }}>
          {interests.map(i => {
            const on = selected.has(i);
            return (
              <div key={i} onClick={() => toggle(i)} style={{ padding: '13px 6px', border: `1.5px solid ${on ? 'var(--teal)' : 'var(--bd)'}`, borderRadius: 13, textAlign: 'center', cursor: 'pointer', transition: '.2s', background: on ? 'var(--teal3)' : '#fff' }}>
                <div style={{ fontSize: 24, marginBottom: 5 }}>{i.split(' ')[0]}</div>
                <div style={{ fontSize: 11, fontWeight: 600, color: on ? 'var(--teal2)' : 'var(--t2)' }}>{i.split(' ').slice(1).join(' ')}</div>
              </div>
            );
          })}
        </div>
        <BtnFull onClick={handleDone}>Start exploring Webond →</BtnFull>
      </AuthBody>
    </div>
  );
};
