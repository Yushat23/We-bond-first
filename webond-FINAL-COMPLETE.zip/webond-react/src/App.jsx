// src/App.jsx
import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from 'react-hot-toast';
import useStore from './store/useStore';
import './styles/globals.css';

// Auth
import {
  Splash, Welcome, Login, Signup, Signup2, Signup3,
  OTPScreen, ForgotPassword, ProfileSetup, Interests
} from './components/auth';

// App
import { Feed, CreatePostModal } from './components/feed';
import { Profile } from './components/profile';
import { VideoFeed, ReelScreen } from './components/video';
import { Messages } from './components/messages';
import { Chat } from './components/chat';
import { Settings } from './components/settings';

const AUTH_SCREENS = ['splash','welcome','login','signup','signup2','signup3','otp','forgot','setup','interests'];
const APP_SCREENS = ['profile','feed','video','reel','messages','chat','settings'];

const SCREEN_MAP = {
  splash: Splash, welcome: Welcome, login: Login,
  signup: Signup, signup2: Signup2, signup3: Signup3,
  otp: OTPScreen, forgot: ForgotPassword, setup: ProfileSetup, interests: Interests,
  profile: Profile, feed: Feed, video: VideoFeed, reel: ReelScreen,
  messages: Messages, chat: Chat, settings: Settings,
};

const NAV_ITEMS = [
  { id: 'profile', label: 'Profile', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> },
  { id: 'feed',    label: 'Home',    icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg> },
  { id: '__fab__', label: '',         icon: null },
  { id: 'messages',label: 'Messages', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> },
  { id: 'video',   label: 'Reels',   icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg> },
];

const StatusBar = () => {
  const [time, setTime] = useState('');
  useEffect(() => {
    const update = () => {
      const n = new Date();
      const h = n.getHours() % 12 || 12;
      const m = n.getMinutes();
      setTime(`${h}:${m < 10 ? '0' : ''}${m}`);
    };
    update();
    const t = setInterval(update, 30000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="status-bar">
      <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--t1)', fontVariantNumeric: 'tabular-nums' }}>{time}</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="var(--t1)" strokeWidth="2" strokeLinecap="round"><path d="M1.42 9a15.91 15.91 0 0 1 21.16 0M5 12.55a11 11 0 0 1 14.08 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/></svg>
        <div style={{ width: 22, height: 11, border: '1.5px solid var(--t1)', borderRadius: 3, position: 'relative', display: 'flex', alignItems: 'center', padding: 1 }}>
          <div style={{ height: '100%', background: 'var(--t1)', borderRadius: 1, width: '80%' }} />
          <div style={{ position: 'absolute', right: -5, top: '50%', transform: 'translateY(-50%)', width: 3, height: 5, background: 'var(--t1)', borderRadius: '0 1px 1px 0' }} />
        </div>
      </div>
    </div>
  );
};

const BottomNav = ({ current, onNavigate, onPost }) => (
  <div className="bottom-nav">
    {NAV_ITEMS.map(item => {
      if (item.id === '__fab__') {
        return (
          <button key="fab" className="fab-btn" onClick={onPost}>
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </button>
        );
      }
      const active = current === item.id;
      return (
        <button key={item.id} className={`nav-item ${active ? 'active' : ''}`} onClick={() => onNavigate(item.id)}>
          {item.icon}
          <span>{item.label}</span>
        </button>
      );
    })}
  </div>
);

const variants = {
  enter: (dir) => ({ x: dir > 0 ? '100%' : '-100%', opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir) => ({ x: dir > 0 ? '-100%' : '100%', opacity: 0 }),
};

export default function App() {
  const { currentScreen, isAuthenticated, navTo, currentTab } = useStore();
  const [showCreate, setShowCreate] = useState(false);
  const [direction, setDirection] = useState(1);
  const [prevScreen, setPrevScreen] = useState(null);

  const isAuthScreen = AUTH_SCREENS.includes(currentScreen);
  const isAppScreen = APP_SCREENS.includes(currentScreen);
  const showNav = isAppScreen && currentScreen !== 'reel';

  const handleNavigate = (id) => {
    setDirection(APP_SCREENS.indexOf(id) >= APP_SCREENS.indexOf(currentScreen) ? 1 : -1);
    setPrevScreen(currentScreen);
    navTo(id);
  };

  const Component = SCREEN_MAP[currentScreen] || Splash;

  // No transition for splash
  if (currentScreen === 'splash') {
    return (
      <div className="phone-shell">
        <StatusBar />
        <div className="screens"><div className="screen"><Component /></div></div>
      </div>
    );
  }

  return (
    <div className="phone-shell">
      <StatusBar />
      <div className="screens">
        <AnimatePresence custom={direction} mode="wait">
          <motion.div
            key={currentScreen}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: 'tween', duration: 0.28, ease: [0.4, 0, 0.2, 1] }}
            className="screen"
          >
            <Component />
          </motion.div>
        </AnimatePresence>

        {showCreate && <CreatePostModal onClose={() => setShowCreate(false)} />}
        <Toaster
          position="bottom-center"
          containerStyle={{ bottom: 90 }}
          toastOptions={{
            style: {
              background: 'var(--t1)', color: '#fff',
              borderRadius: 24, fontSize: 13, fontFamily: 'var(--ff)',
              fontWeight: 500, padding: '10px 18px',
            },
            duration: 2800,
          }}
        />
      </div>

      {showNav && (
        <BottomNav
          current={currentScreen}
          onNavigate={handleNavigate}
          onPost={() => setShowCreate(true)}
        />
      )}
    </div>
  );
}
